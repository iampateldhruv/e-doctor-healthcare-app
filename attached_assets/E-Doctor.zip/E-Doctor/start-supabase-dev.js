#!/usr/bin/env node

import { spawn } from 'child_process';
import path from 'path';

// Kill any existing node processes
console.log('Stopping any existing server processes...');
try {
  spawn('pkill', ['-f', 'server/index'], { stdio: 'inherit' });
} catch (err) {
  console.log('No existing processes found');
}

// Wait a moment for processes to end
setTimeout(() => {
  console.log('Starting server with Supabase...');
  
  // Set environment variables
  process.env.SUPABASE_URL = 'https://oifgojcqkhizhleolcjt.supabase.co';
  process.env.SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc';
  process.env.SESSION_SECRET = 'healthhubai-session-secret';
  
  // Start the server with Supabase
  const server = spawn('npx', ['tsx', 'server/index-supabase-fixed.ts'], {
    stdio: 'inherit',
    env: {
      ...process.env,
    }
  });
  
  server.on('close', (code) => {
    console.log(`Server process exited with code ${code}`);
  });
  
}, 1000);