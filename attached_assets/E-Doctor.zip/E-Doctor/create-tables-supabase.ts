import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import fs from 'fs';

// Load environment variables
dotenv.config();

// Use the provided credentials or fall back to defaults
const supabaseUrl = process.env.SUPABASE_URL || 'https://oifgojcqkhizhleolcjt.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc';

// Initialize Supabase client
const supabase = createClient(supabaseUrl, supabaseKey);

// SQL statements to create tables
const createTablesSQL = `
-- Users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'patient',
  profile_picture TEXT,
  specialization TEXT,
  experience INTEGER,
  bio TEXT,
  location TEXT,
  verified BOOLEAN DEFAULT false,
  rating INTEGER DEFAULT 0,
  review_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Medical records table
CREATE TABLE IF NOT EXISTS medical_records (
  id SERIAL PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  date TIMESTAMP WITH TIME ZONE DEFAULT now(),
  type TEXT NOT NULL,
  file_url TEXT
);

-- Symptoms table
CREATE TABLE IF NOT EXISTS symptoms (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT
);

-- Conditions table
CREATE TABLE IF NOT EXISTS conditions (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  specialization TEXT NOT NULL
);

-- Symptom-Condition mappings table
CREATE TABLE IF NOT EXISTS symptom_conditions (
  id SERIAL PRIMARY KEY,
  symptom_id INTEGER NOT NULL REFERENCES symptoms(id),
  condition_id INTEGER NOT NULL REFERENCES conditions(id),
  weight INTEGER DEFAULT 1,
  UNIQUE(symptom_id, condition_id)
);

-- Consultations table
CREATE TABLE IF NOT EXISTS consultations (
  id SERIAL PRIMARY KEY,
  patient_id INTEGER NOT NULL REFERENCES users(id),
  doctor_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending',
  scheduled_at TIMESTAMP WITH TIME ZONE,
  symptoms JSONB,
  notes TEXT,
  diagnosis TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  consultation_id INTEGER NOT NULL REFERENCES consultations(id),
  sender_id INTEGER NOT NULL REFERENCES users(id),
  content TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  read BOOLEAN DEFAULT false
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price INTEGER NOT NULL,
  category TEXT NOT NULL,
  image_url TEXT,
  requires_prescription BOOLEAN DEFAULT false,
  in_stock BOOLEAN DEFAULT true
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending',
  total INTEGER NOT NULL,
  address TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  quantity INTEGER NOT NULL,
  price INTEGER NOT NULL
);

-- Posts table
CREATE TABLE IF NOT EXISTS posts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  image_url TEXT,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  tags JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
  id SERIAL PRIMARY KEY,
  post_id INTEGER NOT NULL REFERENCES posts(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
`;

async function createTables() {
  console.log('Creating tables in Supabase...');
  
  try {
    // Using Supabase's SQL API for users with administrative privileges
    // Note: This won't work with the anon key, user will need to create tables manually
    const { error } = await supabase.rpc('pgexec', { sql: createTablesSQL });
    
    if (error) {
      console.error('Error creating tables:', error);
      console.log('\nSince the automatic table creation failed, you\'ll need to manually create the tables.');
      console.log('Please log into your Supabase dashboard, go to the SQL editor, and run the SQL statements above.');
      
      // Save the SQL to a file for the user to run manually
      fs.writeFileSync('supabase-tables.sql', createTablesSQL);
      console.log('The SQL has been saved to supabase-tables.sql for your convenience.');
    } else {
      console.log('Tables created successfully!');
    }
  } catch (error) {
    console.error('Error:', error);
    console.log('\nYou\'ll need to manually create the tables in Supabase.');
    
    // Save the SQL to a file for the user to run manually
    fs.writeFileSync('supabase-tables.sql', createTablesSQL);
    console.log('The SQL has been saved to supabase-tables.sql for your convenience.');
  }
}

createTables();