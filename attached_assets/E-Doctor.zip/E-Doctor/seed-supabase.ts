import { createClient } from '@supabase/supabase-js';
import * as crypto from 'crypto';

// Use hardcoded credentials to ensure availability
const supabaseUrl = process.env.SUPABASE_URL || 'https://oifgojcqkhizhleolcjt.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc';

const supabase = createClient(supabaseUrl, supabaseKey);

async function hashPassword(password: string): Promise<string> {
  return new Promise((resolve, reject) => {
    // Generate a random salt
    const salt = crypto.randomBytes(16).toString('hex');
    
    // Hash the password with the salt
    crypto.pbkdf2(password, salt, 1000, 64, 'sha512', (err, derivedKey) => {
      if (err) reject(err);
      // Store both the salt and the hash, separated by a colon
      resolve(salt + ':' + derivedKey.toString('hex'));
    });
  });
}

async function seedUsers() {
  console.log('Seeding users...');
  
  // Check if users already exist
  const { count, error: countError } = await supabase
    .from('users')
    .select('*', { count: 'exact', head: true });
  
  if (countError) {
    console.error('Error checking user count:', countError);
    return;
  }
  
  if (count && count > 0) {
    console.log(`Users table already has ${count} records. Skipping seeding.`);
    return;
  }

  // Demo users
  const users = [
    {
      username: 'patient1',
      password: await hashPassword('password123'),
      email: 'patient1@example.com',
      full_name: 'John Smith',
      role: 'patient',
      profile_picture: 'https://randomuser.me/api/portraits/men/1.jpg',
      location: 'New York',
      verified: true
    },
    {
      username: 'doctor1',
      password: await hashPassword('password123'),
      email: 'doctor1@example.com',
      full_name: 'Dr. Sarah Johnson',
      role: 'doctor',
      profile_picture: 'https://randomuser.me/api/portraits/women/1.jpg',
      specialization: 'Cardiology',
      experience: 8,
      bio: 'Experienced cardiologist specializing in preventive heart care.',
      location: 'Boston',
      verified: true,
      rating: 4,
      review_count: 15
    },
    {
      username: 'doctor2',
      password: await hashPassword('password123'),
      email: 'doctor2@example.com',
      full_name: 'Dr. Michael Chen',
      role: 'doctor',
      profile_picture: 'https://randomuser.me/api/portraits/men/2.jpg',
      specialization: 'Neurology',
      experience: 12,
      bio: 'Neurologist with expertise in headache treatment and nerve disorders.',
      location: 'San Francisco',
      verified: true,
      rating: 5,
      review_count: 23
    },
    {
      username: 'admin',
      password: await hashPassword('admin123'),
      email: 'admin@healthhub.ai',
      full_name: 'Admin User',
      role: 'admin',
      verified: true
    }
  ];

  // Insert users
  const { error: insertError } = await supabase
    .from('users')
    .insert(users);
  
  if (insertError) {
    console.error('Error inserting users:', insertError);
    return;
  }
  
  console.log('Users seeded successfully');
}

async function seedSymptoms() {
  console.log('Seeding symptoms...');
  
  // Check if symptoms already exist
  const { count, error: countError } = await supabase
    .from('symptoms')
    .select('*', { count: 'exact', head: true });
  
  if (countError) {
    console.error('Error checking symptom count:', countError);
    return;
  }
  
  if (count && count > 0) {
    console.log(`Symptoms table already has ${count} records. Skipping seeding.`);
    return;
  }

  // Demo symptoms
  const symptoms = [
    { name: 'Headache', description: 'Pain in the head or upper neck' },
    { name: 'Fever', description: 'Elevated body temperature' },
    { name: 'Cough', description: 'Sudden expulsion of air from the lungs' },
    { name: 'Fatigue', description: 'Feeling of tiredness or exhaustion' },
    { name: 'Nausea', description: 'Sensation of unease in the stomach with an urge to vomit' },
    { name: 'Dizziness', description: 'Feeling of being lightheaded or unsteady' },
    { name: 'Chest Pain', description: 'Discomfort or pain in the chest area' },
    { name: 'Shortness of Breath', description: 'Difficulty breathing or feeling like you cannot get enough air' },
    { name: 'Abdominal Pain', description: 'Pain felt between the chest and pelvic region' },
    { name: 'Joint Pain', description: 'Discomfort or soreness in one or more joints' }
  ];

  // Insert symptoms
  const { error: insertError } = await supabase
    .from('symptoms')
    .insert(symptoms);
  
  if (insertError) {
    console.error('Error inserting symptoms:', insertError);
    return;
  }
  
  console.log('Symptoms seeded successfully');
}

async function seedConditions() {
  console.log('Seeding conditions...');
  
  // Check if conditions already exist
  const { count, error: countError } = await supabase
    .from('conditions')
    .select('*', { count: 'exact', head: true });
  
  if (countError) {
    console.error('Error checking condition count:', countError);
    return;
  }
  
  if (count && count > 0) {
    console.log(`Conditions table already has ${count} records. Skipping seeding.`);
    return;
  }

  // Demo conditions
  const conditions = [
    { 
      name: 'Migraine', 
      description: 'A neurological condition that causes recurring headaches, often with throbbing pain on one side of the head.', 
      specialization: 'Neurology' 
    },
    { 
      name: 'Common Cold', 
      description: 'A viral infection of the upper respiratory tract that affects the nose and throat.', 
      specialization: 'General Practice' 
    },
    { 
      name: 'Hypertension', 
      description: 'A chronic condition characterized by elevated blood pressure in the arteries.', 
      specialization: 'Cardiology' 
    },
    { 
      name: 'Type 2 Diabetes', 
      description: 'A chronic condition that affects the way your body metabolizes sugar.', 
      specialization: 'Endocrinology' 
    },
    { 
      name: 'Asthma', 
      description: 'A condition in which airways narrow and swell, producing extra mucus.', 
      specialization: 'Pulmonology' 
    }
  ];

  // Insert conditions
  const { error: insertError } = await supabase
    .from('conditions')
    .insert(conditions);
  
  if (insertError) {
    console.error('Error inserting conditions:', insertError);
    return;
  }
  
  console.log('Conditions seeded successfully');
}

async function seedSymptomConditions() {
  console.log('Seeding symptom-condition mappings...');
  
  // Check if mappings already exist
  const { count, error: countError } = await supabase
    .from('symptom_conditions')
    .select('*', { count: 'exact', head: true });
  
  if (countError) {
    console.error('Error checking symptom-condition count:', countError);
    return;
  }
  
  if (count && count > 0) {
    console.log(`Symptom-condition mappings table already has ${count} records. Skipping seeding.`);
    return;
  }

  // Get symptoms and conditions IDs
  const { data: symptoms, error: symptomsError } = await supabase
    .from('symptoms')
    .select('id, name');
  
  if (symptomsError || !symptoms) {
    console.error('Error fetching symptoms:', symptomsError);
    return;
  }
  
  const { data: conditions, error: conditionsError } = await supabase
    .from('conditions')
    .select('id, name');
  
  if (conditionsError || !conditions) {
    console.error('Error fetching conditions:', conditionsError);
    return;
  }

  // Create symptom-condition mappings based on names
  const mappings = [
    { symptomName: 'Headache', conditionName: 'Migraine', weight: 5 },
    { symptomName: 'Dizziness', conditionName: 'Migraine', weight: 3 },
    { symptomName: 'Nausea', conditionName: 'Migraine', weight: 2 },
    { symptomName: 'Headache', conditionName: 'Common Cold', weight: 2 },
    { symptomName: 'Fever', conditionName: 'Common Cold', weight: 4 },
    { symptomName: 'Cough', conditionName: 'Common Cold', weight: 5 },
    { symptomName: 'Headache', conditionName: 'Hypertension', weight: 3 },
    { symptomName: 'Dizziness', conditionName: 'Hypertension', weight: 3 },
    { symptomName: 'Chest Pain', conditionName: 'Hypertension', weight: 4 },
    { symptomName: 'Fatigue', conditionName: 'Type 2 Diabetes', weight: 3 },
    { symptomName: 'Shortness of Breath', conditionName: 'Asthma', weight: 5 },
    { symptomName: 'Cough', conditionName: 'Asthma', weight: 3 }
  ];

  // Convert names to IDs
  const mappingsWithIds = mappings.map(mapping => {
    const symptom = symptoms.find(s => s.name === mapping.symptomName);
    const condition = conditions.find(c => c.name === mapping.conditionName);
    
    if (!symptom || !condition) return null;
    
    return {
      symptom_id: symptom.id,
      condition_id: condition.id,
      weight: mapping.weight
    };
  }).filter(m => m !== null);

  // Insert mappings
  const { error: insertError } = await supabase
    .from('symptom_conditions')
    .insert(mappingsWithIds);
  
  if (insertError) {
    console.error('Error inserting symptom-condition mappings:', insertError);
    return;
  }
  
  console.log('Symptom-condition mappings seeded successfully');
}

async function seedProducts() {
  console.log('Seeding products...');
  
  // Check if products already exist
  const { count, error: countError } = await supabase
    .from('products')
    .select('*', { count: 'exact', head: true });
  
  if (countError) {
    console.error('Error checking product count:', countError);
    return;
  }
  
  if (count && count > 0) {
    console.log(`Products table already has ${count} records. Skipping seeding.`);
    return;
  }

  // Demo products
  const products = [
    {
      name: 'Paracetamol',
      description: 'Pain reliever and fever reducer',
      price: 599, // $5.99
      category: 'Over-the-counter',
      image_url: 'https://via.placeholder.com/150',
      requires_prescription: false,
      in_stock: true
    },
    {
      name: 'Amoxicillin',
      description: 'Antibiotic used to treat bacterial infections',
      price: 1299, // $12.99
      category: 'Prescription',
      image_url: 'https://via.placeholder.com/150',
      requires_prescription: true,
      in_stock: true
    },
    {
      name: 'Digital Thermometer',
      description: 'Accurate temperature measurement device',
      price: 1499, // $14.99
      category: 'Medical Devices',
      image_url: 'https://via.placeholder.com/150',
      requires_prescription: false,
      in_stock: true
    },
    {
      name: 'Blood Pressure Monitor',
      description: 'Home device for monitoring blood pressure',
      price: 4999, // $49.99
      category: 'Medical Devices',
      image_url: 'https://via.placeholder.com/150',
      requires_prescription: false,
      in_stock: true
    },
    {
      name: 'Vitamin D3 Supplements',
      description: 'Supports bone health and immune function',
      price: 1799, // $17.99
      category: 'Supplements',
      image_url: 'https://via.placeholder.com/150',
      requires_prescription: false,
      in_stock: true
    }
  ];

  // Insert products
  const { error: insertError } = await supabase
    .from('products')
    .insert(products);
  
  if (insertError) {
    console.error('Error inserting products:', insertError);
    return;
  }
  
  console.log('Products seeded successfully');
}

async function seedPosts() {
  console.log('Seeding community posts...');
  
  // Check if posts already exist
  const { count, error: countError } = await supabase
    .from('posts')
    .select('*', { count: 'exact', head: true });
  
  if (countError) {
    console.error('Error checking post count:', countError);
    return;
  }
  
  if (count && count > 0) {
    console.log(`Posts table already has ${count} records. Skipping seeding.`);
    return;
  }

  // Get user IDs
  const { data: users, error: usersError } = await supabase
    .from('users')
    .select('id, username');
  
  if (usersError || !users) {
    console.error('Error fetching users:', usersError);
    return;
  }

  // Find doctor and patient IDs
  const doctorUser = users.find(u => u.username === 'doctor1');
  const patientUser = users.find(u => u.username === 'patient1');
  
  if (!doctorUser || !patientUser) {
    console.error('Could not find required users for posts');
    return;
  }

  // Demo posts
  const posts = [
    {
      user_id: doctorUser.id,
      title: 'Tips for Managing Stress',
      content: 'Stress can have significant effects on your physical and mental health. Here are some tips to manage stress effectively: practice deep breathing, exercise regularly, get enough sleep, and maintain a balanced diet.',
      tags: ['wellness', 'mental health', 'stress management'],
      likes: 15,
      comments: 3
    },
    {
      user_id: doctorUser.id,
      title: 'Understanding Blood Pressure Readings',
      content: 'Blood pressure readings have two numbers: systolic (top) and diastolic (bottom). Normal blood pressure is less than 120/80 mm Hg. If you have concerns about your blood pressure, consult your healthcare provider.',
      tags: ['cardiology', 'blood pressure', 'health education'],
      likes: 23,
      comments: 7
    },
    {
      user_id: patientUser.id,
      title: 'My Experience with Virtual Consultations',
      content: 'I was skeptical about virtual consultations at first, but my recent experience changed my mind. The process was convenient, efficient, and I received the same level of care as in-person visits.',
      tags: ['telehealth', 'patient experience', 'digital health'],
      likes: 8,
      comments: 2
    }
  ];

  // Insert posts
  const { error: insertError } = await supabase
    .from('posts')
    .insert(posts);
  
  if (insertError) {
    console.error('Error inserting posts:', insertError);
    return;
  }
  
  console.log('Posts seeded successfully');
}

async function seedAll() {
  try {
    console.log('Starting database seeding...');
    await seedUsers();
    await seedSymptoms();
    await seedConditions();
    await seedSymptomConditions();
    await seedProducts();
    await seedPosts();
    console.log('Database seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
  }
}

// Run the seeding process
seedAll();