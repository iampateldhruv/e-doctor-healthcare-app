#!/bin/bash

# Kill any existing node processes
echo "Stopping any existing server processes..."
pkill -f "server/index" || true

# Wait a moment for processes to end
sleep 1

echo "Starting server with Supabase..."

# Start the server with Supabase
NODE_ENV=development \
SUPABASE_URL=https://oifgojcqkhizhleolcjt.supabase.co \
SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc \
SESSION_SECRET=healthhubai-session-secret \
npx tsx server/index-supabase-fixed.ts