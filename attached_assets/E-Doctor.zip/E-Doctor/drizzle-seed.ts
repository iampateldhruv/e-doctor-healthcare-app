import { db } from './server/db';
import { medicationProducts } from './server/product-data';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';
import { 
  users, products,
  insertUserSchema, insertProductSchema
} from './shared/schema';
import { eq } from 'drizzle-orm';

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seedDatabase() {
  try {
    console.log("Starting database seeding...");

    // Check if users table exists
    try {
      const existingUsers = await db.select().from(users);
      console.log(`Found ${existingUsers.length} existing users`);
    } catch (error) {
      console.error("Error checking users table:", error);
      return;
    }

    // Add a patient
    try {
      const patientExists = await db.select().from(users).where(eq(users.username, "patient1"));
      
      if (patientExists.length === 0) {
        await db.insert(users).values({
          username: "patient1",
          password: await hashPassword("password123"),
          email: "patient1@example.com",
          fullName: "John Smith",
          role: "patient",
          profilePicture: "https://randomuser.me/api/portraits/men/1.jpg",
          specialization: null,
          experience: null,
          rating: 0,
          reviewCount: 0,
          verified: false,
          bio: null,
          location: "New York, NY"
        });
        console.log("Created patient user");
      } else {
        console.log("Patient user already exists");
      }
    } catch (error) {
      console.error("Error adding patient:", error);
    }

    // Add a doctor
    try {
      const doctorExists = await db.select().from(users).where(eq(users.username, "dr.cardio"));
      
      if (doctorExists.length === 0) {
        await db.insert(users).values({
          username: "dr.cardio",
          password: await hashPassword("doctor123"),
          email: "cardio@example.com",
          fullName: "Dr. Robert Chen",
          role: "doctor",
          profilePicture: "https://randomuser.me/api/portraits/men/5.jpg",
          specialization: "Cardiology",
          experience: 15,
          rating: 5,
          reviewCount: 120,
          verified: true,
          bio: "Board-certified cardiologist with over 15 years of experience treating heart conditions.",
          location: "Chicago, IL"
        });
        console.log("Created doctor user");
      } else {
        console.log("Doctor user already exists");
      }
    } catch (error) {
      console.error("Error adding doctor:", error);
    }

    // Add products
    try {
      const existingProducts = await db.select().from(products);
      
      if (existingProducts.length === 0) {
        console.log("Adding products...");
        
        for (const product of medicationProducts) {
          await db.insert(products).values({
            name: product.name,
            description: product.description,
            price: product.price,
            category: product.category,
            imageUrl: product.imageUrl,
            requiresPrescription: product.requiresPrescription,
            inStock: product.inStock
          });
        }
        console.log(`Added ${medicationProducts.length} products`);
      } else {
        console.log(`Products already exist (${existingProducts.length} found)`);
      }
    } catch (error) {
      console.error("Error adding products:", error);
    }
    
    console.log("Database seeding completed successfully");
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    process.exit(0);
  }
}

seedDatabase();