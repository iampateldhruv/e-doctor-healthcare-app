import { db } from './server/db';
import { medicationProducts } from './server/product-data';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seedUsers() {
  try {
    // Create admin user for testing
    console.log("Adding test users...");
    
    // Insert some users
    await db.execute(`
      INSERT INTO users 
      (username, password, email, full_name, role, profile_picture, specialization, 
       experience, rating, review_count, verified, bio, location)
      VALUES 
      ('patient1', $1, 'patient1@example.com', 'John Smith', 'patient', 'https://randomuser.me/api/portraits/men/1.jpg', null, null, 0, 0, false, null, 'New York, NY')
    `, [await hashPassword("password123")]);
    
    await db.execute(`
      INSERT INTO users 
      (username, password, email, full_name, role, profile_picture, specialization, 
       experience, rating, review_count, verified, bio, location)
      VALUES 
      ('dr.cardio', $1, 'cardio@example.com', 'Dr. Robert Chen', 'doctor', 'https://randomuser.me/api/portraits/men/5.jpg', 'Cardiology', 15, 5, 120, true, 'Board-certified cardiologist with over 15 years of experience treating heart conditions.', 'Chicago, IL')
    `, [await hashPassword("doctor123")]);
    
    // Add products
    console.log("Adding products...");
    for (const product of medicationProducts) {
      await db.execute(`
        INSERT INTO products 
        (name, description, price, category, image_url, requires_prescription, in_stock)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [
        product.name, 
        product.description, 
        product.price, 
        product.category, 
        product.imageUrl, 
        product.requiresPrescription, 
        product.inStock
      ]);
    }
    
    console.log("Database seeding completed successfully");
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    process.exit(0);
  }
}

seedUsers();