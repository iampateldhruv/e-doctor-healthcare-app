#!/bin/bash

# Stop all running servers
echo "Stopping any running servers..."
pkill -f "server/index-sqlite.ts" || true
pkill -f "server/index-supabase.ts" || true
pkill -f "server/index-supabase-fixed.ts" || true
pkill -f "tsx" || true
pkill -f "node" || true

# Wait a moment for servers to stop
sleep 2

# Make script executable
chmod +x ./run-with-supabase.sh

# Run the server with Supabase
echo "Starting server with Supabase database..."
npx tsx server/index-supabase-fixed.ts