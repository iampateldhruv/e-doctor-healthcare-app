import { db } from './server/db';
import { symptoms } from './shared/schema';

const commonSymptoms = [
  { name: "Headache", description: "Pain in the head or upper neck" },
  { name: "Fever", description: "Elevated body temperature" },
  { name: "Cough", description: "Sudden expulsion of air from the lungs" },
  { name: "Fatigue", description: "Extreme tiredness resulting from mental or physical exertion" },
  { name: "Nausea", description: "Feeling of sickness with an inclination to vomit" },
  { name: "Dizziness", description: "Lightheadedness, feeling faint or unsteady" },
  { name: "Chest Pain", description: "Pain or discomfort in the chest area" },
  { name: "Shortness of Breath", description: "Difficulty breathing or catching your breath" },
  { name: "Sore Throat", description: "Pain or irritation in the throat" },
  { name: "Runny Nose", description: "Mucus discharge from the nose" },
  { name: "Muscle Aches", description: "Pain or soreness in muscles" },
  { name: "Joint Pain", description: "Discomfort or pain in joints" }
];

async function seedSymptoms() {
  try {
    console.log('Adding symptoms to database...');
    
    for (const symptom of commonSymptoms) {
      await db.insert(symptoms).values(symptom).onConflictDoNothing();
      console.log(`Added or skipped symptom: ${symptom.name}`);
    }
    
    console.log('Symptom seeding complete!');
  } catch (error) {
    console.error('Error seeding symptoms:', error);
  } finally {
    process.exit(0);
  }
}

seedSymptoms();