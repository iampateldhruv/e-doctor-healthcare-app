import { db } from './server/db';
import { medicationProducts } from './server/product-data';
import { additionalSymptoms, symptomConditionMappings, conditionData } from './server/symptom-data';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function seedDatabase() {
  try {
    // Add users (doctors and patients)
    const users = [
      // Patients
      {
        username: "patient1",
        password: await hashPassword("password123"),
        email: "patient1@example.com",
        full_name: "John Smith",
        role: "patient",
        profile_picture: "https://randomuser.me/api/portraits/men/1.jpg",
        specialization: null,
        experience: null,
        rating: 0,
        review_count: 0,
        verified: false,
        bio: null,
        location: "New York, NY"
      },
      {
        username: "patient2",
        password: await hashPassword("password123"),
        email: "patient2@example.com",
        full_name: "Emily Johnson",
        role: "patient",
        profile_picture: "https://randomuser.me/api/portraits/women/2.jpg",
        specialization: null,
        experience: null,
        rating: 0,
        review_count: 0,
        verified: false,
        bio: null,
        location: "Boston, MA"
      },
      
      // Doctors
      {
        username: "dr.cardio",
        password: await hashPassword("doctor123"),
        email: "cardio@example.com",
        full_name: "Dr. Robert Chen",
        role: "doctor",
        profile_picture: "https://randomuser.me/api/portraits/men/5.jpg",
        specialization: "Cardiology",
        experience: 15,
        rating: 4.8,
        review_count: 120,
        verified: true,
        bio: "Board-certified cardiologist with over 15 years of experience treating heart conditions.",
        location: "Chicago, IL"
      },
      {
        username: "dr.neuro",
        password: await hashPassword("doctor123"),
        email: "neuro@example.com",
        full_name: "Dr. Sarah Wilson",
        role: "doctor",
        profile_picture: "https://randomuser.me/api/portraits/women/6.jpg",
        specialization: "Neurology",
        experience: 12,
        rating: 4.9,
        review_count: 95,
        verified: true,
        bio: "Neurologist specializing in headaches, migraines, and neurodegenerative disorders.",
        location: "Seattle, WA"
      },
      {
        username: "dr.derm",
        password: await hashPassword("doctor123"),
        email: "derm@example.com",
        full_name: "Dr. Michael Davis",
        role: "doctor",
        profile_picture: "https://randomuser.me/api/portraits/men/8.jpg",
        specialization: "Dermatology",
        experience: 10,
        rating: 4.7,
        review_count: 85,
        verified: true,
        bio: "Dermatologist focused on skin diseases and cosmetic procedures.",
        location: "Miami, FL"
      },
      {
        username: "dr.psych",
        password: await hashPassword("doctor123"),
        email: "psych@example.com",
        full_name: "Dr. Lisa Thompson",
        role: "doctor",
        profile_picture: "https://randomuser.me/api/portraits/women/10.jpg",
        specialization: "Psychiatry",
        experience: 14,
        rating: 4.9,
        review_count: 110,
        verified: true,
        bio: "Psychiatrist specializing in anxiety disorders, depression, and PTSD.",
        location: "Denver, CO"
      },
      {
        username: "dr.gp",
        password: await hashPassword("doctor123"),
        email: "gp@example.com",
        full_name: "Dr. James Martin",
        role: "doctor",
        profile_picture: "https://randomuser.me/api/portraits/men/12.jpg",
        specialization: "General Medicine",
        experience: 20,
        rating: 4.6,
        review_count: 200,
        verified: true,
        bio: "Family physician providing comprehensive primary care for all ages.",
        location: "Austin, TX"
      }
    ];

    for (const user of users) {
      const existingUserResult = await db.execute(
        `SELECT id FROM users WHERE username = $1`,
        [user.username]
      );
      
      if (!existingUserResult.rows.length) {
        await db.execute(`
          INSERT INTO users 
          (username, password, email, full_name, role, profile_picture, specialization, 
           experience, rating, review_count, verified, bio, location)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        `, [
          user.username, user.password, user.email, user.full_name, user.role,
          user.profile_picture, user.specialization, user.experience, user.rating,
          user.review_count, user.verified, user.bio, user.location
        ]);
        console.log(`Created user: ${user.username}`);
      } else {
        console.log(`User ${user.username} already exists, skipping`);
      }
    }
    
    // Add symptoms
    const symptoms = [
      { name: "Headache", description: "Pain in the head or upper neck" },
      { name: "Fever", description: "Elevated body temperature" },
      { name: "Cough", description: "Sudden expulsion of air from the lungs" },
      { name: "Fatigue", description: "Extreme tiredness resulting from mental or physical exertion" },
      { name: "Nausea", description: "Feeling of sickness with an inclination to vomit" },
      { name: "Dizziness", description: "Lightheadedness, feeling faint or unsteady" },
      { name: "Chest Pain", description: "Pain or discomfort in the chest area" },
      { name: "Shortness of Breath", description: "Difficulty breathing or catching your breath" },
      { name: "Sore Throat", description: "Pain or irritation in the throat" },
      { name: "Runny Nose", description: "Mucus discharge from the nose" },
      { name: "Muscle Aches", description: "Pain or soreness in muscles" },
      { name: "Joint Pain", description: "Discomfort or pain in joints" },
      { name: "Abdominal Pain", description: "Pain in the area between the chest and pelvis" },
      { name: "Vomiting", description: "Forceful expulsion of stomach contents" },
      { name: "Diarrhea", description: "Loose, watery bowel movements" },
      { name: "Rash", description: "Area of irritated or swollen skin" },
      { name: "Sneezing", description: "Sudden, forceful, involuntary expulsion of air through the nose and mouth" },
      { name: "Blurred Vision", description: "Lack of sharpness of vision resulting in the inability to see fine detail" },
      { name: "Loss of Appetite", description: "Decreased desire to eat" },
      { name: "Chills", description: "Feeling of cold with shivering" },
      { name: "Sweating", description: "Excessive perspiration" },
      { name: "Back Pain", description: "Pain in the back area" },
      { name: "Insomnia", description: "Difficulty falling or staying asleep" },
      { name: "Anxiety", description: "Feeling of worry, nervousness, or unease" },
      ...additionalSymptoms
    ];
    
    // Add all symptoms
    for (const symptom of symptoms) {
      const existingSymptomResult = await db.execute(
        `SELECT id FROM symptoms WHERE name = $1`,
        [symptom.name]
      );
      
      if (!existingSymptomResult.rows.length) {
        await db.execute(`
          INSERT INTO symptoms (name, description)
          VALUES ($1, $2)
        `, [symptom.name, symptom.description]);
        console.log(`Created symptom: ${symptom.name}`);
      } else {
        console.log(`Symptom ${symptom.name} already exists, skipping`);
      }
    }
    
    // Add conditions
    const conditions = [
      { name: "Common Cold", description: "A viral infectious disease of the upper respiratory tract", specialization: "General Medicine" },
      { name: "Influenza", description: "Contagious respiratory illness caused by influenza viruses", specialization: "General Medicine" },
      { name: "Migraine", description: "Recurrent moderate to severe headaches", specialization: "Neurology" },
      { name: "Hypertension", description: "Persistently elevated blood pressure in the arteries", specialization: "Cardiology" },
      { name: "Anxiety Disorder", description: "Mental health condition characterized by feelings of worry or fear", specialization: "Psychiatry" },
      { name: "Asthma", description: "Chronic disease involving the airways in the lungs", specialization: "Pulmonology" },
      { name: "Diabetes", description: "Metabolic disease that causes high blood sugar", specialization: "Endocrinology" },
      { name: "Arthritis", description: "Inflammation of one or more joints", specialization: "Rheumatology" },
      { name: "Gastroenteritis", description: "Inflammation of the stomach and intestines", specialization: "Gastroenterology" },
      { name: "Dermatitis", description: "Inflammation of the skin", specialization: "Dermatology" },
      { name: "Bronchitis", description: "Inflammation of the lining of the bronchial tubes", specialization: "Pulmonology" },
      { name: "Sinusitis", description: "Inflammation of the sinuses", specialization: "Otolaryngology" },
      { name: "GERD", description: "A digestive disorder that affects the lower esophageal sphincter", specialization: "Gastroenterology" },
      { name: "Urinary Tract Infection", description: "Infection in any part of the urinary system", specialization: "Urology" },
      { name: "Insomnia", description: "Sleep disorder characterized by difficulty falling or staying asleep", specialization: "Neurology" },
      { name: "Depression", description: "Mental health disorder characterized by persistently depressed mood", specialization: "Psychiatry" },
      { name: "Osteoporosis", description: "Condition where bones become weak and brittle", specialization: "Orthopedics" },
      { name: "Hyperthyroidism", description: "Overactive thyroid gland producing excess thyroid hormone", specialization: "Endocrinology" },
      { name: "Hypothyroidism", description: "Underactive thyroid gland not producing enough thyroid hormone", specialization: "Endocrinology" },
      ...conditionData
    ];
    
    // Add all conditions
    for (const condition of conditions) {
      const existingConditionResult = await db.execute(
        `SELECT id FROM conditions WHERE name = $1`,
        [condition.name]
      );
      
      if (!existingConditionResult.rows.length) {
        await db.execute(`
          INSERT INTO conditions (name, description, specialization)
          VALUES ($1, $2, $3)
        `, [condition.name, condition.description, condition.specialization]);
        console.log(`Created condition: ${condition.name}`);
      } else {
        console.log(`Condition ${condition.name} already exists, skipping`);
      }
    }
    
    // Add symptom-condition mappings
    for (const mapping of symptomConditionMappings) {
      // Get symptom ID
      const symptomResult = await db.execute(
        `SELECT id FROM symptoms WHERE name = $1`,
        [mapping.symptomName]
      );
      
      if (symptomResult.rows.length === 0) {
        console.log(`Symptom ${mapping.symptomName} not found, skipping mapping`);
        continue;
      }
      
      // Get condition ID
      const conditionResult = await db.execute(
        `SELECT id FROM conditions WHERE name = $1`,
        [mapping.conditionName]
      );
      
      if (conditionResult.rows.length === 0) {
        console.log(`Condition ${mapping.conditionName} not found, skipping mapping`);
        continue;
      }
      
      const symptomId = symptomResult.rows[0].id;
      const conditionId = conditionResult.rows[0].id;
      
      // Check if mapping already exists
      const existingMappingResult = await db.execute(
        `SELECT id FROM symptom_conditions WHERE symptom_id = $1 AND condition_id = $2`,
        [symptomId, conditionId]
      );
      
      if (!existingMappingResult.rows.length) {
        await db.execute(`
          INSERT INTO symptom_conditions (symptom_id, condition_id, weight)
          VALUES ($1, $2, $3)
        `, [symptomId, conditionId, mapping.weight]);
        console.log(`Created mapping: ${mapping.symptomName} -> ${mapping.conditionName} (weight: ${mapping.weight})`);
      } else {
        console.log(`Mapping ${mapping.symptomName} -> ${mapping.conditionName} already exists, skipping`);
      }
    }
    
    // Add products
    for (const product of medicationProducts) {
      // Check if product already exists
      const existingProductResult = await db.execute(
        `SELECT id FROM products WHERE name = $1`,
        [product.name]
      );
      
      if (!existingProductResult.rows.length) {
        await db.execute(`
          INSERT INTO products 
          (name, description, price, category, image_url, requires_prescription, in_stock)
          VALUES ($1, $2, $3, $4, $5, $6, $7)
        `, [
          product.name, 
          product.description, 
          product.price, 
          product.category, 
          product.imageUrl, 
          product.requiresPrescription, 
          product.inStock
        ]);
        console.log(`Created product: ${product.name}`);
      } else {
        console.log(`Product ${product.name} already exists, skipping`);
      }
    }
    
    console.log('Database seeding completed successfully');
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    process.exit(0);
  }
}

seedDatabase();