import { db } from './server/db';
import { conditions, symptomConditions, symptoms } from './shared/schema';
import { eq, inArray } from 'drizzle-orm';

const commonConditions = [
  { name: "Common Cold", description: "A viral infectious disease of the upper respiratory tract", specialization: "General Medicine" },
  { name: "Influenza", description: "Contagious respiratory illness caused by influenza viruses", specialization: "General Medicine" },
  { name: "Migraine", description: "Recurrent moderate to severe headaches", specialization: "Neurology" },
  { name: "Hypertension", description: "Persistently elevated blood pressure in the arteries", specialization: "Cardiology" },
  { name: "Anxiety Disorder", description: "Mental health condition characterized by feelings of worry or fear", specialization: "Psychiatry" }
];

const symptomConditionMappings = [
  // Common Cold
  { symptomName: "Headache", conditionName: "Common Cold", weight: 2 },
  { symptomName: "Fever", conditionName: "Common Cold", weight: 3 },
  { symptomName: "Cough", conditionName: "Common Cold", weight: 4 },
  { symptomName: "Sore Throat", conditionName: "Common Cold", weight: 4 },
  { symptomName: "Runny Nose", conditionName: "Common Cold", weight: 5 },
  { symptomName: "Fatigue", conditionName: "Common Cold", weight: 2 },
  
  // Influenza
  { symptomName: "Headache", conditionName: "Influenza", weight: 3 },
  { symptomName: "Fever", conditionName: "Influenza", weight: 5 },
  { symptomName: "Fatigue", conditionName: "Influenza", weight: 4 },
  { symptomName: "Cough", conditionName: "Influenza", weight: 4 },
  { symptomName: "Muscle Aches", conditionName: "Influenza", weight: 5 },
  
  // Migraine
  { symptomName: "Headache", conditionName: "Migraine", weight: 5 },
  { symptomName: "Nausea", conditionName: "Migraine", weight: 3 },
  { symptomName: "Dizziness", conditionName: "Migraine", weight: 3 },
  
  // Hypertension
  { symptomName: "Chest Pain", conditionName: "Hypertension", weight: 4 },
  { symptomName: "Headache", conditionName: "Hypertension", weight: 3 },
  { symptomName: "Dizziness", conditionName: "Hypertension", weight: 3 },
  { symptomName: "Shortness of Breath", conditionName: "Hypertension", weight: 2 },
  
  // Anxiety Disorder
  { symptomName: "Fatigue", conditionName: "Anxiety Disorder", weight: 3 },
  { symptomName: "Chest Pain", conditionName: "Anxiety Disorder", weight: 2 },
  { symptomName: "Shortness of Breath", conditionName: "Anxiety Disorder", weight: 3 },
  { symptomName: "Dizziness", conditionName: "Anxiety Disorder", weight: 3 }
];

async function seedConditionsAndMappings() {
  try {
    console.log('Adding conditions to database...');
    
    // Add all conditions at once
    await Promise.all(commonConditions.map(condition => 
      db.insert(conditions).values(condition).onConflictDoNothing()
    ));
    
    console.log('Condition seeding complete!');
    
    console.log('Getting symptom data...');
    
    // Get all symptoms from database at once
    const allSymptoms = await db.select().from(symptoms);
    const symptomMap = new Map(allSymptoms.map(s => [s.name, s.id]));
    
    console.log('Getting condition data...');
    
    // Get all conditions from database at once
    const allConditions = await db.select().from(conditions);
    const conditionMap = new Map(allConditions.map(c => [c.name, c.id]));
    
    console.log('Creating symptom-condition mappings...');
    
    // Create valid mappings list
    const validMappings = [];
    
    for (const mapping of symptomConditionMappings) {
      const symptomId = symptomMap.get(mapping.symptomName);
      const conditionId = conditionMap.get(mapping.conditionName);
      
      if (!symptomId) {
        console.log(`Symptom ${mapping.symptomName} not found, skipping mapping`);
        continue;
      }
      
      if (!conditionId) {
        console.log(`Condition ${mapping.conditionName} not found, skipping mapping`);
        continue;
      }
      
      validMappings.push({
        symptomId,
        conditionId,
        weight: mapping.weight
      });
    }
    
    console.log(`Found ${validMappings.length} valid mappings to add`);
    
    // Get existing mappings to avoid duplicates
    const existingMappings = await db.select().from(symptomConditions);
    console.log(`Found ${existingMappings.length} existing mappings`);
    
    // Create a map of existing mappings for easy lookup
    const existingMap = new Map();
    for (const mapping of existingMappings) {
      const key = `${mapping.symptomId}-${mapping.conditionId}`;
      existingMap.set(key, true);
    }
    
    // Filter out mappings that already exist
    const newMappings = validMappings.filter(mapping => {
      const key = `${mapping.symptomId}-${mapping.conditionId}`;
      return !existingMap.has(key);
    });
    
    console.log(`Adding ${newMappings.length} new mappings`);
    
    // Add all mappings at once in chunks to avoid overwhelming the database
    const CHUNK_SIZE = 5;
    
    for (let i = 0; i < newMappings.length; i += CHUNK_SIZE) {
      const chunk = newMappings.slice(i, i + CHUNK_SIZE);
      await db.insert(symptomConditions).values(chunk).onConflictDoNothing();
      console.log(`Added mappings ${i+1} to ${Math.min(i+CHUNK_SIZE, newMappings.length)}`);
    }
    
    console.log('Mapping seeding complete!');
    
    // Clean up any duplicate mappings
    console.log('Checking for and removing any duplicate mappings...');
    
    const allMappings = await db.select().from(symptomConditions);
    const uniqueKeys = new Set();
    const duplicates = [];
    
    for (const mapping of allMappings) {
      const key = `${mapping.symptomId}-${mapping.conditionId}`;
      if (uniqueKeys.has(key)) {
        duplicates.push(mapping.id);
      } else {
        uniqueKeys.add(key);
      }
    }
    
    if (duplicates.length > 0) {
      console.log(`Found ${duplicates.length} duplicate mappings, removing...`);
      await db.delete(symptomConditions).where(inArray(symptomConditions.id, duplicates));
      console.log('Duplicates removed');
    } else {
      console.log('No duplicates found');
    }
    
    console.log('Verification complete. Database should now have all required mappings.');
    
  } catch (error) {
    console.error('Error seeding conditions and mappings:', error);
  } finally {
    process.exit(0);
  }
}

seedConditionsAndMappings();