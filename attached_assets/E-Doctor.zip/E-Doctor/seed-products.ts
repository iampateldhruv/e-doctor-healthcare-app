import { medicationProducts } from './server/product-data';
import { supabase } from './server/db';

async function seedProducts() {
  try {
    console.log('Starting product seeding...');
    
    // Clear existing products first
    const { error: deleteError } = await supabase
      .from('products')
      .delete()
      .gte('id', 0);
    
    if (deleteError) {
      console.error('Error clearing products:', deleteError);
      return;
    }
    
    console.log('Existing products cleared');
    
    // Convert camelCase field names to snake_case to match database schema
    const formattedProducts = medicationProducts.map(product => ({
      name: product.name,
      description: product.description,
      price: product.price,
      category: product.category,
      image_url: product.imageUrl,
      requires_prescription: product.requiresPrescription,
      in_stock: product.inStock
    }));
    
    // Insert all products
    const { data, error } = await supabase
      .from('products')
      .insert(formattedProducts)
      .select();
    
    if (error) {
      console.error('Error seeding products:', error);
      return;
    }
    
    console.log(`Successfully seeded ${data.length} products`);
  } catch (error) {
    console.error('Unexpected error during product seeding:', error);
  }
}

// Run the seeding
seedProducts()
  .then(() => console.log('Product seeding completed'))
  .catch(err => console.error('Product seeding failed:', err));