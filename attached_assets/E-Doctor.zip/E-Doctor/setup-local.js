
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('Setting up HealthHubAI for local development...');

// Create data directory
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  console.log('Creating data directory...');
  fs.mkdirSync(dataDir, { recursive: true });
}

// Rename package.json to package-replit.json and package-local.json to package.json
console.log('Setting up package.json for local development...');
if (fs.existsSync(path.join(__dirname, 'package.json'))) {
  fs.renameSync(
    path.join(__dirname, 'package.json'),
    path.join(__dirname, 'package-replit.json')
  );
}

fs.renameSync(
  path.join(__dirname, 'package-local.json'),
  path.join(__dirname, 'package.json')
);

// Install dependencies
console.log('Installing dependencies...');
console.log('This may take a few minutes...');
try {
  execSync('npm install', { stdio: 'inherit' });
  console.log('Dependencies installed successfully!');
} catch (error) {
  console.error('Failed to install dependencies:', error.message);
  process.exit(1);
}

console.log('\n\n===== SETUP COMPLETE =====');
console.log('You can now run the application with:');
console.log('npm run dev');
console.log('\nThe application will be available at http://localhost:5000');
console.log('\nDemo account credentials:');
console.log('- Patient: username: patient1, password: password123');
console.log('- Doctor: username: dr.cardio, password: password123');
console.log('\nFor more information, see README-LOCAL.md');
