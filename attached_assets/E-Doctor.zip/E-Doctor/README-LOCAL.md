# HealthHubAI - Local Setup

This is a guide to run HealthHubAI locally on your machine.

## Prerequisites

Make sure you have the following installed on your computer:

- [Node.js](https://nodejs.org/) (v18 or higher)
- [Visual Studio Code](https://code.visualstudio.com/)

## Setup Instructions

Follow these steps to set up and run the project locally:

### 1. Install Dependencies

Open a terminal in the project root directory and run:

```bash
# First rename package-local.json to package.json
mv package-local.json package.json

# Install all required packages
npm install
```

### 2. Start the Application

```bash
# Start the development server
npm run dev
```

The application will be available at http://localhost:5000

### 3. Using the Application

- The database is automatically initialized with demo users and data
- Login using the following credentials:
  - **Patient Account**: 
    - Username: `patient1`
    - Password: `password123`
  - **Doctor Account**: 
    - Username: `dr.cardio` or `dr.neuro`
    - Password: `password123`

## Database Information

- This application uses SQLite, a file-based database that doesn't require any external database server
- All data is stored in the `data` directory in two files:
  - `healthhubai.db`: Main application data
  - `sessions.db`: User session data

## Important Files

- `server/index-sqlite.ts`: Main server file for local setup
- `server/db-sqlite.ts`: Database connection setup for SQLite
- `server/storage-sqlite.ts`: Data storage implementation for SQLite

## Troubleshooting

- If you encounter issues with the database, try deleting the `data` directory and restarting the application
- Make sure you're using Node.js v18 or higher
- Check console logs for any error messages

## Features

- User authentication (login/registration)
- Doctor profiles and listings
- Symptom checker
- Medical consultation system
- Community health posts
- Medication shop
- Patient medical records