import fetch from 'node-fetch';

// Analyze symptoms function for testing
async function analyzeSymptoms(symptomIds) {
  try {
    console.log('Analyzing symptoms with IDs:', symptomIds);
    
    const response = await fetch('http://localhost:5000/api/symptoms/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ symptomIds }),
    });
    
    if (!response.ok) {
      throw new Error(`Error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    console.log('Analysis response:', JSON.stringify(data, null, 2));
    return data;
  } catch (error) {
    console.error('Analysis failed:', error);
    return { error: error.message };
  }
}

// Run a test with multiple symptom IDs
analyzeSymptoms([1, 2, 3])
  .then(result => {
    console.log('Test completed with result:', result.conditions?.length || 0, 'conditions found');
  })
  .catch(err => {
    console.error('Test failed:', err);
  });