import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import path from 'path';
import { registerRoutes } from './routes';
import { setupVite, serveStatic, log } from './vite';
import session from 'express-session';

// Load environment variables first before importing modules that use them
dotenv.config();

// Check if Supabase credentials are in environment variables
if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
  console.error('Missing Supabase credentials in environment variables');
  process.env.SUPABASE_URL = 'https://oifgojcqkhizhleolcjt.supabase.co';
  process.env.SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc';
  console.log('Set Supabase credentials from hardcoded values');
}

// Now import modules that depend on environment variables
import { storage } from './storage';
import { supabase } from './db';

// Verify Supabase connection
async function verifySupabaseConnection() {
  try {
    console.log('Attempting to connect to Supabase...');
    const { error } = await supabase.from('users').select('count');
    
    if (error) {
      console.error('Supabase query error:', error);
      console.log('----------------------------');
      console.log('IMPORTANT: You need to create the necessary tables in your Supabase database.');
      console.log('The SQL has been saved to supabase-tables.sql for your convenience.');
      console.log('Please run this SQL in your Supabase dashboard to create the tables.');
      console.log('----------------------------');
      throw error;
    }
    
    log('Successfully connected to Supabase!');
    return true;
  } catch (error) {
    console.error('Failed to connect to Supabase:', error);
    return false;
  }
}

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Verify Supabase connection on startup
verifySupabaseConnection().catch(err => {
  console.error('Error checking Supabase connection:', err);
});

// Register API routes and get HTTP server instance
const setupServer = async () => {
  try {
    // Register API routes
    const server = await registerRoutes(app);
    
    // Set up Vite middleware and static file serving for production
    if (process.env.NODE_ENV === 'production') {
      serveStatic(app);
    } else {
      await setupVite(app, server);
    }
    
    // Catch-all route to serve the frontend for client-side routing
    app.get('*', (req, res) => {
      if (process.env.NODE_ENV === 'production') {
        res.sendFile(path.join(__dirname, '../client/dist/index.html'));
      } else {
        res.send('Server is running in development mode');
      }
    });
    
    // Error handling middleware
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      log(`Error: ${err.message}`, 'error');
      res.status(500).json({ message: 'Internal server error' });
    });
    
    // Start the server
    const PORT = parseInt(process.env.PORT || '5000', 10);
    server.listen(PORT, () => {
      log(`Server running on port ${PORT}`);
    });
    
    return server;
  } catch (error) {
    console.error('Failed to set up server:', error);
    process.exit(1);
  }
};

setupServer();