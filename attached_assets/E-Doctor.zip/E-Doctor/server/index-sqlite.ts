import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import path from 'path';
import { registerRoutes } from './routes';
import { setupVite, serveStatic, log } from './vite';
import { storage } from './storage-sqlite';

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize demo data (this is specific to SQLite)
storage.initializeDemoData().catch(err => {
  console.error('Failed to initialize demo data:', err);
});

// Register API routes and get HTTP server instance
const setupServer = async () => {
  try {
    // Register API routes
    const server = await registerRoutes(app);
    
    // Set up Vite middleware and static file serving for production
    // This will serve your React frontend
    if (process.env.NODE_ENV === 'production') {
      serveStatic(app);
    } else {
      await setupVite(app, server);
    }
    
    // Catch-all route to serve the frontend for client-side routing
    app.get('*', (req, res) => {
      if (process.env.NODE_ENV === 'production') {
        res.sendFile(path.join(__dirname, '../client/dist/index.html'));
      } else {
        res.send('Server is running in development mode');
      }
    });
    
    // Error handling middleware
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      log(`Error: ${err.message}`, 'error');
      res.status(500).json({ message: 'Internal server error' });
    });
    
    // Start the server
    const PORT = process.env.PORT || 5000;
    server.listen(PORT, '0.0.0.0', () => {
      log(`Server running on port ${PORT}`);
    });
    
    return server;
  } catch (error) {
    console.error('Failed to set up server:', error);
    process.exit(1);
  }
};

setupServer();