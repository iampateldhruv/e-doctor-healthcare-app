export const additionalSymptoms = [
  { name: "Headache", description: "Pain in the head or upper neck" },
  { name: "Fever", description: "Elevated body temperature" },
  { name: "Cough", description: "Sudden expulsion of air from the lungs" },
  { name: "Fatigue", description: "Extreme tiredness resulting from mental or physical exertion" },
  { name: "Nausea", description: "Feeling of sickness with an inclination to vomit" },
  { name: "Dizziness", description: "Lightheadedness, feeling faint or unsteady" },
  { name: "Chest Pain", description: "Pain or discomfort in the chest area" },
  { name: "Shortness of Breath", description: "Difficulty breathing or catching your breath" },
  { name: "Sore Throat", description: "Pain or irritation in the throat" },
  { name: "Runny Nose", description: "Mucus discharge from the nose" },
  { name: "Muscle Aches", description: "Pain or soreness in muscles" },
  { name: "Joint Pain", description: "Discomfort or pain in joints" },
  { name: "Abdominal Pain", description: "Pain in the area between the chest and pelvis" },
  { name: "Vomiting", description: "Forceful expulsion of stomach contents" },
  { name: "Diarrhea", description: "Loose, watery bowel movements" },
  { name: "Rash", description: "Area of irritated or swollen skin" },
  { name: "Sneezing", description: "Sudden, forceful, involuntary expulsion of air through the nose and mouth" },
  { name: "Blurred Vision", description: "Lack of sharpness of vision resulting in the inability to see fine detail" },
  { name: "Loss of Appetite", description: "Decreased desire to eat" },
  { name: "Chills", description: "Feeling of cold with shivering" },
  { name: "Sweating", description: "Excessive perspiration" },
  { name: "Back Pain", description: "Pain in the back area" },
  { name: "Insomnia", description: "Difficulty falling or staying asleep" },
  { name: "Anxiety", description: "Feeling of worry, nervousness, or unease" }
];

export const symptomConditionMappings = [
  // Common Cold
  { symptomName: "Headache", conditionName: "Common Cold", weight: 2 },
  { symptomName: "Fever", conditionName: "Common Cold", weight: 3 },
  { symptomName: "Cough", conditionName: "Common Cold", weight: 4 },
  { symptomName: "Sore Throat", conditionName: "Common Cold", weight: 4 },
  { symptomName: "Runny Nose", conditionName: "Common Cold", weight: 5 },
  { symptomName: "Sneezing", conditionName: "Common Cold", weight: 5 },
  { symptomName: "Fatigue", conditionName: "Common Cold", weight: 2 },
  
  // Influenza
  { symptomName: "Headache", conditionName: "Influenza", weight: 3 },
  { symptomName: "Fever", conditionName: "Influenza", weight: 5 },
  { symptomName: "Fatigue", conditionName: "Influenza", weight: 4 },
  { symptomName: "Cough", conditionName: "Influenza", weight: 4 },
  { symptomName: "Muscle Aches", conditionName: "Influenza", weight: 5 },
  { symptomName: "Chills", conditionName: "Influenza", weight: 4 },
  { symptomName: "Sore Throat", conditionName: "Influenza", weight: 3 },
  { symptomName: "Sweating", conditionName: "Influenza", weight: 3 },
  
  // Migraine
  { symptomName: "Headache", conditionName: "Migraine", weight: 5 },
  { symptomName: "Nausea", conditionName: "Migraine", weight: 3 },
  { symptomName: "Dizziness", conditionName: "Migraine", weight: 3 },
  { symptomName: "Blurred Vision", conditionName: "Migraine", weight: 4 },
  { symptomName: "Fatigue", conditionName: "Migraine", weight: 2 },
  
  // Hypertension
  { symptomName: "Chest Pain", conditionName: "Hypertension", weight: 4 },
  { symptomName: "Headache", conditionName: "Hypertension", weight: 3 },
  { symptomName: "Dizziness", conditionName: "Hypertension", weight: 3 },
  { symptomName: "Shortness of Breath", conditionName: "Hypertension", weight: 2 },
  { symptomName: "Fatigue", conditionName: "Hypertension", weight: 2 },
  
  // Anxiety Disorder
  { symptomName: "Fatigue", conditionName: "Anxiety Disorder", weight: 3 },
  { symptomName: "Chest Pain", conditionName: "Anxiety Disorder", weight: 2 },
  { symptomName: "Shortness of Breath", conditionName: "Anxiety Disorder", weight: 3 },
  { symptomName: "Dizziness", conditionName: "Anxiety Disorder", weight: 3 },
  { symptomName: "Anxiety", conditionName: "Anxiety Disorder", weight: 5 },
  { symptomName: "Insomnia", conditionName: "Anxiety Disorder", weight: 4 },
  { symptomName: "Sweating", conditionName: "Anxiety Disorder", weight: 2 }
];

export const conditionData = [
  { name: "Common Cold", description: "A viral infectious disease of the upper respiratory tract", specialization: "General Medicine" },
  { name: "Influenza", description: "Contagious respiratory illness caused by influenza viruses", specialization: "General Medicine" },
  { name: "Migraine", description: "Recurrent moderate to severe headaches", specialization: "Neurology" },
  { name: "Hypertension", description: "Persistently elevated blood pressure in the arteries", specialization: "Cardiology" },
  { name: "Anxiety Disorder", description: "Mental health condition characterized by feelings of worry or fear", specialization: "Psychiatry" }
];