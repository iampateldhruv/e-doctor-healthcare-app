import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';
import * as schema from '../shared/schema';
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';
import path from 'path';
import fs from 'fs';

// Ensure the data directory exists
const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Connect to SQLite database
const sqlite = new Database(path.join(dataDir, 'healthhubai.db'));

// Create drizzle database instance
export const db = drizzle(sqlite, { schema });

// Auto-migrate the schema
try {
  // This doesn't perform real migrations, but it will automatically 
  // create tables based on your schema
  db.run(`PRAGMA foreign_keys = ON`);
  
  // Create your tables here
  console.log('Ensuring database tables are created...');
  
  // Users table
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      role TEXT DEFAULT 'patient',
      profile_picture TEXT,
      specialization TEXT,
      experience INTEGER,
      bio TEXT,
      location TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
  
  // Symptoms table
  db.run(`
    CREATE TABLE IF NOT EXISTS symptoms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT
    )
  `);
  
  // Conditions table
  db.run(`
    CREATE TABLE IF NOT EXISTS conditions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      specialization TEXT
    )
  `);
  
  // Symptom-Condition mappings table
  db.run(`
    CREATE TABLE IF NOT EXISTS symptom_conditions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      symptomId INTEGER NOT NULL,
      conditionId INTEGER NOT NULL,
      weight INTEGER DEFAULT 1,
      FOREIGN KEY (symptomId) REFERENCES symptoms(id),
      FOREIGN KEY (conditionId) REFERENCES conditions(id),
      UNIQUE(symptomId, conditionId)
    )
  `);
  
  // Medical records table
  db.run(`
    CREATE TABLE IF NOT EXISTS medical_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patientId INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      type TEXT,
      fileUrl TEXT,
      date TEXT,
      FOREIGN KEY (patientId) REFERENCES users(id)
    )
  `);
  
  // Consultations table
  db.run(`
    CREATE TABLE IF NOT EXISTS consultations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patientId INTEGER NOT NULL,
      doctorId INTEGER NOT NULL,
      status TEXT DEFAULT 'pending',
      symptoms TEXT,
      diagnosis TEXT,
      notes TEXT,
      scheduledAt TEXT,
      createdAt TEXT,
      FOREIGN KEY (patientId) REFERENCES users(id),
      FOREIGN KEY (doctorId) REFERENCES users(id)
    )
  `);
  
  // Messages table
  db.run(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      consultationId INTEGER NOT NULL,
      senderId INTEGER NOT NULL,
      content TEXT NOT NULL,
      read BOOLEAN DEFAULT 0,
      sentAt TEXT,
      FOREIGN KEY (consultationId) REFERENCES consultations(id),
      FOREIGN KEY (senderId) REFERENCES users(id)
    )
  `);
  
  // Products table
  db.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      price REAL NOT NULL,
      imageUrl TEXT,
      category TEXT,
      stock INTEGER DEFAULT 0
    )
  `);
  
  // Orders table
  db.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      status TEXT DEFAULT 'pending',
      total REAL NOT NULL,
      address TEXT,
      createdAt TEXT,
      FOREIGN KEY (userId) REFERENCES users(id)
    )
  `);
  
  // Order items table
  db.run(`
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orderId INTEGER NOT NULL,
      productId INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      price REAL NOT NULL,
      FOREIGN KEY (orderId) REFERENCES orders(id),
      FOREIGN KEY (productId) REFERENCES products(id)
    )
  `);
  
  // Posts table
  db.run(`
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      imageUrl TEXT,
      likes INTEGER DEFAULT 0,
      comments INTEGER DEFAULT 0,
      tags TEXT,
      createdAt TEXT,
      FOREIGN KEY (userId) REFERENCES users(id)
    )
  `);
  
  // Comments table
  db.run(`
    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      postId INTEGER NOT NULL,
      userId INTEGER NOT NULL,
      content TEXT NOT NULL,
      createdAt TEXT,
      FOREIGN KEY (postId) REFERENCES posts(id),
      FOREIGN KEY (userId) REFERENCES users(id)
    )
  `);
  
  console.log('Database tables created successfully');
} catch (error) {
  console.error('Error setting up database:', error);
}