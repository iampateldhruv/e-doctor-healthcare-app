
import { supabase } from './db';

async function initDatabase() {
  try {
    // Users table
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'users',
      definition: `
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        fullName TEXT NOT NULL,
        role TEXT DEFAULT 'patient',
        profilePicture TEXT,
        specialization TEXT,
        experience INTEGER,
        rating REAL,
        reviewCount INTEGER,
        verified BOOLEAN,
        bio TEXT,
        location TEXT,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      `
    });

    // Medical records table
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'medical_records',
      definition: `
        id SERIAL PRIMARY KEY,
        type TEXT NOT NULL,
        patientId INTEGER NOT NULL REFERENCES users(id),
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        fileUrl TEXT,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      `
    });

    // Symptoms table
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'symptoms',
      definition: `
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT
      `
    });

    // Conditions table
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'conditions',
      definition: `
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT NOT NULL,
        specialization TEXT NOT NULL
      `
    });

    // Symptom-Condition mappings
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'symptom_conditions',
      definition: `
        id SERIAL PRIMARY KEY,
        symptomId INTEGER NOT NULL REFERENCES symptoms(id),
        conditionId INTEGER NOT NULL REFERENCES conditions(id),
        weight INTEGER
      `
    });

    // Products table
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'products',
      definition: `
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        price REAL NOT NULL,
        category TEXT NOT NULL,
        imageUrl TEXT,
        requiresPrescription BOOLEAN,
        inStock BOOLEAN
      `
    });

    // Orders table
    await supabase.rpc('create_table_if_not_exists', {
      table_name: 'orders',
      definition: `
        id SERIAL PRIMARY KEY,
        userId INTEGER NOT NULL REFERENCES users(id),
        total REAL NOT NULL,
        address TEXT NOT NULL,
        status TEXT NOT NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      `
    });

    console.log('Database tables created successfully');
  } catch (error) {
    console.error('Error creating tables:', error);
  }
}

initDatabase();
