import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, '../uploads');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  })
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes (login, register, logout, etc)
  setupAuth(app);
  
  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send password in response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get all doctors
  app.get("/api/doctors", async (req, res) => {
    try {
      const specialization = req.query.specialization as string | undefined;
      const doctors = await storage.getDoctors(specialization);
      res.json(doctors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch doctors" });
    }
  });

  // Get doctor by ID
  app.get("/api/doctors/:id", async (req, res) => {
    try {
      const doctor = await storage.getUser(parseInt(req.params.id));
      if (!doctor || doctor.role !== "doctor") {
        return res.status(404).json({ message: "Doctor not found" });
      }
      res.json(doctor);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch doctor" });
    }
  });

  // Get symptoms
  app.get("/api/symptoms", async (req, res) => {
    try {
      const symptoms = await storage.getSymptoms();
      res.json(symptoms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch symptoms" });
    }
  });
  
  // Get conditions
  app.get("/api/conditions", async (req, res) => {
    try {
      const specialization = req.query.specialization as string | undefined;
      const conditions = specialization 
        ? await storage.getConditionsBySpecialization(specialization)
        : await storage.getConditions();
      res.json(conditions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conditions" });
    }
  });

  // Analyze symptoms
  app.post("/api/symptoms/analyze", async (req, res) => {
    try {
      const { symptomIds } = req.body;
      if (!Array.isArray(symptomIds) || symptomIds.length === 0) {
        return res.status(400).json({ message: "Invalid symptoms provided" });
      }

      console.log("Analyzing symptoms with IDs:", symptomIds);
      
      // Get conditions based on selected symptoms
      let potentialConditions = [];
      try {
        potentialConditions = await storage.getConditionsBySymptoms(symptomIds);
        console.log("Found conditions:", potentialConditions.length);
      } catch (conditionError) {
        console.error("Error getting conditions:", conditionError);
        // Continue with empty conditions instead of failing completely
      }
      
      // Get full symptom details
      let symptoms = [];
      try {
        const symptomPromises = symptomIds.map(id => storage.getSymptom(id));
        const symptomResults = await Promise.all(symptomPromises);
        symptoms = symptomResults.filter(s => s !== undefined);
        console.log("Found symptoms:", symptoms.length);
      } catch (symptomError) {
        console.error("Error getting symptoms:", symptomError);
        // Continue with empty symptoms instead of failing completely
      }
      
      // Return results - even if one part fails, we return what we have
      res.json({
        conditions: potentialConditions || [],
        symptoms: symptoms || []
      });
    } catch (error) {
      console.error("Error analyzing symptoms:", error);
      res.status(500).json({ message: "Failed to analyze symptoms", error: error.message });
    }
  });

  // Upload medical record
  app.post("/api/medical-records", upload.single('file'), async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const { title, description, type } = req.body;
      const fileUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
      
      const medicalRecord = await storage.createMedicalRecord({
        patientId: req.user.id,
        title,
        description,
        type,
        fileUrl
      });
      
      res.status(201).json(medicalRecord);
    } catch (error) {
      res.status(500).json({ message: "Failed to create medical record" });
    }
  });

  // Get user's medical records
  app.get("/api/medical-records", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const records = await storage.getMedicalRecordsByPatient(req.user.id);
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch medical records" });
    }
  });

  // Create consultation
  app.post("/api/consultations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const { doctorId, scheduledAt, symptoms, notes } = req.body;
      
      if (!doctorId) {
        return res.status(400).json({ message: "Doctor ID is required" });
      }

      if (!scheduledAt) {
        return res.status(400).json({ message: "Scheduled time is required" });
      }

      // Verify doctor exists
      const doctor = await storage.getUser(parseInt(doctorId));
      if (!doctor || doctor.role !== "doctor") {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      // Parse and validate date
      const scheduledDate = new Date(scheduledAt);
      if (isNaN(scheduledDate.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }

      const consultation = await storage.createConsultation({
        patientId: req.user.id,
        doctorId: parseInt(doctorId),
        scheduledAt: scheduledDate,
        symptoms: symptoms || [],
        notes: notes || "",
        status: "scheduled"
      });
      
      res.status(201).json(consultation);
    } catch (error) {
      console.error("Consultation creation error:", error);
      res.status(500).json({ message: "Failed to create consultation", error: error.message });
    }
  });

  // Get consultations for current user
  app.get("/api/consultations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      let consultations;
      if (req.user.role === "patient") {
        consultations = await storage.getConsultationsByPatient(req.user.id);
      } else if (req.user.role === "doctor") {
        consultations = await storage.getConsultationsByDoctor(req.user.id);
      } else {
        return res.status(403).json({ message: "Unauthorized role" });
      }
      
      res.json(consultations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch consultations" });
    }
  });

  // Get specific consultation
  app.get("/api/consultations/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const consultationId = parseInt(req.params.id);
      const consultation = await storage.getConsultation(consultationId);
      
      if (!consultation) {
        return res.status(404).json({ message: "Consultation not found" });
      }
      
      // Only allow access if user is the patient or doctor for this consultation
      if (consultation.patientId !== req.user.id && consultation.doctorId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access" });
      }
      
      res.json(consultation);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch consultation" });
    }
  });

  // Update consultation
  app.patch("/api/consultations/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const consultationId = parseInt(req.params.id);
      const consultation = await storage.getConsultation(consultationId);
      
      if (!consultation) {
        return res.status(404).json({ message: "Consultation not found" });
      }
      
      // Only allow access if user is the patient or doctor for this consultation
      if (consultation.patientId !== req.user.id && consultation.doctorId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access" });
      }
      
      const { status, diagnosis, scheduledAt, notes } = req.body;
      const updatedConsultation = await storage.updateConsultation(consultationId, {
        status,
        diagnosis,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : undefined,
        notes
      });
      
      res.json(updatedConsultation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update consultation" });
    }
  });

  // Get messages for a consultation
  app.get("/api/consultations/:id/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const consultationId = parseInt(req.params.id);
      const consultation = await storage.getConsultation(consultationId);
      
      if (!consultation) {
        return res.status(404).json({ message: "Consultation not found" });
      }
      
      // Only allow access if user is the patient or doctor for this consultation
      if (consultation.patientId !== req.user.id && consultation.doctorId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access" });
      }
      
      try {
        console.log('Fetching messages for consultation:', consultationId);
        const messages = await storage.getMessagesByConsultation(consultationId);
        console.log('Found messages:', messages);
        
        // Mark messages as read
        await storage.markMessagesAsRead(consultationId, req.user.id);
        
        res.json(messages);
      } catch (error) {
        console.error('Error fetching messages:', error);
        res.status(500).json({ message: "Failed to fetch messages", error: error.message });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send message in a consultation
  app.post("/api/consultations/:id/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const consultationId = parseInt(req.params.id);
      const consultation = await storage.getConsultation(consultationId);
      
      if (!consultation) {
        return res.status(404).json({ message: "Consultation not found" });
      }
      
      // Only allow access if user is the patient or doctor for this consultation
      if (consultation.patientId !== req.user.id && consultation.doctorId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access" });
      }
      
      const { content } = req.body;
      if (!content || content.trim().length === 0) {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      const message = await storage.createMessage({
        consultationId,
        senderId: req.user.id,
        content
      });
      
      res.status(201).json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const products = await storage.getProducts(category);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get product by ID
  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(parseInt(req.params.id));
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Create order
  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const { items, total, address } = req.body;
      
      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ message: "No items provided" });
      }
      
      // Create order
      const order = await storage.createOrder({
        userId: req.user.id,
        status: "pending",
        total,
        address
      });
      
      // Add order items
      for (const item of items) {
        await storage.createOrderItem({
          orderId: order.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price
        });
      }
      
      res.status(201).json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  // Get user's orders
  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const orders = await storage.getOrdersByUser(req.user.id);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Get specific order with items
  app.get("/api/orders/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Only allow access to the user's own orders
      if (order.userId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized access" });
      }
      
      const items = await storage.getOrderItems(orderId);
      
      // Get product details for each item
      const itemsWithProducts = await Promise.all(
        items.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return { ...item, product };
        })
      );
      
      res.json({ ...order, items: itemsWithProducts });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  // Get community posts
  app.get("/api/posts", async (req, res) => {
    try {
      const tag = req.query.tag as string | undefined;
      const posts = await storage.getPosts(tag);
      
      // Get author details for each post
      const postsWithAuthors = await Promise.all(
        posts.map(async (post) => {
          const author = await storage.getUser(post.userId);
          return { ...post, author };
        })
      );
      
      res.json(postsWithAuthors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  // Get post by ID with comments
  app.get("/api/posts/:id", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const author = await storage.getUser(post.userId);
      const comments = await storage.getCommentsByPost(postId);
      
      // Get comment authors
      const commentsWithAuthors = await Promise.all(
        comments.map(async (comment) => {
          const commentAuthor = await storage.getUser(comment.userId);
          return { ...comment, author: commentAuthor };
        })
      );
      
      res.json({ ...post, author, comments: commentsWithAuthors });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  // Create post
  app.post("/api/posts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      // Only doctors can create posts in the community
      if (req.user.role !== "doctor") {
        return res.status(403).json({ message: "Only doctors can create posts" });
      }
      
      const { title, content, imageUrl, tags } = req.body;
      
      if (!title || !content) {
        return res.status(400).json({ message: "Title and content are required" });
      }
      
      const post = await storage.createPost({
        userId: req.user.id,
        title,
        content,
        imageUrl,
        tags
      });
      
      res.status(201).json(post);
    } catch (error) {
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  // Add comment to post
  app.post("/api/posts/:id/comments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const { content } = req.body;
      
      if (!content || content.trim().length === 0) {
        return res.status(400).json({ message: "Comment content is required" });
      }
      
      const comment = await storage.createComment({
        postId,
        userId: req.user.id,
        content
      });
      
      const author = await storage.getUser(comment.userId);
      
      res.status(201).json({ ...comment, author });
    } catch (error) {
      res.status(500).json({ message: "Failed to add comment" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
