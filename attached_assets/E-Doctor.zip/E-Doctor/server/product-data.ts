import { InsertProduct } from "@shared/schema";

export const medicationProducts: InsertProduct[] = [
  // Prescription Medications
  {
    name: "Lisinopril 10mg",
    description: "ACE inhibitor used to treat high blood pressure and heart failure.",
    price: 1499,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_15573.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Atorvastatin 20mg",
    description: "Statin medication used to treat high cholesterol and reduce the risk of heart disease.",
    price: 1899,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/tms/Package_17306.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Levothyroxine 50mcg",
    description: "Thyroid hormone used to treat hypothyroidism and thyroid hormone deficiency.",
    price: 1299,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/DrugItem_19292.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Metformin 500mg",
    description: "Oral diabetes medication that helps control blood sugar levels in type 2 diabetes.",
    price: 999,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_5358.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Amlodipine 5mg",
    description: "Calcium channel blocker used to treat high blood pressure and chest pain (angina).",
    price: 1399,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_10480.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Omeprazole 20mg",
    description: "Proton pump inhibitor used to treat acid reflux and stomach ulcers.",
    price: 1599,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_13674.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Sertraline 50mg",
    description: "Selective serotonin reuptake inhibitor (SSRI) used to treat depression and anxiety disorders.",
    price: 1799,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_11285.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Losartan 50mg",
    description: "Angiotensin II receptor blocker used to treat high blood pressure and protect kidneys in diabetes.",
    price: 1699,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_11074.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Albuterol Inhaler",
    description: "Bronchodilator used to treat or prevent bronchospasm in asthma and COPD.",
    price: 2499,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/Package_19894.PNG",
    requiresPrescription: true,
    inStock: true
  },
  {
    name: "Gabapentin 300mg",
    description: "Anticonvulsant used to treat seizures, nerve pain, and restless legs syndrome.",
    price: 1499,
    category: "Prescription Meds",
    imageUrl: "https://www.grxstatic.com/d4fuqqd5l3dbz/products/cwf_tms/DrugItem_11723.PNG",
    requiresPrescription: true,
    inStock: true
  },

  // Vitamins & Supplements
  {
    name: "Multivitamin Daily",
    description: "Complete daily multivitamin with essential vitamins and minerals for overall health.",
    price: 1299,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1577196592050-d17ea52ff0f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Vitamin D3 2000 IU",
    description: "Supports bone health, immune function, and calcium absorption.",
    price: 1099,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1585435557343-3b92fbf0d815?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Omega-3 Fish Oil",
    description: "Supports heart health, brain function, and reduces inflammation.",
    price: 1599,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1583512603784-a8e3ea8355b4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Calcium + Vitamin D",
    description: "Supports bone health and muscle function.",
    price: 1399,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1616109748085-3a2cad402df3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Probiotics 10 Billion CFU",
    description: "Supports digestive health and immune function with beneficial bacteria.",
    price: 1899,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1607216719798-803f1df8cf75?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Magnesium 400mg",
    description: "Supports muscle and nerve function, energy production, and sleep quality.",
    price: 1199,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1610971309474-abb401cp7eef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Vitamin C 1000mg",
    description: "Supports immune function, collagen production, and acts as an antioxidant.",
    price: 999,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1616109748085-3a2cad402df3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "B Complex",
    description: "Supports energy metabolism, nervous system function, and cell health.",
    price: 1499,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1577196592050-d17ea52ff0f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Iron 65mg",
    description: "Essential for blood production and oxygen transport in the body.",
    price: 1099,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Zinc 50mg",
    description: "Supports immune function, wound healing, and cellular metabolism.",
    price: 999,
    category: "Vitamins & Supplements",
    imageUrl: "https://images.unsplash.com/photo-1616109748085-3a2cad402df3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // Personal Care
  {
    name: "Moisturizing Face Wash",
    description: "Gentle cleansing with added moisture for all skin types.",
    price: 1299,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1556228720-195a672e8a03?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Sunscreen SPF 50",
    description: "Broad spectrum protection against UVA and UVB rays.",
    price: 1599,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1521223619319-4240b138e9c8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Anti-Dandruff Shampoo",
    description: "Clinically proven to reduce dandruff and relieve scalp irritation.",
    price: 1399,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1626722569836-4a8a041242d9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Moisturizing Body Lotion",
    description: "24-hour hydration for dry and sensitive skin.",
    price: 1199,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1611080541598-9b71d66bbf38?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Dental Floss Pack",
    description: "Effective plaque removal between teeth for better oral health.",
    price: 599,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1556156653-e5a7c26222c8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Electric Toothbrush",
    description: "Advanced cleaning technology for superior plaque removal.",
    price: 4999,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1631729322787-63484e77d968?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Facial Moisturizer",
    description: "Hydrates and protects skin with SPF 15 and essential nutrients.",
    price: 1899,
    category: "Personal Care",
    imageUrl: "https://images.unsplash.com/photo-1613013261832-a5d86dba9421?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // Health Devices
  {
    name: "Digital Blood Pressure Monitor",
    description: "Accurate home monitoring of blood pressure with easy-to-read display.",
    price: 4999,
    category: "Health Devices",
    imageUrl: "https://images.unsplash.com/photo-1632752898897-ab5261ef2e75?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Glucose Monitor Kit",
    description: "Complete kit for monitoring blood glucose levels at home.",
    price: 5999,
    category: "Health Devices",
    imageUrl: "https://images.unsplash.com/photo-1623000250907-8bd6df5d3728?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Digital Thermometer",
    description: "Fast and accurate temperature readings with memory function.",
    price: 1999,
    category: "Health Devices",
    imageUrl: "https://images.unsplash.com/photo-1588776970644-a5817f739d79?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Pulse Oximeter",
    description: "Measures blood oxygen saturation levels and pulse rate.",
    price: 3499,
    category: "Health Devices",
    imageUrl: "https://images.unsplash.com/photo-1603816452977-933a93af3869?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "TENS Unit for Pain Relief",
    description: "Non-invasive pain management device using electrical nerve stimulation.",
    price: 4499,
    category: "Health Devices",
    imageUrl: "https://images.unsplash.com/photo-1581595219315-a187dd40c322?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Peak Flow Meter",
    description: "Measures how well air moves out of lungs, useful for asthma management.",
    price: 2499,
    category: "Health Devices",
    imageUrl: "https://images.unsplash.com/photo-1583912267636-c2810fee366e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // First Aid
  {
    name: "Complete First Aid Kit",
    description: "Comprehensive kit with essential supplies for emergency treatment.",
    price: 2999,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1665670369706-3c88f55ab772?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Adhesive Bandages Variety Pack",
    description: "Assorted sizes of sterile bandages for minor cuts and scrapes.",
    price: 899,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1584308878768-82647b0ae4bf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Antiseptic Wipes",
    description: "Individual alcohol wipes for cleaning wounds and preventing infection.",
    price: 599,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1582547300604-b4d45734a67a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Medical Tape Roll",
    description: "Hypoallergenic tape for securing bandages and dressings.",
    price: 499,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1550831858-3c2581fed470?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Elastic Bandage Wrap",
    description: "Provides compression and support for sprains and strains.",
    price: 899,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1585435421671-0c16737a238a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Emergency Thermal Blanket",
    description: "Reflects and retains body heat in emergency situations.",
    price: 699,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1554331643-18a04a3e2fcb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "CPR Face Shield",
    description: "Barrier device for safer CPR administration.",
    price: 799,
    category: "First Aid",
    imageUrl: "https://images.unsplash.com/photo-1603398920254-2425989432f9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // Over-the-counter Medications
  {
    name: "Acetaminophen 500mg",
    description: "Pain reliever and fever reducer for headaches, muscle aches, and minor pain.",
    price: 899,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Ibuprofen 200mg",
    description: "Anti-inflammatory pain reliever for headaches, minor arthritis, and fever reduction.",
    price: 999,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1626516438856-5cdeab260c80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Aspirin 325mg",
    description: "Pain reliever, fever reducer, and anti-inflammatory medication.",
    price: 799,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Naproxen Sodium 220mg",
    description: "Long-lasting pain reliever for minor aches and pains with anti-inflammatory properties.",
    price: 1099,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1550572017-13225088df82?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Diphenhydramine 25mg",
    description: "Antihistamine for allergy relief and as a sleep aid.",
    price: 899,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1550572017-13225088df82?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Loratadine 10mg",
    description: "24-hour non-drowsy antihistamine for allergy relief.",
    price: 1299,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1585435557343-3b92fbf0d815?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Cetirizine 10mg",
    description: "24-hour allergy relief from indoor and outdoor allergens.",
    price: 1199,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1577196592050-d17ea52ff0f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Famotidine 20mg",
    description: "Acid reducer for heartburn relief and acid indigestion.",
    price: 999,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1550572017-13225088df82?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Antacid Chewable Tablets",
    description: "Fast-acting relief for heartburn, acid indigestion, and sour stomach.",
    price: 699,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1626516438856-5cdeab260c80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Hydrocortisone Cream 1%",
    description: "Anti-itch cream for temporary relief of minor skin irritations and rashes.",
    price: 899,
    category: "Over-the-counter",
    imageUrl: "https://images.unsplash.com/photo-1611080541598-9b71d66bbf38?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // Digestive Health
  {
    name: "Probiotic Daily Capsules",
    description: "Supports digestive health and immune function with beneficial bacteria.",
    price: 1999,
    category: "Digestive Health",
    imageUrl: "https://images.unsplash.com/photo-1607216719798-803f1df8cf75?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Fiber Supplement Powder",
    description: "Promotes regularity and supports digestive health with natural fiber.",
    price: 1799,
    category: "Digestive Health",
    imageUrl: "https://images.unsplash.com/photo-1583513702439-2e611c58e93d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Loperamide 2mg",
    description: "Anti-diarrheal medication for fast relief of diarrhea symptoms.",
    price: 899,
    category: "Digestive Health",
    imageUrl: "https://images.unsplash.com/photo-1550572017-13225088df82?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Digestive Enzyme Tablets",
    description: "Supports digestion and nutrient absorption, especially for heavy meals.",
    price: 1499,
    category: "Digestive Health",
    imageUrl: "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Gas Relief Softgels",
    description: "Fast relief from painful pressure, bloating, and discomfort of excess gas.",
    price: 999,
    category: "Digestive Health",
    imageUrl: "https://images.unsplash.com/photo-1585435557343-3b92fbf0d815?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // Respiratory Health
  {
    name: "Cough Suppressant Syrup",
    description: "Controls cough due to minor throat and bronchial irritation.",
    price: 1299,
    category: "Respiratory Health",
    imageUrl: "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Nasal Decongestant Spray",
    description: "Provides temporary relief of nasal congestion due to colds or allergies.",
    price: 1099,
    category: "Respiratory Health",
    imageUrl: "https://images.unsplash.com/photo-1613613428185-9096c1d1tedd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Chest Rub Ointment",
    description: "Provides temporary relief of nasal congestion and coughs associated with colds.",
    price: 999,
    category: "Respiratory Health",
    imageUrl: "https://images.unsplash.com/photo-1611080541598-9b71d66bbf38?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Throat Lozenges",
    description: "Temporarily relieves sore throat pain and cough associated with colds.",
    price: 699,
    category: "Respiratory Health",
    imageUrl: "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Expectorant Tablets",
    description: "Helps loosen phlegm and thin bronchial secretions to make coughs more productive.",
    price: 1199,
    category: "Respiratory Health",
    imageUrl: "https://images.unsplash.com/photo-1626516438856-5cdeab260c80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },

  // Sleep and Stress
  {
    name: "Melatonin 5mg",
    description: "Promotes better sleep and regulates sleep cycle, especially for jet lag.",
    price: 1399,
    category: "Sleep and Stress",
    imageUrl: "https://images.unsplash.com/photo-1611079859244-a1f473d9397c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Nighttime Sleep Aid",
    description: "Helps reduce difficulty falling asleep for a better night's rest.",
    price: 1299,
    category: "Sleep and Stress",
    imageUrl: "https://images.unsplash.com/photo-1585435557343-3b92fbf0d815?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Chamomile Tea",
    description: "Natural herbal tea that promotes relaxation and better sleep quality.",
    price: 899,
    category: "Sleep and Stress",
    imageUrl: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Stress Relief Supplement",
    description: "Blend of herbs and nutrients that help the body adapt to stress.",
    price: 1699,
    category: "Sleep and Stress",
    imageUrl: "https://images.unsplash.com/photo-1607216719798-803f1df8cf75?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
  {
    name: "Lavender Essential Oil",
    description: "Aromatherapy oil known for its calming and relaxing properties.",
    price: 1599,
    category: "Sleep and Stress",
    imageUrl: "https://images.unsplash.com/photo-1547211453-2788d17d77ed?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
    requiresPrescription: false,
    inStock: true
  },
];