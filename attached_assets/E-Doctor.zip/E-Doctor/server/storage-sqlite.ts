import { db } from './db-sqlite';
import { 
  users, insertUserSchema, User, InsertUser,
  medicalRecords, MedicalRecord, InsertMedicalRecord,
  symptoms, Symptom, InsertSymptom,
  conditions, Condition, InsertCondition,
  symptomConditions, SymptomCondition, InsertSymptomCondition,
  consultations, Consultation, InsertConsultation,
  messages, Message, InsertMessage,
  products, Product, InsertProduct,
  orders, Order, InsertOrder,
  orderItems, OrderItem, InsertOrderItem,
  posts, Post, InsertPost,
  comments, Comment, InsertComment
} from '../shared/schema';
import { eq, inArray, desc, asc, and, sql } from 'drizzle-orm';
import { medicationProducts } from './product-data';
import { additionalSymptoms, symptomConditionMappings, conditionData } from './symptom-data';
import session from 'express-session';
import path from 'path';
import fs from 'fs';
import SQLiteStore from 'better-sqlite3-session-store';
import BetterSqlite3 from 'better-sqlite3';

// Ensure the data directory exists
const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Create SQLite session store
const SqliteStore = SQLiteStore(session);
const sessionDb = new BetterSqlite3(path.join(dataDir, 'sessions.db'));

// Create timestamp string for current date & time in ISO format
const timestamp = () => new Date().toISOString();

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getDoctors(specialization?: string): Promise<User[]>;
  
  // Medical records operations
  getMedicalRecordsByPatient(patientId: number): Promise<MedicalRecord[]>;
  getMedicalRecord(id: number): Promise<MedicalRecord | undefined>;
  createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord>;
  
  // Symptom operations
  getSymptoms(): Promise<Symptom[]>;
  getSymptom(id: number): Promise<Symptom | undefined>;
  getSymptomByName(name: string): Promise<Symptom | undefined>;
  createSymptom(symptom: InsertSymptom): Promise<Symptom>;
  
  // Condition operations
  getConditions(): Promise<Condition[]>;
  getCondition(id: number): Promise<Condition | undefined>;
  getConditionsBySpecialization(specialization: string): Promise<Condition[]>;
  createCondition(condition: InsertCondition): Promise<Condition>;
  
  // Symptom-Condition mapping operations
  getSymptomConditions(): Promise<SymptomCondition[]>;
  createSymptomCondition(mapping: InsertSymptomCondition): Promise<SymptomCondition>;
  getConditionsBySymptoms(symptomIds: number[]): Promise<{condition: Condition, score: number}[]>;
  
  // Consultation operations
  getConsultation(id: number): Promise<Consultation | undefined>;
  getConsultationsByPatient(patientId: number): Promise<Consultation[]>;
  getConsultationsByDoctor(doctorId: number): Promise<Consultation[]>;
  createConsultation(consultation: InsertConsultation): Promise<Consultation>;
  updateConsultation(id: number, data: Partial<Consultation>): Promise<Consultation | undefined>;
  
  // Message operations
  getMessagesByConsultation(consultationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessagesAsRead(consultationId: number, userId: number): Promise<void>;
  
  // Product operations
  getProducts(category?: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined>;
  
  // Order items operations
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  
  // Post operations
  getPosts(tag?: string): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  getPostsByUser(userId: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePostStats(id: number, likes?: number, comments?: number): Promise<Post | undefined>;
  
  // Comment operations
  getCommentsByPost(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Session store
  sessionStore: session.Store;
  
  // Initialization
  initializeDemoData(): Promise<void>;
}

export class SQLiteStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Initialize session store
    this.sessionStore = new SqliteStore({
      client: sessionDb,
      expired: {
        clear: true,
        intervalMs: 900000 // 15 minutes
      }
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getDoctors(specialization?: string): Promise<User[]> {
    if (specialization) {
      return db.select().from(users)
        .where(and(
          eq(users.role, 'doctor'),
          eq(users.specialization, specialization)
        ));
    }
    return db.select().from(users).where(eq(users.role, 'doctor'));
  }

  // Medical records operations
  async getMedicalRecordsByPatient(patientId: number): Promise<MedicalRecord[]> {
    return db.select().from(medicalRecords)
      .where(eq(medicalRecords.patientId, patientId))
      .orderBy(desc(medicalRecords.date));
  }

  async getMedicalRecord(id: number): Promise<MedicalRecord | undefined> {
    const result = await db.select().from(medicalRecords).where(eq(medicalRecords.id, id));
    return result[0];
  }

  async createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord> {
    const result = await db.insert(medicalRecords).values({
      ...record,
      date: timestamp()
    }).returning();
    return result[0];
  }

  // Symptom operations
  async getSymptoms(): Promise<Symptom[]> {
    return db.select().from(symptoms).orderBy(asc(symptoms.name));
  }

  async getSymptom(id: number): Promise<Symptom | undefined> {
    const result = await db.select().from(symptoms).where(eq(symptoms.id, id));
    return result[0];
  }

  async getSymptomByName(name: string): Promise<Symptom | undefined> {
    const result = await db.select().from(symptoms).where(eq(symptoms.name, name));
    return result[0];
  }

  async createSymptom(symptom: InsertSymptom): Promise<Symptom> {
    const result = await db.insert(symptoms).values(symptom).returning();
    return result[0];
  }

  // Condition operations
  async getConditions(): Promise<Condition[]> {
    return db.select().from(conditions).orderBy(asc(conditions.name));
  }

  async getCondition(id: number): Promise<Condition | undefined> {
    const result = await db.select().from(conditions).where(eq(conditions.id, id));
    return result[0];
  }

  async getConditionsBySpecialization(specialization: string): Promise<Condition[]> {
    return db.select().from(conditions)
      .where(eq(conditions.specialization, specialization))
      .orderBy(asc(conditions.name));
  }

  async createCondition(condition: InsertCondition): Promise<Condition> {
    const result = await db.insert(conditions).values(condition).returning();
    return result[0];
  }

  // Symptom-Condition mapping operations
  async getSymptomConditions(): Promise<SymptomCondition[]> {
    return db.select().from(symptomConditions);
  }

  async createSymptomCondition(mapping: InsertSymptomCondition): Promise<SymptomCondition> {
    const result = await db.insert(symptomConditions).values(mapping).returning();
    return result[0];
  }

  async getConditionsBySymptoms(symptomIds: number[]): Promise<{ condition: Condition, score: number }[]> {
    // Get relevant mappings
    const mappings = await db
      .select()
      .from(symptomConditions)
      .where(inArray(symptomConditions.symptomId, symptomIds));
    
    // Calculate scores for each condition
    const conditionScores = new Map<number, number>();
    
    for (const mapping of mappings) {
      const currentScore = conditionScores.get(mapping.conditionId) || 0;
      conditionScores.set(mapping.conditionId, currentScore + (mapping.weight || 1));
    }
    
    // Get condition details
    const results: { condition: Condition, score: number }[] = [];
    
    for (const [conditionId, score] of conditionScores.entries()) {
      const condition = await this.getCondition(conditionId);
      if (condition) {
        results.push({ condition, score });
      }
    }
    
    // Sort by score in descending order
    return results.sort((a, b) => b.score - a.score);
  }

  // Consultation operations
  async getConsultation(id: number): Promise<Consultation | undefined> {
    const result = await db.select().from(consultations).where(eq(consultations.id, id));
    return result[0];
  }

  async getConsultationsByPatient(patientId: number): Promise<Consultation[]> {
    return db.select().from(consultations)
      .where(eq(consultations.patientId, patientId))
      .orderBy(desc(consultations.createdAt));
  }

  async getConsultationsByDoctor(doctorId: number): Promise<Consultation[]> {
    return db.select().from(consultations)
      .where(eq(consultations.doctorId, doctorId))
      .orderBy(desc(consultations.createdAt));
  }

  async createConsultation(consultation: InsertConsultation): Promise<Consultation> {
    const result = await db.insert(consultations).values({
      ...consultation,
      createdAt: timestamp()
    }).returning();
    return result[0];
  }

  async updateConsultation(id: number, data: Partial<Consultation>): Promise<Consultation | undefined> {
    const result = await db.update(consultations).set(data).where(eq(consultations.id, id)).returning();
    return result[0];
  }

  // Message operations
  async getMessagesByConsultation(consultationId: number): Promise<Message[]> {
    return db.select().from(messages)
      .where(eq(messages.consultationId, consultationId))
      .orderBy(asc(messages.sentAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const result = await db.insert(messages).values({
      ...message,
      sentAt: timestamp(),
      read: false
    }).returning();
    return result[0];
  }

  async markMessagesAsRead(consultationId: number, userId: number): Promise<void> {
    await db.update(messages)
      .set({ read: true })
      .where(
        and(
          eq(messages.consultationId, consultationId),
          sql`${messages.senderId} != ${userId}`
        )
      );
  }

  // Product operations
  async getProducts(category?: string): Promise<Product[]> {
    if (category) {
      return db.select().from(products)
        .where(eq(products.category, category))
        .orderBy(asc(products.name));
    }
    return db.select().from(products).orderBy(asc(products.name));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id));
    return result[0];
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(product).returning();
    return result[0];
  }

  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    const result = await db.select().from(orders).where(eq(orders.id, id));
    return result[0];
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return db.select().from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const result = await db.insert(orders).values({
      ...order,
      createdAt: timestamp()
    }).returning();
    return result[0];
  }

  async updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined> {
    const result = await db.update(orders).set(data).where(eq(orders.id, id)).returning();
    return result[0];
  }

  // Order items operations
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const result = await db.insert(orderItems).values(item).returning();
    return result[0];
  }

  // Post operations
  async getPosts(tag?: string): Promise<Post[]> {
    if (tag) {
      return db.select().from(posts)
        .where(sql`json_extract(${posts.tags}, '$[*]') LIKE '%${tag}%'`)
        .orderBy(desc(posts.createdAt));
    }
    return db.select().from(posts).orderBy(desc(posts.createdAt));
  }

  async getPost(id: number): Promise<Post | undefined> {
    const result = await db.select().from(posts).where(eq(posts.id, id));
    return result[0];
  }

  async getPostsByUser(userId: number): Promise<Post[]> {
    return db.select().from(posts)
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt));
  }

  async createPost(post: InsertPost): Promise<Post> {
    const result = await db.insert(posts).values({
      ...post,
      createdAt: timestamp(),
      likes: 0,
      comments: 0
    }).returning();
    return result[0];
  }

  async updatePostStats(id: number, likes?: number, comments?: number): Promise<Post | undefined> {
    const updateData: Partial<Post> = {};
    if (likes !== undefined) updateData.likes = likes;
    if (comments !== undefined) updateData.comments = comments;
    
    if (Object.keys(updateData).length === 0) return this.getPost(id);
    
    const result = await db.update(posts).set(updateData).where(eq(posts.id, id)).returning();
    return result[0];
  }

  // Comment operations
  async getCommentsByPost(postId: number): Promise<Comment[]> {
    return db.select().from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(asc(comments.createdAt));
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    // Get current post
    const post = await this.getPost(comment.postId);
    if (!post) throw new Error('Post not found');
    
    // Insert the comment
    const result = await db.insert(comments).values({
      ...comment,
      createdAt: timestamp()
    }).returning();
    
    // Update the comment count on the post
    await this.updatePostStats(comment.postId, undefined, (post.comments || 0) + 1);
    
    return result[0];
  }
  
  // Initialize demo data for the local database
  async initializeDemoData(): Promise<void> {
    try {
      console.log('Initializing demo data...');
      
      // Check if we already have data
      const hasUsers = (await db.select().from(users)).length > 0;
      if (hasUsers) {
        console.log('Demo data already exists, skipping initialization');
        return;
      }
      
      // Create some users
      console.log('Creating demo users...');
      
      await this.createUser({
        username: 'patient1',
        password: '$2b$10$X7JE3KO91.7Y7Kob8pbEX.4.QR5qL0rvpBX2lXxMmMMoz7.8Ou2iS', // password123
        email: 'patient1@example.com',
        fullName: 'John Doe',
        role: 'patient',
      });
      
      await this.createUser({
        username: 'dr.cardio',
        password: '$2b$10$X7JE3KO91.7Y7Kob8pbEX.4.QR5qL0rvpBX2lXxMmMMoz7.8Ou2iS', // password123
        email: 'cardio@example.com',
        fullName: 'Dr. Robert Smith',
        role: 'doctor',
        specialization: 'Cardiology',
        experience: 15,
        bio: 'Experienced cardiologist specializing in preventive cardiac care',
        location: 'New York'
      });
      
      await this.createUser({
        username: 'dr.neuro',
        password: '$2b$10$X7JE3KO91.7Y7Kob8pbEX.4.QR5qL0rvpBX2lXxMmMMoz7.8Ou2iS', // password123
        email: 'neuro@example.com',
        fullName: 'Dr. Emily Johnson',
        role: 'doctor',
        specialization: 'Neurology',
        experience: 10,
        bio: 'Neurologist specializing in headache disorders and neuropathy',
        location: 'Boston'
      });
      
      // Add symptoms
      console.log('Adding symptoms...');
      for (const symptom of additionalSymptoms) {
        const existingSymptom = await this.getSymptomByName(symptom.name);
        if (!existingSymptom) {
          await this.createSymptom(symptom);
        }
      }
      
      // Add conditions
      console.log('Adding conditions...');
      for (const condition of conditionData) {
        await this.createCondition(condition);
      }
      
      // Add symptom-condition mappings
      console.log('Adding symptom-condition mappings...');
      for (const mapping of symptomConditionMappings) {
        const symptom = await this.getSymptomByName(mapping.symptomName);
        if (!symptom) {
          console.log(`Symptom not found: ${mapping.symptomName}`);
          continue;
        }
        
        const conditionsResult = await db.select().from(conditions).where(eq(conditions.name, mapping.conditionName));
        if (conditionsResult.length === 0) {
          console.log(`Condition not found: ${mapping.conditionName}`);
          continue;
        }
        
        await this.createSymptomCondition({
          symptomId: symptom.id,
          conditionId: conditionsResult[0].id,
          weight: mapping.weight
        });
      }
      
      // Add products
      console.log('Adding products...');
      for (const product of medicationProducts) {
        await this.createProduct(product);
      }
      
      console.log('Demo data initialization complete!');
    } catch (error) {
      console.error('Error initializing demo data:', error);
    }
  }
}

export const storage = new SQLiteStorage();