import { createClient } from '@supabase/supabase-js';
import { 
  User, InsertUser, MedicalRecord, InsertMedicalRecord, 
  Symptom, InsertSymptom, Condition, InsertCondition, 
  SymptomCondition, InsertSymptomCondition, Consultation, 
  InsertConsultation, Message, InsertMessage, Product, 
  InsertProduct, Order, InsertOrder, OrderItem, InsertOrderItem,
  Post, InsertPost, Comment, InsertComment
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Use hardcoded credentials to ensure availability
const supabaseUrl = process.env.SUPABASE_URL || 'https://oifgojcqkhizhleolcjt.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc';

console.log('Initializing Supabase client in storage.ts with URL:', supabaseUrl);

const supabase = createClient(
  supabaseUrl,
  supabaseKey
);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getDoctors(specialization?: string): Promise<User[]>;

  // Medical records operations
  getMedicalRecordsByPatient(patientId: number): Promise<MedicalRecord[]>;
  getMedicalRecord(id: number): Promise<MedicalRecord | undefined>;
  createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord>;

  // Symptom operations
  getSymptoms(): Promise<Symptom[]>;
  getSymptom(id: number): Promise<Symptom | undefined>;
  getSymptomByName(name: string): Promise<Symptom | undefined>;
  createSymptom(symptom: InsertSymptom): Promise<Symptom>;

  // Condition operations
  getConditions(): Promise<Condition[]>;
  getCondition(id: number): Promise<Condition | undefined>;
  getConditionsBySpecialization(specialization: string): Promise<Condition[]>;
  createCondition(condition: InsertCondition): Promise<Condition>;

  // Symptom-Condition mapping operations
  getSymptomConditions(): Promise<SymptomCondition[]>;
  createSymptomCondition(mapping: InsertSymptomCondition): Promise<SymptomCondition>;
  getConditionsBySymptoms(symptomIds: number[]): Promise<{condition: Condition, score: number}[]>;

  // Consultation operations
  getConsultation(id: number): Promise<Consultation | undefined>;
  getConsultationsByPatient(patientId: number): Promise<Consultation[]>;
  getConsultationsByDoctor(doctorId: number): Promise<Consultation[]>;
  createConsultation(consultation: InsertConsultation): Promise<Consultation>;
  updateConsultation(id: number, data: Partial<Consultation>): Promise<Consultation | undefined>;

  // Message operations
  getMessagesByConsultation(consultationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessagesAsRead(consultationId: number, userId: number): Promise<void>;

  // Product operations
  getProducts(category?: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined>;

  // Order items operations
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;

  // Post operations
  getPosts(tag?: string): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  getPostsByUser(userId: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePostStats(id: number, likes?: number, comments?: number): Promise<Post | undefined>;

  // Comment operations
  getCommentsByPost(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;

  // Session store
  sessionStore: any;
}

export class SupabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const { data, error } = await supabase
      .from('users')
      .select()
      .eq('id', id)
      .single();
    
    if (error) {
      console.error('Error fetching user by ID:', error);
      throw error;
    }
    
    if (!data) return undefined;
    
    // Convert snake_case from DB to camelCase for application
    return {
      ...data,
      fullName: data.full_name,
      profilePicture: data.profile_picture,
      reviewCount: data.review_count,
      createdAt: data.created_at
    } as User;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const { data, error } = await supabase
      .from('users')
      .select()
      .eq('username', username)
      .single();
    
    if (error) {
      if (error.code !== 'PGRST116') {
        console.error('Error fetching user by username:', error);
        throw error;
      }
      return undefined;
    }
    
    if (!data) return undefined;
    
    // Convert snake_case from DB to camelCase for application
    return {
      ...data,
      fullName: data.full_name,
      profilePicture: data.profile_picture,
      reviewCount: data.review_count,
      createdAt: data.created_at
    } as User;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const { data, error } = await supabase
      .from('users')
      .select()
      .eq('email', email)
      .single();
    
    if (error) {
      if (error.code !== 'PGRST116') {
        console.error('Error fetching user by email:', error);
        throw error;
      }
      return undefined;
    }
    
    if (!data) return undefined;
    
    // Convert snake_case from DB to camelCase for application
    return {
      ...data,
      fullName: data.full_name,
      profilePicture: data.profile_picture,
      reviewCount: data.review_count,
      createdAt: data.created_at
    } as User;
  }

  async createUser(user: InsertUser): Promise<User> {
    // Convert fullName to full_name for database compatibility
    const dbUser = {
      username: user.username,
      password: user.password,
      email: user.email,
      full_name: user.fullName, // Convert camelCase to snake_case
      role: user.role,
      profile_picture: user.profilePicture,
      specialization: user.specialization,
      experience: user.experience,
      bio: user.bio,
      location: user.location
    };
    
    console.log('Creating user:', dbUser);
    
    const { data, error } = await supabase
      .from('users')
      .insert([dbUser])
      .select()
      .single();
    
    if (error) {
      console.error('Error creating user:', error);
      throw error;
    }
    
    // Convert data back to camelCase for application code
    return {
      ...data,
      fullName: data.full_name,
      profilePicture: data.profile_picture,
      reviewCount: data.review_count,
      createdAt: data.created_at
    } as User;
  }

  async updateUser(id: number, user: Partial<User>): Promise<User | undefined> {
    // Convert camelCase to snake_case for DB
    const dbUser: any = {};
    
    if (user.fullName !== undefined) dbUser.full_name = user.fullName;
    if (user.profilePicture !== undefined) dbUser.profile_picture = user.profilePicture;
    if (user.reviewCount !== undefined) dbUser.review_count = user.reviewCount;
    
    // Copy other fields directly
    if (user.username !== undefined) dbUser.username = user.username;
    if (user.password !== undefined) dbUser.password = user.password;
    if (user.email !== undefined) dbUser.email = user.email;
    if (user.role !== undefined) dbUser.role = user.role;
    if (user.specialization !== undefined) dbUser.specialization = user.specialization;
    if (user.experience !== undefined) dbUser.experience = user.experience;
    if (user.bio !== undefined) dbUser.bio = user.bio;
    if (user.location !== undefined) dbUser.location = user.location;
    if (user.verified !== undefined) dbUser.verified = user.verified;
    if (user.rating !== undefined) dbUser.rating = user.rating;
    
    console.log('Updating user with ID:', id, 'Data:', dbUser);
    
    const { data, error } = await supabase
      .from('users')
      .update(dbUser)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error('Error updating user:', error);
      throw error;
    }
    
    if (!data) return undefined;
    
    // Convert snake_case to camelCase for application
    return {
      ...data,
      fullName: data.full_name,
      profilePicture: data.profile_picture,
      reviewCount: data.review_count,
      createdAt: data.created_at
    } as User;
  }

  async getDoctors(specialization?: string): Promise<User[]> {
    let query = supabase
      .from('users')
      .select()
      .eq('role', 'doctor');

    if (specialization) {
      query = query.eq('specialization', specialization);
    }

    const { data, error } = await query;
    
    if (error) {
      console.error('Error fetching doctors:', error);
      throw error;
    }
    
    // Convert each doctor's data from snake_case to camelCase
    return (data || []).map(doctor => ({
      ...doctor,
      fullName: doctor.full_name,
      profilePicture: doctor.profile_picture,
      reviewCount: doctor.review_count,
      createdAt: doctor.created_at
    })) as User[];
  }

  // Medical records operations
  async getMedicalRecordsByPatient(patientId: number): Promise<MedicalRecord[]> {
    const { data, error } = await supabase
      .from('medical_records')
      .select()
      .eq('patientId', patientId);
    if (error) throw error;
    return data || [];
  }

  async getMedicalRecord(id: number): Promise<MedicalRecord | undefined> {
    const { data, error } = await supabase
      .from('medical_records')
      .select()
      .eq('id', id)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async createMedicalRecord(record: InsertMedicalRecord): Promise<MedicalRecord> {
    const { data, error } = await supabase
      .from('medical_records')
      .insert([{ ...record, date: new Date().toISOString() }])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  // Symptom operations
  async getSymptoms(): Promise<Symptom[]> {
    const { data, error } = await supabase
      .from('symptoms')
      .select();
    if (error) throw error;
    return data || [];
  }

  async getSymptom(id: number): Promise<Symptom | undefined> {
    const { data, error } = await supabase
      .from('symptoms')
      .select()
      .eq('id', id)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async getSymptomByName(name: string): Promise<Symptom | undefined> {
    const { data, error } = await supabase
      .from('symptoms')
      .select()
      .eq('name', name)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async createSymptom(symptom: InsertSymptom): Promise<Symptom> {
    const { data, error } = await supabase
      .from('symptoms')
      .insert([symptom])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  // Condition operations
  async getConditions(): Promise<Condition[]> {
    const { data, error } = await supabase
      .from('conditions')
      .select();
    if (error) throw error;
    return data || [];
  }

  async getCondition(id: number): Promise<Condition | undefined> {
    const { data, error } = await supabase
      .from('conditions')
      .select()
      .eq('id', id)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async getConditionsBySpecialization(specialization: string): Promise<Condition[]> {
    const { data, error } = await supabase
      .from('conditions')
      .select()
      .eq('specialization', specialization);
    if (error) throw error;
    return data || [];
  }

  async createCondition(condition: InsertCondition): Promise<Condition> {
    const { data, error } = await supabase
      .from('conditions')
      .insert([condition])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  // Symptom-Condition mapping operations
  async getSymptomConditions(): Promise<SymptomCondition[]> {
    const { data, error } = await supabase
      .from('symptom_conditions')
      .select();
    if (error) throw error;
    return data || [];
  }

  async createSymptomCondition(mapping: InsertSymptomCondition): Promise<SymptomCondition> {
    const { data, error } = await supabase
      .from('symptom_conditions')
      .insert([mapping])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async getConditionsBySymptoms(symptomIds: number[]): Promise<{ condition: Condition, score: number }[]> {
    try {
      console.log('Getting conditions for symptom IDs:', symptomIds);
      
      // First, get all symptom-condition mappings
      const { data: mappings, error } = await supabase
        .from('symptom_conditions')
        .select('symptom_id, condition_id, weight')
        .in('symptom_id', symptomIds);

      if (error) {
        console.error('Error fetching symptom-condition mappings:', error);
        throw error;
      }

      // Debug the mappings
      console.log(`Found ${mappings?.length || 0} symptom-condition mappings`);
      
      // Calculate scores for each condition
      const conditionScoreMap = new Map<number, number>();
      
      for (const mapping of mappings || []) {
        const conditionId = mapping.condition_id;
        const weight = mapping.weight || 1;
        
        const currentScore = conditionScoreMap.get(conditionId) || 0;
        conditionScoreMap.set(conditionId, currentScore + weight);
      }
      
      // Now get the actual condition objects
      const results: { condition: Condition, score: number }[] = [];
      
      // Convert to array to avoid TypeScript error
      const conditionEntries = Array.from(conditionScoreMap.entries());
      
      for (const [conditionId, score] of conditionEntries) {
        // Get the condition details
        const { data: condition, error: conditionError } = await supabase
          .from('conditions')
          .select('*')
          .eq('id', conditionId)
          .single();
        
        if (conditionError) {
          console.error(`Error fetching condition ${conditionId}:`, conditionError);
          continue;
        }
        
        if (condition) {
          results.push({
            condition: condition as Condition,
            score
          });
        }
      }
      
      // Sort by score in descending order
      return results.sort((a, b) => b.score - a.score);
    } catch (error) {
      console.error('Error in getConditionsBySymptoms:', error);
      return []; // Return empty array rather than crashing
    }
  }

  // Consultation operations
  async getConsultation(id: number): Promise<Consultation | undefined> {
    try {
      console.log('Fetching consultation with ID:', id);
      const { data, error } = await supabase
        .from('consultations')
        .select()
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          console.log('Consultation not found');
          return undefined;
        }
        console.error('Error fetching consultation:', error);
        throw error;
      }

      if (!data) {
        console.log('No consultation data returned');
        return undefined;
      }

      // Convert snake_case to camelCase
      return {
        id: data.id,
        patientId: data.patient_id,
        doctorId: data.doctor_id,
        scheduledAt: data.scheduled_at,
        symptoms: data.symptoms,
        notes: data.notes,
        status: data.status,
        diagnosis: data.diagnosis,
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Failed to fetch consultation:', error);
      throw error;
    }
  }

  async getConsultationsByPatient(patientId: number): Promise<Consultation[]> {
    const { data, error } = await supabase
      .from('consultations')
      .select()
      .eq('patientId', patientId);
    if (error) throw error;
    return data || [];
  }

  async getConsultationsByDoctor(doctorId: number): Promise<Consultation[]> {
    const { data, error } = await supabase
      .from('consultations')
      .select()
      .eq('doctorId', doctorId);
    if (error) throw error;
    return data || [];
  }

  async createConsultation(consultation: InsertConsultation): Promise<Consultation> {
    try {
      const { data, error } = await supabase
        .from('consultations')
        .insert([{
          patient_id: consultation.patientId,
          doctor_id: consultation.doctorId,
          scheduled_at: consultation.scheduledAt,
          symptoms: consultation.symptoms,
          notes: consultation.notes,
          status: consultation.status || 'scheduled'
        }])
        .select()
        .single();
      
      if (error) {
        console.error('Consultation creation error:', error);
        throw error;
      }
      
      return {
        id: data.id,
        patientId: data.patient_id,
        doctorId: data.doctor_id,
        scheduledAt: data.scheduled_at,
        symptoms: data.symptoms,
        notes: data.notes,
        status: data.status,
        diagnosis: data.diagnosis,
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Failed to create consultation:', error);
      throw error;
    }
  }

  async updateConsultation(id: number, data: Partial<Consultation>): Promise<Consultation | undefined> {
    const { data: updatedData, error } = await supabase
      .from('consultations')
      .update(data)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return updatedData || undefined;
  }

  // Message operations
  async getMessagesByConsultation(consultationId: number): Promise<Message[]> {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('id, consultation_id, sender_id, content, sent_at, read')
        .eq('consultation_id', consultationId)
        .order('sent_at', { ascending: true });

      if (error) {
        console.error('Error fetching messages:', error);
        throw error;
      }

      return data.map(msg => ({
        id: msg.id,
        consultationId: msg.consultation_id,
        senderId: msg.sender_id,
        content: msg.content,
        sentAt: msg.sent_at,
        read: msg.read
      }));
    } catch (error) {
      console.error('Failed to fetch messages:', error);
      throw error;
    }
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    try {
      console.log('Creating message:', message);
      const { data, error } = await supabase
        .from('messages')
        .insert([{
          consultation_id: message.consultationId,
          sender_id: message.senderId,
          content: message.content,
          sent_at: new Date().toISOString(),
          read: false
        }])
        .select('id, consultation_id, sender_id, content, sent_at, read')
        .single();

      if (error) {
        console.error('Error creating message:', error);
        throw error;
      }

      if (!data) {
        throw new Error('No data returned from message creation');
      }

      const formattedMessage: Message = {
        id: data.id,
        consultationId: data.consultation_id,
        senderId: data.sender_id,
        content: data.content,
        sentAt: data.sent_at,
        read: data.read
      };

      console.log('Created message:', formattedMessage);
      return formattedMessage;
    } catch (error) {
      console.error('Failed to create message:', error);
      throw error;
    }
  }

  async markMessagesAsRead(consultationId: number, userId: number): Promise<void> {
    try {
      const { error } = await supabase
        .from('messages')
        .update({ read: true })
        .eq('consultation_id', consultationId)
        .neq('sender_id', userId)
        .eq('read', false);
      
      if (error) {
        console.error('Error marking messages as read:', error);
        throw error;
      }
    } catch (error) {
      console.error('Failed to mark messages as read:', error);
      throw error;
    }
  }

  // Product operations
  async getProducts(category?: string): Promise<Product[]> {
    let query = supabase.from('products').select();
    if (category) {
      query = query.eq('category', category);
    }
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const { data, error } = await supabase
      .from('products')
      .select()
      .eq('id', id)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const { data, error } = await supabase
      .from('products')
      .insert([product])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  // Order operations
  async getOrder(id: number): Promise<Order | undefined> {
    const { data, error } = await supabase
      .from('orders')
      .select()
      .eq('id', id)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select()
      .eq('userId', userId);
    if (error) throw error;
    return data || [];
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const { data, error } = await supabase
      .from('orders')
      .insert([{
        ...order,
        date: new Date().toISOString(),
        status: order.status || 'pending'
      }])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined> {
    const { data: updatedData, error } = await supabase
      .from('orders')
      .update(data)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return updatedData || undefined;
  }

  // Order items operations
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    const { data, error } = await supabase
      .from('order_items')
      .select()
      .eq('orderId', orderId);
    if (error) throw error;
    return data || [];
  }

  async createOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const { data, error } = await supabase
      .from('order_items')
      .insert([item])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  // Post operations
  async getPosts(tag?: string): Promise<Post[]> {
    let query = supabase.from('posts').select();
    if (tag) {
      query = query.contains('tags', [tag]);
    }
    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  }

  async getPost(id: number): Promise<Post | undefined> {
    const { data, error } = await supabase
      .from('posts')
      .select()
      .eq('id', id)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data || undefined;
  }

  async getPostsByUser(userId: number): Promise<Post[]> {
    const { data, error } = await supabase
      .from('posts')
      .select()
      .eq('userId', userId);
    if (error) throw error;
    return data || [];
  }

  async createPost(post: InsertPost): Promise<Post> {
    const { data, error } = await supabase
      .from('posts')
      .insert([{
        ...post,
        createdAt: new Date().toISOString(),
        likes: 0,
        comments: 0
      }])
      .select()
      .single();
    if (error) throw error;
    return data;
  }

  async updatePostStats(id: number, likes?: number, comments?: number): Promise<Post | undefined> {
    const updates: any = {};
    if (likes !== undefined) updates.likes = likes;
    if (comments !== undefined) updates.comments = comments;

    const { data, error } = await supabase
      .from('posts')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    if (error) throw error;
    return data || undefined;
  }

  // Comment operations
  async getCommentsByPost(postId: number): Promise<Comment[]> {
    const { data, error } = await supabase
      .from('comments')
      .select()
      .eq('postId', postId)
      .order('createdAt', { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const { data, error } = await supabase
      .from('comments')
      .insert([{
        ...comment,
        createdAt: new Date().toISOString()
      }])
      .select()
      .single();
    if (error) throw error;

    // Update post comment count
    const post = await this.getPost(comment.postId);
    if (post) {
      await this.updatePostStats(post.id, undefined, (post.comments || 0) + 1);
    }

    return data;
  }
}

// Export the new Supabase storage implementation
export const storage = new SupabaseStorage();