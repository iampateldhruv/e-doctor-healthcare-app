import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { User, Consultation, MedicalRecord } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  Calendar,
  Clock,
  ClipboardList,
  FileText,
  UploadCloud,
  Plus,
  Video,
  MessageSquare,
  ChevronRight,
  ChevronDown,
  User as UserIcon,
  PlusCircle,
  Activity,
  Pill,
  HeartPulse,
  ChevronUp,
  AlertTriangle,
} from "lucide-react";

export default function PatientDashboard() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [uploadingRecord, setUploadingRecord] = useState(false);
  const [medicalRecordData, setMedicalRecordData] = useState({
    title: "",
    description: "",
    type: "Lab Result",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Redirect if not logged in
  if (!user) {
    navigate("/auth");
    return null;
  }

  // Fetch consultations
  const { data: consultations, isLoading: consultationsLoading } = useQuery<Consultation[]>({
    queryKey: ["/api/consultations"],
    queryFn: async () => {
      const response = await fetch("/api/consultations");
      if (!response.ok) {
        throw new Error("Failed to fetch consultations");
      }
      return response.json();
    },
  });

  // Fetch medical records
  const { data: medicalRecords, isLoading: recordsLoading } = useQuery<MedicalRecord[]>({
    queryKey: ["/api/medical-records"],
    queryFn: async () => {
      const response = await fetch("/api/medical-records");
      if (!response.ok) {
        throw new Error("Failed to fetch medical records");
      }
      return response.json();
    },
  });

  // Upload medical record
  const handleUploadRecord = async () => {
    if (!medicalRecordData.title || !medicalRecordData.description) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setUploadingRecord(true);

    try {
      // Create FormData
      const formData = new FormData();
      formData.append("title", medicalRecordData.title);
      formData.append("description", medicalRecordData.description);
      formData.append("type", medicalRecordData.type);
      
      if (selectedFile) {
        formData.append("file", selectedFile);
      }

      // Upload record
      const response = await fetch("/api/medical-records", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Failed to upload medical record");
      }

      // Show success message
      toast({
        title: "Medical record uploaded",
        description: "Your medical record has been successfully added",
      });

      // Reset form and close dialog
      setMedicalRecordData({
        title: "",
        description: "",
        type: "Lab Result",
      });
      setSelectedFile(null);
      setIsUploadDialogOpen(false);

      // Invalidate query to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/medical-records"] });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload medical record",
        variant: "destructive",
      });
    } finally {
      setUploadingRecord(false);
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Format time
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Get status badge color
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>;
      case "scheduled":
        return <Badge className="bg-blue-500">Scheduled</Badge>;
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>;
      default:
        return <Badge className="bg-yellow-500">Pending</Badge>;
    }
  };

  // Get consultation doctors
  const getDoctorsFromConsultations = () => {
    const uniqueDoctors = new Set<number>();
    const doctors: { id: number; count: number }[] = [];

    if (consultations) {
      consultations.forEach((consultation) => {
        if (!uniqueDoctors.has(consultation.doctorId)) {
          uniqueDoctors.add(consultation.doctorId);
          doctors.push({ id: consultation.doctorId, count: 1 });
        } else {
          const doctor = doctors.find((d) => d.id === consultation.doctorId);
          if (doctor) {
            doctor.count += 1;
          }
        }
      });
    }

    return doctors.slice(0, 3); // Return top 3 doctors
  };

  return (
    <div className="bg-background min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-textColor mb-2 font-sf-pro">Patient Dashboard</h1>
          <p className="text-gray-600">
            Manage your health records, appointments, and consultations
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center mb-6">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage
                      src={user.profilePicture}
                      alt={user.fullName}
                    />
                    <AvatarFallback className="text-lg">
                      {user.fullName.split(" ").map((n) => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-bold">{user.fullName}</h2>
                  <p className="text-gray-500">{user.email}</p>
                </div>

                <Separator className="my-4" />

                <nav className="space-y-1">
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "overview" ? "bg-primary/10 text-primary" : ""
                    }`}
                    onClick={() => setActiveTab("overview")}
                  >
                    <Activity className="mr-2 h-4 w-4" />
                    Overview
                  </Button>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "consultations" ? "bg-primary/10 text-primary" : ""
                    }`}
                    onClick={() => setActiveTab("consultations")}
                  >
                    <Video className="mr-2 h-4 w-4" />
                    Consultations
                  </Button>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "records" ? "bg-primary/10 text-primary" : ""
                    }`}
                    onClick={() => setActiveTab("records")}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Medical Records
                  </Button>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "medications" ? "bg-primary/10 text-primary" : ""
                    }`}
                    onClick={() => setActiveTab("medications")}
                  >
                    <Pill className="mr-2 h-4 w-4" />
                    Medications
                  </Button>
                </nav>

                <Separator className="my-4" />

                <div className="space-y-3">
                  <Button
                    className="w-full bg-primary text-white"
                    onClick={() => navigate("/symptom-checker")}
                  >
                    <HeartPulse className="mr-2 h-4 w-4" /> Check Symptoms
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate("/doctors")}
                  >
                    <UserIcon className="mr-2 h-4 w-4" /> Find Doctors
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader className="pb-3">
                <CardTitle>Upcoming Appointment</CardTitle>
              </CardHeader>
              <CardContent>
                {consultationsLoading ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : consultations?.filter(c => c.status === "scheduled").length === 0 ? (
                  <div className="text-center py-4">
                    <p className="text-gray-500 text-sm">No upcoming appointments</p>
                    <Button
                      className="mt-2 text-sm"
                      variant="link"
                      onClick={() => navigate("/doctors")}
                    >
                      Book a consultation
                    </Button>
                  </div>
                ) : (
                  consultations
                    ?.filter(c => c.status === "scheduled")
                    .slice(0, 1)
                    .map((consultation) => (
                      <div key={consultation.id} className="space-y-3">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 text-primary mr-2" />
                          <span className="text-sm">
                            {consultation.scheduledAt ? formatDate(consultation.scheduledAt) : "Not scheduled"}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-primary mr-2" />
                          <span className="text-sm">
                            {consultation.scheduledAt ? formatTime(consultation.scheduledAt) : "Not scheduled"}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <UserIcon className="h-4 w-4 text-primary mr-2" />
                          <span className="text-sm">Dr. [Doctor Name]</span>
                        </div>
                        <Button
                          className="w-full mt-2"
                          size="sm"
                          onClick={() => navigate(`/consultation/${consultation.id}`)}
                        >
                          Join Consultation
                        </Button>
                      </div>
                    ))[0]
                )}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">
                        Total Consultations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {consultationsLoading ? (
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                        ) : (
                          consultations?.length || 0
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">
                        Medical Records
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {recordsLoading ? (
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                        ) : (
                          medicalRecords?.length || 0
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium text-gray-500">
                        Next Appointment
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {consultationsLoading ? (
                        <Loader2 className="h-5 w-5 animate-spin text-primary" />
                      ) : consultations?.filter(c => c.status === "scheduled").length === 0 ? (
                        <span className="text-sm text-gray-500">None scheduled</span>
                      ) : (
                        <span className="text-sm font-medium">
                          {formatDate(consultations?.filter(c => c.status === "scheduled")[0]?.scheduledAt || new Date().toString())}
                        </span>
                      )}
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Health Overview</CardTitle>
                    <CardDescription>
                      Your health indicators and metrics
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">Heart Rate</span>
                          <span className="text-sm text-gray-500">78 bpm</span>
                        </div>
                        <Progress value={78} max={100} className="h-2" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">Blood Pressure</span>
                          <span className="text-sm text-gray-500">120/80 mmHg</span>
                        </div>
                        <Progress value={75} max={100} className="h-2" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium">Blood Glucose</span>
                          <span className="text-sm text-gray-500">90 mg/dL</span>
                        </div>
                        <Progress value={60} max={100} className="h-2" />
                      </div>
                      <div className="flex justify-end">
                        <Button variant="link" className="text-primary">
                          View All Health Metrics
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle>Recent Consultations</CardTitle>
                        <Button
                          variant="ghost"
                          className="text-primary h-8 px-2"
                          onClick={() => setActiveTab("consultations")}
                        >
                          View All
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {consultationsLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-6 w-6 animate-spin text-primary" />
                        </div>
                      ) : consultations?.length === 0 ? (
                        <div className="text-center py-8">
                          <p className="text-gray-500">No consultations yet</p>
                          <Button
                            variant="link"
                            className="mt-2"
                            onClick={() => navigate("/doctors")}
                          >
                            Find a doctor
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {consultations?.slice(0, 3).map((consultation) => (
                            <div
                              key={consultation.id}
                              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
                              onClick={() => navigate(`/consultation/${consultation.id}`)}
                            >
                              <div className="flex items-center gap-3">
                                <div className="bg-primary/10 p-2 rounded-full">
                                  <Video className="h-4 w-4 text-primary" />
                                </div>
                                <div>
                                  <h4 className="text-sm font-medium">
                                    Consultation {consultation.status === "completed" ? "with Dr. [Doctor]" : "Scheduled"}
                                  </h4>
                                  <p className="text-xs text-gray-500">
                                    {consultation.scheduledAt
                                      ? formatDate(consultation.scheduledAt)
                                      : formatDate(consultation.createdAt)}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {getStatusBadge(consultation.status)}
                                <ChevronRight className="h-4 w-4 text-gray-400" />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <div className="flex justify-between items-center">
                        <CardTitle>Medical Records</CardTitle>
                        <Button
                          variant="ghost"
                          className="text-primary h-8 px-2"
                          onClick={() => setActiveTab("records")}
                        >
                          View All
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {recordsLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-6 w-6 animate-spin text-primary" />
                        </div>
                      ) : medicalRecords?.length === 0 ? (
                        <div className="text-center py-8">
                          <p className="text-gray-500">No medical records yet</p>
                          <Button
                            variant="link"
                            className="mt-2"
                            onClick={() => setIsUploadDialogOpen(true)}
                          >
                            Upload a record
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {medicalRecords?.slice(0, 3).map((record) => (
                            <div
                              key={record.id}
                              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100"
                            >
                              <div className="flex items-center gap-3">
                                <div className="bg-primary/10 p-2 rounded-full">
                                  <FileText className="h-4 w-4 text-primary" />
                                </div>
                                <div>
                                  <h4 className="text-sm font-medium">{record.title}</h4>
                                  <p className="text-xs text-gray-500">
                                    {formatDate(record.date)}
                                  </p>
                                </div>
                              </div>
                              <div>
                                <Badge variant="outline">{record.type}</Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* Consultations Tab */}
            {activeTab === "consultations" && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Your Consultations</CardTitle>
                      <CardDescription>
                        Manage all your appointments and consultations
                      </CardDescription>
                    </div>
                    <Button
                      className="bg-primary text-white"
                      onClick={() => navigate("/doctors")}
                    >
                      <Plus className="h-4 w-4 mr-2" /> New Consultation
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="upcoming">
                    <TabsList className="mb-4">
                      <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                      <TabsTrigger value="past">Past</TabsTrigger>
                      <TabsTrigger value="all">All</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="upcoming">
                      {consultationsLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        </div>
                      ) : consultations?.filter(c => c.status === "scheduled").length === 0 ? (
                        <div className="text-center py-8">
                          <p className="text-gray-500 mb-2">No upcoming consultations</p>
                          <Button 
                            variant="default"
                            className="bg-primary"
                            onClick={() => navigate("/doctors")}
                          >
                            Find a Doctor
                          </Button>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Doctor</TableHead>
                              <TableHead>Date & Time</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {consultations
                              ?.filter(c => c.status === "scheduled")
                              .map((consultation) => (
                                <TableRow key={consultation.id}>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Avatar className="h-8 w-8">
                                        <AvatarFallback>DR</AvatarFallback>
                                      </Avatar>
                                      <div>
                                        <div className="font-medium">Dr. [Name]</div>
                                        <div className="text-xs text-gray-500">[Specialization]</div>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    {consultation.scheduledAt ? (
                                      <div>
                                        <div>{formatDate(consultation.scheduledAt)}</div>
                                        <div className="text-xs text-gray-500">
                                          {formatTime(consultation.scheduledAt)}
                                        </div>
                                      </div>
                                    ) : (
                                      <span className="text-gray-500">Not scheduled</span>
                                    )}
                                  </TableCell>
                                  <TableCell>{getStatusBadge(consultation.status)}</TableCell>
                                  <TableCell>
                                    <div className="flex gap-2">
                                      <Button
                                        size="sm"
                                        className="bg-primary"
                                        onClick={() => navigate(`/consultation/${consultation.id}`)}
                                      >
                                        Join
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => {
                                          // Handle reschedule
                                          toast({
                                            title: "Not implemented",
                                            description: "Rescheduling functionality is not implemented yet.",
                                          });
                                        }}
                                      >
                                        Reschedule
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                          </TableBody>
                        </Table>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="past">
                      {consultationsLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        </div>
                      ) : consultations?.filter(c => c.status === "completed").length === 0 ? (
                        <div className="text-center py-8">
                          <p className="text-gray-500">No past consultations</p>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Doctor</TableHead>
                              <TableHead>Date & Time</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {consultations
                              ?.filter(c => c.status === "completed")
                              .map((consultation) => (
                                <TableRow key={consultation.id}>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Avatar className="h-8 w-8">
                                        <AvatarFallback>DR</AvatarFallback>
                                      </Avatar>
                                      <div>
                                        <div className="font-medium">Dr. [Name]</div>
                                        <div className="text-xs text-gray-500">[Specialization]</div>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    {consultation.scheduledAt ? (
                                      <div>
                                        <div>{formatDate(consultation.scheduledAt)}</div>
                                        <div className="text-xs text-gray-500">
                                          {formatTime(consultation.scheduledAt)}
                                        </div>
                                      </div>
                                    ) : (
                                      <span className="text-gray-500">
                                        {formatDate(consultation.createdAt)}
                                      </span>
                                    )}
                                  </TableCell>
                                  <TableCell>{getStatusBadge(consultation.status)}</TableCell>
                                  <TableCell>
                                    <div className="flex gap-2">
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => navigate(`/consultation/${consultation.id}`)}
                                      >
                                        View Details
                                      </Button>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        onClick={() => navigate("/doctors")}
                                      >
                                        Book Again
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                          </TableBody>
                        </Table>
                      )}
                    </TabsContent>
                    
                    <TabsContent value="all">
                      {consultationsLoading ? (
                        <div className="flex justify-center py-8">
                          <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        </div>
                      ) : consultations?.length === 0 ? (
                        <div className="text-center py-8">
                          <p className="text-gray-500 mb-2">No consultations yet</p>
                          <Button 
                            variant="default"
                            className="bg-primary"
                            onClick={() => navigate("/doctors")}
                          >
                            Find a Doctor
                          </Button>
                        </div>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Doctor</TableHead>
                              <TableHead>Date & Time</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {consultations?.map((consultation) => (
                              <TableRow key={consultation.id}>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <Avatar className="h-8 w-8">
                                      <AvatarFallback>DR</AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="font-medium">Dr. [Name]</div>
                                      <div className="text-xs text-gray-500">[Specialization]</div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  {consultation.scheduledAt ? (
                                    <div>
                                      <div>{formatDate(consultation.scheduledAt)}</div>
                                      <div className="text-xs text-gray-500">
                                        {formatTime(consultation.scheduledAt)}
                                      </div>
                                    </div>
                                  ) : (
                                    <span className="text-gray-500">
                                      {formatDate(consultation.createdAt)}
                                    </span>
                                  )}
                                </TableCell>
                                <TableCell>{getStatusBadge(consultation.status)}</TableCell>
                                <TableCell>
                                  <div className="flex gap-2">
                                    <Button
                                      size="sm"
                                      variant={consultation.status === "scheduled" ? "default" : "outline"}
                                      className={consultation.status === "scheduled" ? "bg-primary" : ""}
                                      onClick={() => navigate(`/consultation/${consultation.id}`)}
                                    >
                                      {consultation.status === "scheduled" ? "Join" : "View"}
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}

            {/* Medical Records Tab */}
            {activeTab === "records" && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Medical Records</CardTitle>
                      <CardDescription>
                        Manage your health records and documents
                      </CardDescription>
                    </div>
                    <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
                      <DialogTrigger asChild>
                        <Button className="bg-primary text-white">
                          <Plus className="h-4 w-4 mr-2" /> Upload Record
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Upload Medical Record</DialogTitle>
                          <DialogDescription>
                            Add a new medical record to your health profile
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="title">Title</Label>
                            <Input
                              id="title"
                              placeholder="E.g., Blood Test Results"
                              value={medicalRecordData.title}
                              onChange={(e) => setMedicalRecordData({
                                ...medicalRecordData,
                                title: e.target.value,
                              })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="type">Record Type</Label>
                            <Select
                              value={medicalRecordData.type}
                              onValueChange={(value) => setMedicalRecordData({
                                ...medicalRecordData,
                                type: value,
                              })}
                            >
                              <SelectTrigger id="type">
                                <SelectValue placeholder="Select record type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Lab Result">Lab Result</SelectItem>
                                <SelectItem value="Prescription">Prescription</SelectItem>
                                <SelectItem value="Imaging">Imaging (X-ray, MRI, etc.)</SelectItem>
                                <SelectItem value="Vaccination">Vaccination</SelectItem>
                                <SelectItem value="Visit Summary">Visit Summary</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="description">Description</Label>
                            <Textarea
                              id="description"
                              placeholder="Add details about this record"
                              rows={3}
                              value={medicalRecordData.description}
                              onChange={(e) => setMedicalRecordData({
                                ...medicalRecordData,
                                description: e.target.value,
                              })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Upload Document (optional)</Label>
                            <div
                              className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                              onClick={() => document.getElementById("file-upload")?.click()}
                            >
                              <input
                                id="file-upload"
                                type="file"
                                className="hidden"
                                accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                                onChange={(e) => {
                                  if (e.target.files && e.target.files[0]) {
                                    setSelectedFile(e.target.files[0]);
                                  }
                                }}
                              />
                              {selectedFile ? (
                                <div className="flex items-center justify-center gap-2">
                                  <FileText className="h-6 w-6 text-primary" />
                                  <span className="text-sm font-medium">{selectedFile.name}</span>
                                </div>
                              ) : (
                                <>
                                  <UploadCloud className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                                  <p className="text-sm text-gray-500">
                                    Drag and drop or click to upload
                                  </p>
                                  <p className="text-xs text-gray-400 mt-1">
                                    PDF, JPG, PNG, DOC up to 10MB
                                  </p>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            variant="outline"
                            onClick={() => setIsUploadDialogOpen(false)}
                          >
                            Cancel
                          </Button>
                          <Button
                            className="bg-primary"
                            onClick={handleUploadRecord}
                            disabled={uploadingRecord}
                          >
                            {uploadingRecord ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Uploading...
                              </>
                            ) : (
                              "Upload Record"
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent>
                  {recordsLoading ? (
                    <div className="flex justify-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : medicalRecords?.length === 0 ? (
                    <div className="text-center py-8">
                      <FileText className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-gray-900 mb-1">No Records Found</h3>
                      <p className="text-gray-500 mb-4">
                        Upload your medical records to keep track of your health history
                      </p>
                      <Button
                        className="bg-primary text-white"
                        onClick={() => setIsUploadDialogOpen(true)}
                      >
                        <Plus className="h-4 w-4 mr-2" /> Upload First Record
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {medicalRecords?.map((record) => (
                        <div
                          key={record.id}
                          className="border rounded-lg bg-background overflow-hidden"
                        >
                          <div className="flex justify-between items-center p-4 cursor-pointer hover:bg-gray-50" 
                               onClick={() => {
                                 // Toggle expanded state
                               }}>
                            <div className="flex items-center gap-3">
                              <div className="bg-primary/10 p-2 rounded-full">
                                <FileText className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-medium">{record.title}</h4>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <span>{formatDate(record.date)}</span>
                                  <span>•</span>
                                  <Badge variant="outline">{record.type}</Badge>
                                </div>
                              </div>
                            </div>
                            <ChevronDown className="h-5 w-5 text-gray-400" />
                          </div>
                          <div className="px-4 pb-4">
                            <p className="text-gray-600 text-sm mb-3">
                              {record.description}
                            </p>
                            {record.fileUrl && (
                              <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                                <FileText className="h-4 w-4 text-gray-500" />
                                <a
                                  href={record.fileUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-primary text-sm hover:underline"
                                >
                                  View Document
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Medications Tab */}
            {activeTab === "medications" && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Medications</CardTitle>
                      <CardDescription>
                        Track your prescribed medications and schedules
                      </CardDescription>
                    </div>
                    <Button
                      className="bg-primary text-white"
                      onClick={() => {
                        toast({
                          title: "Feature in development",
                          description: "The medication tracking feature is coming soon.",
                        });
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" /> Add Medication
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Pill className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                    <h3 className="text-lg font-medium text-gray-900 mb-1">No Medications Found</h3>
                    <p className="text-gray-500 mb-2">
                      You don't have any medications tracked yet
                    </p>
                    <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 max-w-md mx-auto mt-6">
                      <div className="flex items-start">
                        <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-amber-800">Medication Tracking</h4>
                          <p className="text-xs text-amber-700 mt-1">
                            Your medications will appear here after a doctor prescribes them during a consultation.
                            You can also manually add medications to track your schedule and dosage.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
