import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User, InsertConsultation } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Loader2,
  Star,
  StarHalf,
  MapPin,
  Briefcase,
  Calendar as CalendarIcon,
  Clock,
  CheckCircle,
  User as UserIcon,
  Video,
  MessageSquare,
  ClipboardList,
  BadgeCheck,
  ChevronLeft,
} from "lucide-react";

export default function DoctorProfile() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [timeSlot, setTimeSlot] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [symptoms, setSymptoms] = useState<string[]>([]);

  // Fetch doctor data
  const { data: doctor, isLoading } = useQuery<User>({
    queryKey: [`/api/doctors/${id}`],
    queryFn: async () => {
      const response = await fetch(`/api/doctors/${id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch doctor");
      }
      return response.json();
    },
  });

  // Book consultation mutation
  const bookConsultationMutation = useMutation({
    mutationFn: async (consultationData: InsertConsultation) => {
      const res = await apiRequest("POST", "/api/consultations", consultationData);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/consultations"] });
      setIsDialogOpen(false);
      toast({
        title: "Appointment booked successfully",
        description: `Your consultation with Dr. ${doctor?.fullName} has been scheduled.`,
      });
      navigate(`/consultation/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to book appointment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Function to handle booking consultation
  const handleBookConsultation = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to book a consultation",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    if (!date || !timeSlot) {
      toast({
        title: "Incomplete booking details",
        description: "Please select both a date and time for your consultation",
        variant: "destructive",
      });
      return;
    }

    // Combine date and time slot
    const scheduledDateTime = new Date(date);
    const [hours, minutes] = timeSlot.split(":").map(Number);
    scheduledDateTime.setHours(hours, minutes, 0, 0);

    // Ensure we're working with a valid date
    if (isNaN(scheduledDateTime.getTime())) {
      toast({
        title: "Invalid date/time",
        description: "Please select a valid date and time for your consultation",
        variant: "destructive",
      });
      return;
    }

    bookConsultationMutation.mutate({
      patientId: user.id,
      doctorId: parseInt(id),
      scheduledAt: scheduledDateTime,
      symptoms,
      notes,
      status: "pending",
    });
  };

  // Function to render star ratings
  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-warning text-xs fill-current" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-warning text-xs fill-current" />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-warning text-xs" />);
    }

    return stars;
  };

  // Generate time slots for the selected date
  const getTimeSlots = () => {
    // Example time slots from 9:00 AM to 5:00 PM
    const slots = [];
    for (let hour = 9; hour <= 17; hour++) {
      slots.push(`${hour}:00`);
      if (hour < 17) {
        slots.push(`${hour}:30`);
      }
    }
    return slots;
  };

  // Generate specializations as badges
  const specializations = doctor?.specialization
    ? doctor.specialization.split(",").map((s) => s.trim())
    : [];

  return (
    <div className="bg-background min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          className="mb-6 flex items-center text-gray-600"
          onClick={() => navigate("/doctors")}
        >
          <ChevronLeft className="h-4 w-4 mr-2" /> Back to Doctors
        </Button>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : !doctor ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <h3 className="text-lg font-medium text-gray-900">Doctor not found</h3>
            <p className="mt-2 text-sm text-gray-500">
              The doctor you're looking for doesn't exist or has been removed.
            </p>
            <Button className="mt-4" onClick={() => navigate("/doctors")}>
              View All Doctors
            </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="md:col-span-1">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <img
                        src={doctor.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(doctor.fullName)}&background=0D8ABC&color=fff&size=256`}
                        alt={doctor.fullName}
                        className="w-32 h-32 rounded-full object-cover mb-4"
                      />
                      <h2 className="text-2xl font-bold text-gray-800">
                        {doctor.fullName}
                        {doctor.verified && (
                          <span className="verified-badge ml-2">
                            <BadgeCheck className="h-3 w-3 mr-1" /> Verified
                          </span>
                        )}
                      </h2>
                      <p className="text-primary font-medium">{doctor.specialization}</p>
                      <div className="flex items-center mt-2">
                        <div className="flex text-warning">
                          {renderStarRating(doctor.rating)}
                        </div>
                        <span className="text-gray-600 text-xs ml-1">
                          {doctor.rating.toFixed(1)} ({doctor.reviewCount} reviews)
                        </span>
                      </div>

                      <Separator className="my-4" />

                      <div className="w-full space-y-2">
                        <div className="flex items-center justify-center">
                          <Briefcase className="text-primary mr-2 h-4 w-4" />
                          <span className="text-gray-600">
                            {doctor.experience ? `${doctor.experience}+ years experience` : "Experienced Professional"}
                          </span>
                        </div>
                        {doctor.location && (
                          <div className="flex items-center justify-center">
                            <MapPin className="text-primary mr-2 h-4 w-4" />
                            <span className="text-gray-600">{doctor.location}</span>
                          </div>
                        )}
                      </div>

                      <div className="mt-6 space-y-2 w-full">
                        <Button
                          className="w-full bg-primary text-white"
                          onClick={() => setIsDialogOpen(true)}
                        >
                          <Video className="mr-2 h-4 w-4" /> Book Video Consultation
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => {
                            toast({
                              title: "Feature coming soon",
                              description: "Message functionality will be available soon.",
                            });
                          }}
                        >
                          <MessageSquare className="mr-2 h-4 w-4" /> Send Message
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle className="text-lg">Consultation Fee</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <p className="text-3xl font-bold text-primary">$75</p>
                      <p className="text-gray-500 text-sm">per video consultation</p>
                    </div>
                    <Separator className="my-4" />
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li className="flex items-start">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                        <span>30-minute video consultation</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                        <span>Secure prescription if needed</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                        <span>Follow-up messages for 3 days</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                        <span>Medical document upload</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="md:col-span-2">
                <Card>
                  <CardHeader className="pb-3">
                    <h3 className="text-lg font-semibold">Doctor Information</h3>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="about">
                      <TabsList>
                        <TabsTrigger value="about">About</TabsTrigger>
                        <TabsTrigger value="expertise">Expertise</TabsTrigger>
                        <TabsTrigger value="reviews">Reviews</TabsTrigger>
                      </TabsList>
                      <TabsContent value="about" className="mt-4">
                        <div className="space-y-4">
                          <div>
                            <h3 className="text-lg font-semibold mb-2">Biography</h3>
                            <p className="text-gray-600">
                              {doctor.bio ||
                                `Dr. ${doctor.fullName} is a highly qualified ${doctor.specialization} with ${doctor.experience || "several"} years of experience in the field. With a patient-centered approach to healthcare, Dr. ${doctor.fullName.split(" ")[0]} is dedicated to providing quality care and personalized treatment plans.`}
                            </p>
                          </div>

                          <Separator />

                          <div>
                            <h3 className="text-lg font-semibold mb-2">Specializations</h3>
                            <div className="flex flex-wrap gap-2">
                              {specializations.map((spec, index) => (
                                <Badge
                                  key={index}
                                  variant="outline"
                                  className="bg-primary bg-opacity-10 text-primary"
                                >
                                  {spec}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <Separator />

                          <div>
                            <h3 className="text-lg font-semibold mb-2">Languages</h3>
                            <div className="flex flex-wrap gap-2">
                              <Badge variant="outline">English</Badge>
                              <Badge variant="outline">Spanish</Badge>
                            </div>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="expertise" className="mt-0">
                        <div className="space-y-4">
                          <div>
                            <h3 className="text-lg font-semibold mb-2">Areas of Expertise</h3>
                            <ul className="list-disc list-inside space-y-1 text-gray-600">
                              {specializations.map((spec, index) => (
                                <li key={index}>{spec}</li>
                              ))}
                              <li>Preventive Care</li>
                              <li>Chronic Disease Management</li>
                              <li>Patient Education</li>
                            </ul>
                          </div>

                          <Separator />

                          <div>
                            <h3 className="text-lg font-semibold mb-2">Education & Training</h3>
                            <div className="space-y-3">
                              <div>
                                <p className="font-medium">Medical Degree</p>
                                <p className="text-gray-600">Harvard Medical School</p>
                                <p className="text-sm text-gray-500">2005 - 2009</p>
                              </div>
                              <div>
                                <p className="font-medium">Residency</p>
                                <p className="text-gray-600">
                                  Johns Hopkins Hospital, {doctor.specialization}
                                </p>
                                <p className="text-sm text-gray-500">2009 - 2013</p>
                              </div>
                              <div>
                                <p className="font-medium">Fellowship</p>
                                <p className="text-gray-600">
                                  Mayo Clinic, Advanced {doctor.specialization}
                                </p>
                                <p className="text-sm text-gray-500">2013 - 2015</p>
                              </div>
                            </div>
                          </div>

                          <Separator />

                          <div>
                            <h3 className="text-lg font-semibold mb-2">Publications</h3>
                            <div className="space-y-2 text-gray-600">
                              <p className="text-sm">
                                "Advances in {doctor.specialization} Treatment Approaches" - 
                                Journal of Medical Sciences, 2019
                              </p>
                              <p className="text-sm">
                                "Patient Outcomes in Telemedicine vs. In-person Consultations" - 
                                Healthcare Innovation Journal, 2021
                              </p>
                            </div>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="reviews" className="mt-0">
                        <div className="space-y-6">
                          <div className="flex items-center">
                            <div className="flex-1">
                              <h3 className="text-lg font-semibold">Patient Reviews</h3>
                              <p className="text-gray-600">Based on {doctor.reviewCount} reviews</p>
                            </div>
                            <div className="text-right">
                              <div className="text-3xl font-bold text-primary">
                                {doctor.rating ? doctor.rating.toFixed(1) : "0.0"}
                                <span className="text-lg text-gray-500">/5</span>
                              </div>
                              <div className="flex text-warning justify-end">
                                {renderStarRating(doctor.rating || 0)}
                              </div>
                            </div>
                          </div>

                          <Separator />

                          {/* Sample reviews - in a real app these would come from an API */}
                          <div className="space-y-4">
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="font-medium">Sarah Johnson</h4>
                                <div className="flex text-warning">
                                  {renderStarRating(5)}
                                </div>
                              </div>
                              <p className="text-sm text-gray-500 mb-2">3 weeks ago</p>
                              <p className="text-gray-600">
                                Dr. {doctor.fullName} was very thorough and took the time to explain my 
                                condition and treatment options. The video consultation was seamless 
                                and I felt like I was in an actual office visit. Highly recommend!
                              </p>
                            </div>

                            <Separator />

                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="font-medium">Robert Chen</h4>
                                <div className="flex text-warning">
                                  {renderStarRating(4)}
                                </div>
                              </div>
                              <p className="text-sm text-gray-500 mb-2">2 months ago</p>
                              <p className="text-gray-600">
                                Great experience with Dr. {doctor.fullName}. Very knowledgeable and 
                                professional. The only reason for 4 stars instead of 5 is because the 
                                consultation started about 10 minutes late. Otherwise, excellent care!
                              </p>
                            </div>

                            <Separator />

                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="font-medium">Maria Rodriguez</h4>
                                <div className="flex text-warning">
                                  {renderStarRating(5)}
                                </div>
                              </div>
                              <p className="text-sm text-gray-500 mb-2">4 months ago</p>
                              <p className="text-gray-600">
                                I've been seeing Dr. {doctor.fullName} for my chronic condition for 
                                several months now. The telemedicine platform makes it so convenient, 
                                and Dr. {doctor.fullName.split(" ")[0]} always provides personalized care. The 
                                prescription delivery is also very prompt.
                              </p>
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>

                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Available Appointments</CardTitle>
                    <CardDescription>
                      Select a date and time to book your consultation
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          className="rounded-md border"
                          disabled={(date) => {
                            const today = new Date();
                            today.setHours(0, 0, 0, 0);
                            return date < today;
                          }}
                        />
                      </div>
                      <div>
                        <h3 className="text-md font-medium mb-2 flex items-center">
                          <Clock className="mr-2 h-4 w-4 text-primary" /> 
                          Available Time Slots
                        </h3>
                        {!date ? (
                          <div className="text-gray-500 text-sm italic">
                            Please select a date to see available time slots
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 gap-2">
                            {getTimeSlots().map((slot) => (
                              <Button
                                key={slot}
                                variant={timeSlot === slot ? "default" : "outline"}
                                className={`text-sm ${timeSlot === slot ? "bg-primary text-white" : ""}`}
                                onClick={() => setTimeSlot(slot)}
                              >
                                {slot}
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full bg-primary text-white"
                      onClick={() => setIsDialogOpen(true)}
                      disabled={!date || !timeSlot}
                    >
                      Book Appointment
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>

            {/* Booking confirmation dialog */}
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Confirm Your Appointment</DialogTitle>
                  <DialogDescription>
                    Review your consultation details with Dr. {doctor.fullName}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="flex items-center">
                    <UserIcon className="h-5 w-5 text-primary mr-2" />
                    <span className="font-medium">Dr. {doctor.fullName}</span>
                    <span className="text-gray-500 text-sm ml-2">{doctor.specialization}</span>
                  </div>
                  
                  {date && timeSlot && (
                    <div className="flex items-center">
                      <CalendarIcon className="h-5 w-5 text-primary mr-2" />
                      <span>
                        {date.toLocaleDateString('en-US', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })} at {timeSlot}
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-center">
                    <Video className="h-5 w-5 text-primary mr-2" />
                    <span>30-minute Video Consultation</span>
                  </div>

                  <Separator />
                  
                  <div>
                    <label className="text-sm font-medium">Your Symptoms (optional)</label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {["Headache", "Fever", "Cough", "Fatigue", "Nausea", "Dizziness"].map((symptom) => (
                        <Badge
                          key={symptom}
                          variant={symptoms.includes(symptom) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => {
                            if (symptoms.includes(symptom)) {
                              setSymptoms(symptoms.filter(s => s !== symptom));
                            } else {
                              setSymptoms([...symptoms, symptom]);
                            }
                          }}
                        >
                          {symptom}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Additional Notes (optional)</label>
                    <Textarea
                      placeholder="Please share any additional information that would help the doctor prepare for your consultation..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button 
                    className="bg-primary"
                    onClick={handleBookConsultation}
                    disabled={bookConsultationMutation.isPending}
                  >
                    {bookConsultationMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                        Booking...
                      </>
                    ) : (
                      "Confirm Booking"
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </>
        )}
      </div>
    </div>
  );
}
