import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Consultation, Message, InsertMessage } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Loader2,
  Clock,
  Calendar,
  ChevronLeft,
  MessageSquare,
  PhoneCall,
  Video,
  FileText,
  ClipboardList,
  SendHorizonal,
  Paperclip,
  Pill,
  ChevronRight,
  AlertTriangle,
  X,
  Maximize2,
  Minimize2,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  UserPlus,
  Phone,
  MoreVertical,
  Plus,
} from "lucide-react";

type VideoCallState = {
  isJoined: boolean;
  isAudioMuted: boolean;
  isVideoMuted: boolean;
  isFullScreen: boolean;
};

export default function ConsultationPage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("chat");
  const [message, setMessage] = useState("");
  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [videoCallState, setVideoCallState] = useState<VideoCallState>({
    isJoined: false,
    isAudioMuted: false,
    isVideoMuted: false,
    isFullScreen: false,
  });
  const [prescription, setPrescription] = useState({
    medications: [{ name: "", dosage: "", instructions: "" }],
    notes: "",
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  // Redirect if not logged in
  if (!user) {
    navigate("/auth");
    return null;
  }

  // Fetch consultation
  const {
    data: consultation,
    isLoading: consultationLoading,
    error: consultationError,
  } = useQuery<Consultation>({
    queryKey: [`/api/consultations/${id}`],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/consultations/${id}`);
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "Failed to fetch consultation");
        }

        return data;
      } catch (error) {
        console.error("Consultation fetch error:", error);
        throw error;
      }
    },
    retry: 1,
  });

  // Fetch doctor and patient information
  const {
    data: otherParticipant,
    isLoading: participantLoading,
  } = useQuery({
    queryKey: [`/api/users/${user?.role === "patient" ? consultation?.doctorId : consultation?.patientId}`],
    queryFn: async () => {
      if (!consultation) return null;
      const participantId = user?.role === "patient" ? consultation.doctorId : consultation.patientId;
      const response = await fetch(`/api/users/${participantId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch participant");
      }
      return response.json();
    },
    enabled: !!consultation,
  });

  // Fetch messages
  const {
    data: messages,
    isLoading: messagesLoading,
    error: messagesError,
  } = useQuery<Message[]>({
    queryKey: [`/api/consultations/${id}/messages`],
    queryFn: async () => {
      const response = await fetch(`/api/consultations/${id}/messages`);
      if (!response.ok) {
        throw new Error("Failed to fetch messages");
      }
      return response.json();
    },
    refetchInterval: 5000, // Poll for new messages every 5 seconds
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageData: InsertMessage) => {
      const res = await apiRequest("POST", `/api/consultations/${id}/messages`, messageData);
      return await res.json();
    },
    onSuccess: (newMessage) => {
      // Update messages cache immediately
      queryClient.setQueryData([`/api/consultations/${id}/messages`], (oldData: Message[] | undefined) => {
        return oldData ? [...oldData, newMessage] : [newMessage];
      });

      // Then invalidate to ensure sync
      queryClient.invalidateQueries({ queryKey: [`/api/consultations/${id}/messages`] });
      setMessage("");

      // Scroll to bottom after message is added
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // Handle sending a message
  const handleSendMessage = () => {
    if (!message.trim()) return;

    sendMessageMutation.mutate({
      consultationId: parseInt(id),
      senderId: user.id,
      content: message,
    });
  };

  // Handle video call initialization
  useEffect(() => {
    if (isVideoCallActive && videoCallState.isJoined) {
      const initializeCamera = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ 
            video: true,
            audio: true 
          });

          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }

          // For demo purposes, we'll mock the remote video
          // with a delayed timer to simulate connection establishment
          setTimeout(() => {
            if (remoteVideoRef.current) {
              // In a real app, this would come from the WebRTC peer connection
              // Here we're just cloning the user's own stream for demo purposes
              remoteVideoRef.current.srcObject = stream.clone();

              toast({
                title: "Connected with doctor",
                description: "Video call has been successfully established",
              });
            }
          }, 2000);

          toast({
            title: "Video call started",
            description: "Connecting to remote participant...",
          });
        } catch (error) {
          console.error("Error accessing camera:", error);
          toast({
            title: "Camera access error",
            description: "Could not access your camera or microphone. Please ensure you've granted camera permissions.",
            variant: "destructive",
          });
          setVideoCallState(prev => ({
            ...prev,
            isJoined: false,
          }));
        }
      };

      initializeCamera();

      return () => {
        // Clean up media streams
        if (localVideoRef.current && localVideoRef.current.srcObject) {
          const tracks = (localVideoRef.current.srcObject as MediaStream).getTracks();
          tracks.forEach(track => track.stop());
        }
        if (remoteVideoRef.current && remoteVideoRef.current.srcObject) {
          const tracks = (remoteVideoRef.current.srcObject as MediaStream).getTracks();
          tracks.forEach(track => track.stop());
        }
      };
    }
  }, [isVideoCallActive, videoCallState.isJoined, toast]);

  // Format message time
  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Add medication field
  const addMedication = () => {
    setPrescription({
      ...prescription,
      medications: [
        ...prescription.medications,
        { name: "", dosage: "", instructions: "" }
      ]
    });
  };

  // Remove medication field
  const removeMedication = (index: number) => {
    const medications = [...prescription.medications];
    medications.splice(index, 1);
    setPrescription({
      ...prescription,
      medications
    });
  };

  // Update medication field
  const updateMedication = (index: number, field: string, value: string) => {
    const medications = [...prescription.medications];
    medications[index] = {
      ...medications[index],
      [field]: value
    };
    setPrescription({
      ...prescription,
      medications
    });
  };

  // Start video call
  const startVideoCall = useCallback(async () => {
    try {
      // Request access to user's media devices
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });

      // Set local video stream
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = mediaStream;
      }

      // In a real app with WebRTC, we would connect to a signaling server
      // and set up peer connections. For now, we'll simulate a remote stream
      // with a delayed connection to demonstrate UI functionality
      setTimeout(() => {
        // Check if component is still mounted
        if (remoteVideoRef.current) {
          // In a real implementation, this would be a remote peer's stream
          // For demo purposes, we're using a placeholder
          toast({
            title: "Doctor connected",
            description: "The other participant has joined the call",
          });
        }
      }, 3000);

      // Update state
      setVideoCallState(prev => ({
        ...prev,
        isJoined: true
      }));

      // Set video call active
      setIsVideoCallActive(true);

      toast({
        title: "Video call started",
        description: "Connected to local camera and microphone",
      });

    } catch (error) {
      console.error('Error accessing media devices:', error);
      toast({
        title: "Video call failed",
        description: "Could not access camera or microphone. Please ensure your camera and microphone are connected and you've granted permission to use them.",
        variant: "destructive",
      });
    }
  }, [toast]);

  // Handle video call controls
  const handleVideoControl = (control: keyof VideoCallState) => {
    setVideoCallState(prev => ({
      ...prev,
      [control]: !prev[control],
    }));

    // Handle muting audio/video streams
    if (control === "isAudioMuted" || control === "isVideoMuted") {
      if (localVideoRef.current && localVideoRef.current.srcObject) {
        const mediaStream = localVideoRef.current.srcObject as MediaStream;
        const tracks = control === "isAudioMuted" 
          ? mediaStream.getAudioTracks() 
          : mediaStream.getVideoTracks();

        tracks.forEach(track => {
          track.enabled = !track.enabled;
        });
      }
    }

    // Handle full screen
    if (control === "isFullScreen") {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
          toast({
            title: "Fullscreen error",
            description: `Error attempting to enable fullscreen: ${err.message}`,
            variant: "destructive",
          });
        });
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen().catch(err => {
            console.error("Error exiting fullscreen:", err);
          });
        }
      }
    }
  };

  // Handle prescription submit
  const handlePrescriptionSubmit = () => {
    // In a real app, this would send the prescription to the backend
    toast({
      title: "Prescription saved",
      description: "The prescription has been saved and sent to the patient",
    });
  };

  return (
    <div className="bg-background min-h-screen py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <Button
          variant="ghost"
          className="mb-6 flex items-center text-gray-600"
          onClick={() => navigate(user.role === "patient" ? "/dashboard" : "/")}
        >
          <ChevronLeft className="h-4 w-4 mr-2" /> {user.role === "patient" ? "Back to Dashboard" : "Back to Home"}
        </Button>

        {consultationLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : consultationError ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Error Loading Consultation</h3>
            <p className="text-gray-500 mb-4">
              {consultationError instanceof Error ? consultationError.message : "An error occurred"}
            </p>
            <Button onClick={() => navigate("/dashboard")}>
              Return to Dashboard
            </Button>
          </div>
        ) : !consultation ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <h3 className="text-lg font-medium text-gray-900">Consultation not found</h3>
            <p className="mt-2 text-sm text-gray-500">
              The consultation you're looking for doesn't exist or has been removed.
            </p>
            <Button className="mt-4" onClick={() => navigate("/dashboard")}>
              Return to Dashboard
            </Button>
          </div>
        ) : (
          <>
            {isVideoCallActive ? (
              <div className="fixed inset-0 bg-black z-50 flex flex-col p-4">
                <div className="flex justify-between items-center text-white mb-4 px-4">
                  <div className="flex items-center">
                    <div className="mr-4">
                      <Badge className="bg-red-500">LIVE</Badge>
                    </div>
                    <h2 className="text-lg font-medium">
                      Consultation with {otherParticipant ? otherParticipant.fullName : (participantLoading ? "Loading..." : "Unknown")}
                    </h2>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-white hover:bg-gray-800 rounded-full"
                    onClick={() => {
                      setIsVideoCallActive(false);
                      setVideoCallState({
                        isJoined: false,
                        isAudioMuted: false,
                        isVideoMuted: false,
                        isFullScreen: false,
                      });
                    }}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <div className="flex-1 relative">
                  {/* Remote Video (Doctor or Patient) */}
                  <div className="w-full h-full bg-gray-900 rounded-lg overflow-hidden">
                    <video
                      ref={remoteVideoRef}
                      className="w-full h-full object-cover"
                      autoPlay
                      playsInline
                      poster="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80"
                    ></video>
                  </div>

                  {/* Local Video */}
                  <div className="absolute bottom-4 right-4 w-1/4 max-w-[240px] aspect-video rounded-lg overflow-hidden border-2 border-white shadow-lg">
                    <video
                      ref={localVideoRef}
                      className="w-full h-full object-cover"
                      autoPlay
                      playsInline
                      muted
                    ></video>
                  </div>
                </div>

                <div className="flex justify-center items-center space-x-4 py-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-full p-3 ${videoCallState.isAudioMuted ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'}`}
                    onClick={() => handleVideoControl('isAudioMuted')}
                  >
                    {videoCallState.isAudioMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-full p-3 ${videoCallState.isVideoMuted ? 'bg-red-500 text-white' : 'bg-gray-800 text-white'}`}
                    onClick={() => handleVideoControl('isVideoMuted')}
                  >
                    {videoCallState.isVideoMuted ? <CameraOff className="h-5 w-5" /> : <Camera className="h-5 w-5" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full p-3 bg-gray-800 text-white"
                    onClick={() => handleVideoControl('isFullScreen')}
                  >
                    {videoCallState.isFullScreen ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full p-4 bg-red-500 text-white"
                    onClick={() => {
                      setIsVideoCallActive(false);
                      setVideoCallState({
                        isJoined: false,
                        isAudioMuted: false,
                        isVideoMuted: false,
                        isFullScreen: false,
                      });
                    }}
                  >
                    <Phone className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Consultation Info */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Consultation Details</CardTitle>
                  <CardDescription>
                    {consultation.status === "completed" 
                      ? "This consultation has ended" 
                      : "Manage your consultation"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium text-gray-500">Status</h3>
                    <Badge 
                      className={
                        consultation.status === "completed" ? "bg-green-500" : 
                        consultation.status === "scheduled" ? "bg-blue-500" :
                        consultation.status === "cancelled" ? "bg-red-500" : "bg-yellow-500"
                      }
                    >
                      {consultation.status.charAt(0).toUpperCase() + consultation.status.slice(1)}
                    </Badge>
                  </div>

                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium text-gray-500">
                      {user.role === "patient" ? "Doctor" : "Patient"}
                    </h3>
                    <span className="text-sm text-gray-900">
                      {otherParticipant ? otherParticipant.fullName : (participantLoading ? "Loading..." : "Unknown")}
                    </span>
                  </div>

                  {consultation.scheduledAt && (
                    <>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                          <h3 className="text-sm font-medium text-gray-500">Date</h3>
                        </div>
                        <span className="text-sm text-gray-900">
                          {new Date(consultation.scheduledAt).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-gray-400 mr-2" />
                          <h3 className="text-sm font-medium text-gray-500">Time</h3>
                        </div>
                        <span className="text-sm text-gray-900">
                          {new Date(consultation.scheduledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </>
                  )}

                  {consultation.symptoms && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-2">Symptoms</h3>
                      <div className="flex flex-wrap gap-2">
                        {(typeof consultation.symptoms === 'string' ? [consultation.symptoms] : consultation.symptoms).map((symptom, index) => (
                          <Badge key={index} variant="outline" className="bg-gray-100 text-gray-700">
                            {symptom}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {consultation.status === "scheduled" && (
                    <div className="pt-2">
                      <Button className="w-full mb-2" onClick={startVideoCall}>
                        <Video className="h-4 w-4 mr-2" /> Start Video Call
                      </Button>
                      <Button variant="outline" className="w-full">
                        <PhoneCall className="h-4 w-4 mr-2" /> Start Voice Call
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Main Content Area */}
            <div className="lg:col-span-2">
              <Card className="h-full flex flex-col">
                <CardHeader className="pb-0">
                  <div className="flex space-x-4">
                    <Button
                      variant={activeTab === "chat" ? "default" : "ghost"}
                      onClick={() => setActiveTab("chat")}
                      className="flex items-center"
                    >
                      <MessageSquare className="h-4 w-4 mr-2" /> Messages
                    </Button>
                    <Button
                      variant={activeTab === "prescription" ? "default" : "ghost"}
                      onClick={() => setActiveTab("prescription")}
                      className="flex items-center"
                    >
                      <FileText className="h-4 w-4 mr-2" /> Prescription
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="flex-grow p-0">
                  {activeTab === "chat" && (
                    <div className="flex flex-col h-[600px]">
                      {/* Messages */}
                      <ScrollArea className="flex-grow p-4">
                        {messagesLoading ? (
                          <div className="flex justify-center items-center h-full">
                            <Loader2 className="h-6 w-6 animate-spin text-primary" />
                          </div>
                        ) : messages?.length === 0 ? (
                          <div className="flex flex-col items-center justify-center h-full text-center p-6">
                            <MessageSquare className="h-12 w-12 text-gray-300 mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-1">No Messages Yet</h3>
                            <p className="text-gray-500 max-w-md">
                              Start the conversation by sending a message about your symptoms or questions
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {messages?.map((msg) => (
                              <div
                                key={msg.id}
                                className={`flex ${msg.senderId === user.id ? "justify-end" : "justify-start"}`}
                              >
                                <div
                                  className={`max-w-[80%] ${
                                    msg.senderId === user.id
                                      ? "bg-primary text-white rounded-tl-lg rounded-tr-lg rounded-bl-lg"
                                      : "bg-gray-100 text-gray-800 rounded-tl-lg rounded-tr-lg rounded-br-lg"
                                  } p-3`}
                                >
                                  <p className="text-sm">{msg.content}</p>
                                  <p className={`text-xs mt-1 ${msg.senderId === user.id ? "text-primary-foreground/70" : "text-gray-500"}`}>
                                    {msg.sentAt ? formatMessageTime(msg.sentAt.toString()) : ""}
                                  </p>
                                </div>
                              </div>
                            ))}
                            <div ref={messagesEndRef} />
                          </div>
                        )}
                      </ScrollArea>

                      {/* Message Input */}
                      <div className="p-4 border-t">
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="rounded-full"
                            onClick={() => {
                              toast({
                                title: "Feature coming soon",
                                description: "File attachments will be available in the future.",
                              });
                            }}
                          >
                            <Paperclip className="h-5 w-5 text-gray-500" />
                          </Button>
                          <Input
                            placeholder="Type your message..."
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                handleSendMessage();
                              }
                            }}
                            className="flex-grow"
                          />
                          <Button
                            size="icon"
                            className="rounded-full bg-primary"
                            onClick={handleSendMessage}
                            disabled={!message.trim() || sendMessageMutation.isPending}
                          >
                            {sendMessageMutation.isPending ? (
                              <Loader2 className="h-5 w-5 animate-spin" />
                            ) : (
                              <SendHorizonal className="h-5 w-5" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === "prescription" && (
                    <div className="p-6">
                      {user.role !== "doctor" && !consultation.diagnosis ? (
                        <div className="flex flex-col items-center justify-center h-[500px] text-center">
                          <ClipboardList className="h-12 w-12 text-gray-300 mb-4" />
                          <h3 className="text-lg font-medium text-gray-900 mb-1">No Prescription Available</h3>
                          <p className="text-gray-500 max-w-md">
                            The doctor hasn't created a prescription for this consultation yet
                          </p>
                        </div>
                      ) : user.role === "doctor" ? (
                        <div className="space-y-6">
                          <div>
                            <h3 className="text-lg font-medium mb-2">Create Prescription</h3>
                            <p className="text-gray-500 text-sm mb-4">
                              Prescribe medications and instructions for the patient
                            </p>
                          </div>

                          <div className="space-y-4">
                            <div>
                              <h4 className="text-sm font-medium mb-2">Medications</h4>
                              {prescription.medications.map((med, index) => (
                                <div key={index} className="rounded-md border p-4 mb-3">
                                  <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-sm font-medium">Medication #{index + 1}</h4>
                                    {prescription.medications.length > 1 && (
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-6 w-6 rounded-full"
                                        onClick={() => removeMedication(index)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    )}
                                  </div>
                                  <div className="space-y-3">
                                    <div>
                                      <label className="text-xs font-medium">Medication Name</label>
                                      <Input
                                        placeholder="e.g., Amoxicillin"
                                        value={med.name}
                                        onChange={(e) => updateMedication(index, "name", e.target.value)}
                                        className="mt-1"
                                      />
                                    </div>
                                    <div>
                                      <label className="text-xs font-medium">Dosage</label>
                                      <Input
                                        placeholder="e.g., 500mg, twice daily"
                                        value={med.dosage}
                                        onChange={(e) => updateMedication(index, "dosage", e.target.value)}
                                        className="mt-1"
                                      />
                                    </div>
                                    <div>
                                      <label className="text-xs font-medium">Instructions</label>
                                      <Textarea
                                        placeholder="e.g., Take with food, for 7 days"
                                        value={med.instructions}
                                        onChange={(e) => updateMedication(index, "instructions", e.target.value)}
                                        className="mt-1"
                                        rows={2}
                                      />
                                    </div>
                                  </div>
                                </div>
                              ))}
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full mt-2"
                                onClick={addMedication}
                              >
                                <Plus className="h-4 w-4 mr-2" /> Add Another Medication
                              </Button>
                            </div>

                            <div>
                              <label className="text-sm font-medium">Additional Notes</label>
                              <Textarea
                                placeholder="Any additional instructions or follow-up recommendations..."
                                value={prescription.notes}
                                onChange={(e) => setPrescription({...prescription, notes: e.target.value})}
                                className="mt-1"
                                rows={4}
                              />
                            </div>

                            <div>
                              <label className="text-sm font-medium">Diagnosis</label>
                              <Textarea
                                placeholder="Enter your diagnosis..."
                                value={consultation.diagnosis || ""}
                                onChange={(e) => {
                                  // In a real app, this would update the consultation diagnosis
                                }}
                                className="mt-1"
                                rows={3}
                              />
                            </div>
                          </div>

                          <div className="flex justify-end">
                            <Button
                              className="bg-primary text-white"
                              onClick={handlePrescriptionSubmit}
                            >
                              Save Prescription
                            </Button>
                          </div>
                        </div>
                      ) : (
                        // Prescription view for patient
                        <div className="space-y-6">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-medium">Your Prescription</h3>
                            <Badge className="bg-green-500">Issued</Badge>
                          </div>

                          <Separator />

                          <div>
                            <h4 className="text-sm font-medium mb-2">Diagnosis</h4>
                            <p className="text-gray-700">{consultation.diagnosis}</p>
                          </div>

                          <Separator />

                          <div>
                            <h4 className="text-sm font-medium mb-3">Medications</h4>
                            <div className="space-y-4">
                              <div className="rounded-md border p-4">
                                <div className="flex items-center mb-2">
                                  <Pill className="h-5 w-5 text-primary mr-2" />
                                  <h5 className="font-medium">Amoxicillin</h5>
                                </div>
                                <div className="ml-7 space-y-1">
                                  <p className="text-sm"><span className="font-medium">Dosage:</span> 500mg, three times daily</p>
                                  <p className="text-sm"><span className="font-medium">Instructions:</span> Take with food for 7 days</p>
                                </div>
                              </div>

                              <div className="rounded-md border p-4">
                                <div className="flex items-center mb-2">
                                  <Pill className="h-5 w-5 text-primary mr-2" />
                                  <h5 className="font-medium">Ibuprofen</h5>
                                </div>
                                <div className="ml-7 space-y-1">
                                  <p className="text-sm"><span className="font-medium">Dosage:</span> 400mg, as needed</p>
                                  <p className="text-sm"><span className="font-medium">Instructions:</span> Take for pain relief, not more than 3 times daily</p>
                                </div>
                              </div>
                            </div>
                          </div>

                          <Separator />

                          <div>
                            <h4 className="text-sm font-medium mb-2">Additional Notes</h4>
                            <p className="text-gray-700">
                              Drink plenty of fluids and rest. Schedule a follow-up appointment in 10 days if symptoms persist. Avoid strenuous activity for at least 48 hours.
                            </p>
                          </div>

                          <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                            <div className="flex">
                              <div className="flex-shrink-0">
                                <svg className="h-5 w-5 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                                </svg>
                              </div>
                              <div className="ml-3">
                                <h5 className="text-sm font-medium text-blue-800">Order Medications</h5>
                                <p className="text-xs text-blue-700 mt-1">
                                  Your prescribed medications can be ordered through our pharmacy with delivery right to your door.
                                </p>
                                <Button 
                                  className="mt-2 text-xs h-7 bg-blue-500 hover:bg-blue-600"
                                  onClick={() => navigate("/pharmacy")}
                                >
                                  Order Medications
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
          )}
          </>
        )}
      </div>
    </div>
  );
}