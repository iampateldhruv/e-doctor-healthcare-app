import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import DoctorCard from "@/components/doctor/doctor-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search } from "lucide-react";

export default function DoctorListing() {
  const [specialization, setSpecialization] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const { data: doctors, isLoading } = useQuery<User[]>({
    queryKey: ["/api/doctors", specialization],
    queryFn: async () => {
      const url = new URL("/api/doctors", window.location.origin);
      if (specialization) {
        url.searchParams.append("specialization", specialization);
      }
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch doctors");
      }
      return response.json();
    }
  });

  const filteredDoctors = doctors?.filter(doctor => 
    doctor.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (doctor.specialization && doctor.specialization.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (doctor.location && doctor.location.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const specializations = [
    "All Specialists",
    "Cardiologist",
    "Neurologist",
    "Dermatologist",
    "Pediatrician",
    "Orthopedic",
    "General Medicine",
    "Psychiatry"
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-textColor mb-2">Find Doctors</h1>
        <p className="text-gray-600">Connect with highly rated doctors specializing in various fields</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative w-full md:w-1/2">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
          <Input 
            placeholder="Search by name, specialization, or location" 
            className="pl-10" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select 
          value={specialization} 
          onValueChange={(value) => setSpecialization(value === "All Specialists" ? "" : value)}
        >
          <SelectTrigger className="w-full md:w-[200px]">
            <SelectValue placeholder="All Specialists" />
          </SelectTrigger>
          <SelectContent>
            {specializations.map((spec) => (
              <SelectItem key={spec} value={spec}>
                {spec}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center space-x-4 mb-8 overflow-x-auto pb-2">
        {specializations.map((spec) => (
          <Button
            key={spec}
            variant={specialization === (spec === "All Specialists" ? "" : spec) ? "default" : "outline"}
            className="whitespace-nowrap rounded-full"
            onClick={() => setSpecialization(spec === "All Specialists" ? "" : spec)}
          >
            {spec}
          </Button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filteredDoctors?.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium">No doctors found</h3>
          <p className="text-gray-500 mt-2">Try adjusting your search criteria</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors?.map((doctor) => (
            <DoctorCard key={doctor.id} doctor={doctor} />
          ))}
        </div>
      )}
    </div>
  );
}
