import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Post, User, InsertPost } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Loader2,
  Search,
  Plus,
  Image,
  Link2,
  Heart,
  MessageSquare,
  Share2,
  Filter,
  ListFilter,
} from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import PostCard from "@/components/community/post-card";
import { useToast } from "@/hooks/use-toast";

type PostWithAuthor = Post & { author: User };

export default function Community() {
  // Temporarily mock user for development
  const user = null; // For development purposes
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newPost, setNewPost] = useState<{ title: string; content: string; tags: string }>({
    title: "",
    content: "",
    tags: "",
  });
  
  // Fetch posts
  const { data: posts, isLoading } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts", selectedTag],
    queryFn: async () => {
      const url = new URL("/api/posts", window.location.origin);
      if (selectedTag) {
        url.searchParams.append("tag", selectedTag);
      }
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch posts");
      }
      return response.json();
    }
  });

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: InsertPost) => {
      const res = await apiRequest("POST", "/api/posts", postData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setIsCreateDialogOpen(false);
      setNewPost({ title: "", content: "", tags: "" });
      toast({
        title: "Post created",
        description: "Your post has been published to the community.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCreatePost = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to create a post",
        variant: "destructive",
      });
      return;
    }

    if (user.role !== "doctor") {
      toast({
        title: "Only doctors can create posts",
        description: "Community health tips are shared by verified healthcare professionals",
        variant: "destructive",
      });
      return;
    }

    if (!newPost.title || !newPost.content) {
      toast({
        title: "Missing information",
        description: "Please provide a title and content for your post",
        variant: "destructive",
      });
      return;
    }

    const tagsArray = newPost.tags
      .split(",")
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0);

    createPostMutation.mutate({
      userId: user.id,
      title: newPost.title,
      content: newPost.content,
      tags: tagsArray,
      imageUrl: null,
    });
  };

  // Extract all unique tags from posts
  const allTags = posts
    ? Array.from(
        new Set(
          posts.flatMap(post => (post.tags as string[]) || [])
        )
      )
    : [];

  // Filter posts by search query
  const filteredPosts = posts?.filter(
    post =>
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author?.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (post.tags as string[])?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="bg-background min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold text-textColor mb-2 font-sf-pro">Health Community</h1>
            <p className="text-gray-600">
              Connect with doctors and patients, share experiences, and get expert health tips
            </p>
          </div>
          <div className="mt-4 md:mt-0">
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary text-white">
                  <Plus className="mr-2 h-4 w-4" /> Create Post
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create a Community Post</DialogTitle>
                  <DialogDescription>
                    Share your health tips, advice, or insights with the community
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label htmlFor="title" className="text-sm font-medium">
                      Title
                    </label>
                    <Input
                      id="title"
                      placeholder="Enter a descriptive title"
                      value={newPost.title}
                      onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="content" className="text-sm font-medium">
                      Content
                    </label>
                    <Textarea
                      id="content"
                      placeholder="Share your health advice, tips, or experience..."
                      rows={5}
                      value={newPost.content}
                      onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="tags" className="text-sm font-medium">
                      Tags (comma separated)
                    </label>
                    <Input
                      id="tags"
                      placeholder="e.g. Nutrition, Heart Health, Wellness"
                      value={newPost.tags}
                      onChange={(e) => setNewPost({ ...newPost, tags: e.target.value })}
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="text-gray-500">
                      <Image className="h-4 w-4 mr-2" /> Add Image
                    </Button>
                    <Button variant="outline" size="sm" className="text-gray-500">
                      <Link2 className="h-4 w-4 mr-2" /> Add Link
                    </Button>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="bg-primary text-white"
                    onClick={handleCreatePost}
                    disabled={createPostMutation.isPending}
                  >
                    {createPostMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Publishing...
                      </>
                    ) : (
                      "Publish Post"
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          <div className="md:w-1/4">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Categories</h3>
                <Filter className="h-5 w-5 text-gray-500" />
              </div>
              <div className="space-y-2">
                <Button
                  variant="subtle"
                  className={`w-full justify-start ${!selectedTag ? "bg-primary/10 text-primary" : "text-gray-700"}`}
                  onClick={() => setSelectedTag(null)}
                >
                  All Topics
                </Button>
                {allTags.map((tag, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className={`w-full justify-start ${selectedTag === tag ? "bg-primary/10 text-primary" : "text-gray-700"}`}
                    onClick={() => setSelectedTag(tag)}
                  >
                    {tag}
                  </Button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Top Contributors</h3>
              <div className="space-y-4">
                {posts
                  ?.filter(post => post.author?.role === "doctor")
                  .slice(0, 3)
                  .map(post => (
                    <div key={post.author.id} className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarImage src={post.author.profilePicture} alt={post.author.fullName} />
                        <AvatarFallback>{post.author.fullName.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="text-sm font-medium">{post.author.fullName}</h4>
                        <p className="text-xs text-gray-500">{post.author.specialization}</p>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Community Guidelines</h3>
              <ul className="text-sm text-gray-600 space-y-2">
                <li>✓ Share factual health information</li>
                <li>✓ Be respectful and supportive</li>
                <li>✓ Protect personal information</li>
                <li>✓ Cite sources when relevant</li>
                <li>✗ No medical diagnoses or prescriptions</li>
                <li>✗ No promotional content or spam</li>
              </ul>
            </div>
          </div>

          <div className="md:w-3/4">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="flex flex-col sm:flex-row justify-between gap-4">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search posts..."
                    className="pl-10"
                  />
                </div>
                <div className="flex items-center">
                  <Button variant="outline" className="flex items-center ml-2">
                    <ListFilter className="h-4 w-4 mr-2" /> Filter
                  </Button>
                </div>
              </div>
            </div>

            <Tabs defaultValue="all" className="mb-6">
              <TabsList className="bg-white">
                <TabsTrigger value="all">All Posts</TabsTrigger>
                <TabsTrigger value="featured">Featured</TabsTrigger>
                <TabsTrigger value="popular">Most Popular</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="mt-4 space-y-6">
                {isLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredPosts?.length === 0 ? (
                  <div className="text-center py-12 bg-white rounded-lg">
                    <h3 className="text-lg font-medium text-gray-900">No posts found</h3>
                    <p className="mt-2 text-sm text-gray-500">
                      Try adjusting your search or filter criteria.
                    </p>
                  </div>
                ) : (
                  filteredPosts?.map(post => <PostCard key={post.id} post={post} />)
                )}
              </TabsContent>
              
              {/* Other tabs content would follow a similar pattern */}
              <TabsContent value="featured" className="mt-4 space-y-6">
                {filteredPosts?.slice(0, 2).map(post => <PostCard key={post.id} post={post} />)}
              </TabsContent>
              
              <TabsContent value="popular" className="mt-4 space-y-6">
                {filteredPosts?.sort((a, b) => b.likes - a.likes).slice(0, 3).map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </TabsContent>
              
              <TabsContent value="recent" className="mt-4 space-y-6">
                {filteredPosts?.sort((a, b) => 
                  new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                ).slice(0, 3).map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </TabsContent>
            </Tabs>

            <div className="bg-white rounded-xl shadow-sm p-6 mt-10">
              <h3 className="text-xl font-bold mb-4 font-sf-pro">Join the Conversation</h3>
              <div className="flex items-start mb-6">
                <Avatar className="w-10 h-10 mr-3">
                  <AvatarImage 
                    src={user?.profilePicture} 
                    alt={user?.fullName || "Guest User"} 
                  />
                  <AvatarFallback>
                    {user ? user.fullName.substring(0, 2).toUpperCase() : "GU"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <Textarea
                    placeholder="Share your health question or experience..."
                    className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    rows={3}
                  />
                  <div className="flex justify-between items-center mt-3">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                        <Image className="h-5 w-5" />
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                          />
                        </svg>
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                        <Link2 className="h-5 w-5" />
                      </Button>
                    </div>
                    <Button
                      className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90 transition duration-300"
                      onClick={() => {
                        if (!user) {
                          toast({
                            title: "Authentication required",
                            description: "Please log in to post in the community",
                            variant: "destructive",
                          });
                          return;
                        }
                        setIsCreateDialogOpen(true);
                      }}
                    >
                      Post to Community
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center mb-4">
                <h4 className="font-semibold">Recent Discussions</h4>
                <div className="text-sm">
                  <span className="text-primary cursor-pointer">Newest</span>
                  <span className="mx-2 text-gray-300">|</span>
                  <span className="text-gray-500 cursor-pointer">Popular</span>
                </div>
              </div>

              <div className="space-y-6">
                {/* Recent discussion items */}
                {filteredPosts?.slice(0, 2).map(post => (
                  <div key={post.id} className="border-b border-gray-200 pb-6">
                    <div className="flex items-center mb-2">
                      <Avatar className="w-8 h-8 mr-2">
                        <AvatarImage src={post.author.profilePicture} alt={post.author.fullName} />
                        <AvatarFallback>{post.author.fullName.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-semibold">
                          {post.author.fullName}{" "}
                          <span className="text-xs text-gray-500 ml-1">
                            {post.author.role === "doctor" ? post.author.specialization : "Patient"}
                          </span>
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(post.createdAt).toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </p>
                      </div>
                    </div>
                    <p className="text-sm mb-3">
                      {post.content.length > 150 
                        ? post.content.substring(0, 150) + "..." 
                        : post.content}
                    </p>
                    <div className="flex items-center text-sm">
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center mr-4">
                        <Heart className="mr-1 h-4 w-4" /> {post.likes}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center mr-4">
                        <MessageSquare className="mr-1 h-4 w-4" /> {post.comments}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center">
                        <Share2 className="mr-1 h-4 w-4" /> Share
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 text-center">
                <Button variant="link" className="text-primary font-medium">
                  View More Discussions
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
