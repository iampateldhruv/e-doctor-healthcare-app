import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Search, ShoppingCart, Upload, Filter, Clock } from "lucide-react";
import ProductCard from "@/components/pharmacy/product-card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCart } from "@/hooks/use-cart";

export default function Pharmacy() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [sortOrder, setSortOrder] = useState<string>("featured");
  const { getTotalItems } = useCart();

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", selectedCategory],
    queryFn: async () => {
      const url = new URL("/api/products", window.location.origin);
      if (selectedCategory) {
        url.searchParams.append("category", selectedCategory);
      }
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      return response.json();
    }
  });

  const categories = [
    "All Products",
    "Prescription Meds",
    "Vitamins & Supplements",
    "Personal Care",
    "Health Devices",
    "First Aid"
  ];

  // Filter products by search query
  const filteredProducts = products?.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort products based on selected order
  const sortedProducts = filteredProducts ? [...filteredProducts] : [];
  if (sortOrder === "price-low") {
    sortedProducts.sort((a, b) => a.price - b.price);
  } else if (sortOrder === "price-high") {
    sortedProducts.sort((a, b) => b.price - a.price);
  } else if (sortOrder === "name") {
    sortedProducts.sort((a, b) => a.name.localeCompare(b.name));
  }

  return (
    <div className="bg-background min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-textColor mb-2 font-sf-pro">E-Pharmacy</h1>
          <p className="text-gray-600">Order prescribed medicines and healthcare products</p>
        </div>

        <div className="bg-gradient-to-r from-secondary to-primary text-white rounded-xl shadow-lg overflow-hidden mb-10">
          <div className="md:flex">
            <div className="md:w-2/3 p-8">
              <h3 className="text-2xl font-bold mb-3 font-sf-pro">Prescription Delivery Service</h3>
              <p className="mb-6">
                Upload your prescription and get medicines delivered to your doorstep. Fast, secure,
                and convenient.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="bg-white text-primary hover:bg-gray-100 font-medium py-2 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                >
                  <Upload className="mr-2 h-4 w-4" /> Upload Prescription
                </Button>
                <Button
                  className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-medium py-2 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                  variant="ghost"
                >
                  <Clock className="mr-2 h-4 w-4" /> View Order History
                </Button>
              </div>
            </div>
            <div className="md:w-1/3 flex items-center justify-center p-8 bg-white bg-opacity-10">
              <img
                src="https://images.unsplash.com/photo-1582560475093-ba66accbc7f0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
                alt="Prescription delivery"
                className="max-h-48 object-contain"
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          <div className="md:w-1/4">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Categories</h3>
                <Filter className="h-5 w-5 text-gray-500" />
              </div>
              <div className="space-y-2">
                {categories.map((category, index) => (
                  <Button
                    key={index}
                    variant={category === (selectedCategory || "All Products") ? "subtle" : "ghost"}
                    className={`w-full justify-start ${
                      category === (selectedCategory || "All Products")
                        ? "bg-primary/10 text-primary"
                        : "text-gray-700"
                    }`}
                    onClick={() => setSelectedCategory(category === "All Products" ? "" : category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Popular Products</h3>
              <div className="space-y-4">
                {products?.slice(0, 3).map(product => (
                  <div key={product.id} className="flex items-center">
                    <div className="w-12 h-12 bg-gray-100 rounded-md flex-shrink-0 mr-3">
                      <img
                        src={product.imageUrl || `https://via.placeholder.com/48?text=${encodeURIComponent(product.name.charAt(0))}`}
                        alt={product.name}
                        className="w-full h-full object-contain p-1"
                      />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">{product.name}</h4>
                      <p className="text-primary text-sm font-semibold">${(product.price / 100).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Need Help?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Our pharmacists are available to answer your questions about medications and health products.
              </p>
              <Button className="w-full bg-primary text-white">Contact Pharmacist</Button>
            </div>
          </div>

          <div className="md:w-3/4">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <div className="flex flex-col md:flex-row gap-4 justify-between">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search products..."
                    className="pl-10"
                  />
                </div>
                <div className="flex gap-4">
                  <Select
                    value={sortOrder}
                    onValueChange={(value) => setSortOrder(value)}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="featured">Featured</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="name">Name</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button 
                    variant="outline" 
                    className="relative"
                    onClick={() => window.location.href = "/cart"}
                  >
                    <ShoppingCart className="h-5 w-5" />
                    <Badge className="absolute -top-2 -right-2 bg-primary text-white text-xs">
                      {getTotalItems()}
                    </Badge>
                  </Button>
                </div>
              </div>
            </div>

            <Tabs defaultValue="all" className="mb-6">
              <TabsList className="bg-white">
                <TabsTrigger value="all">All Products</TabsTrigger>
                <TabsTrigger value="popular">Popular</TabsTrigger>
                <TabsTrigger value="new">New Arrivals</TabsTrigger>
                <TabsTrigger value="discounted">Discounted</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="mt-4">
                {isLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : sortedProducts.length === 0 ? (
                  <div className="text-center py-12 bg-white rounded-lg">
                    <h3 className="text-lg font-medium text-gray-900">No products found</h3>
                    <p className="mt-2 text-sm text-gray-500">
                      Try adjusting your search or filter to find what you're looking for.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {sortedProducts.map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>
                )}
              </TabsContent>
              <TabsContent value="popular" className="mt-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedProducts.slice(0, 3).map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="new" className="mt-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedProducts.slice(2, 5).map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="discounted" className="mt-4">
                <div className="text-center py-12 bg-white rounded-lg">
                  <h3 className="text-lg font-medium text-gray-900">No discounted products</h3>
                  <p className="mt-2 text-sm text-gray-500">
                    Check back later for special offers and discounts.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
