import HeroSection from "@/components/home/hero-section";
import ServicesSection from "@/components/home/services-section";
import TopDoctors from "@/components/home/top-doctors";
import CommunitySection from "@/components/home/community-section";
import PharmacySection from "@/components/home/pharmacy-section";
import MobileAppSection from "@/components/home/mobile-app-section";
import TestimonialsSection from "@/components/home/testimonials-section";
import NewsletterSection from "@/components/home/newsletter-section";

export default function HomePage() {
  return (
    <div>
      <HeroSection />
      <ServicesSection />
      <TopDoctors />
      <CommunitySection />
      <PharmacySection />
      <MobileAppSection />
      <TestimonialsSection />
      <NewsletterSection />
    </div>
  );
}
