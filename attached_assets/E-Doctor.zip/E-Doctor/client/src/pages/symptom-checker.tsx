import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Symptom, Condition } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2, AlertTriangle, X, Plus, Upload, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type AnalysisResult = {
  conditions: {
    condition: Condition;
    score: number;
  }[];
  symptoms: Symptom[];
};

export default function SymptomChecker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [selectedSymptoms, setSelectedSymptoms] = useState<Symptom[]>([]);
  const [symptomInput, setSymptomInput] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Fetch available symptoms
  const { data: symptoms, isLoading: symptomsLoading } = useQuery<Symptom[]>({
    queryKey: ["/api/symptoms"],
  });

  // Filter symptoms based on input
  const filteredSymptoms = symptoms?.filter(
    (symptom) =>
      symptom.name.toLowerCase().includes(symptomInput.toLowerCase()) &&
      !selectedSymptoms.some((s) => s.id === symptom.id)
  );

  // Analyze symptoms mutation
  const analysisMutation = useMutation<AnalysisResult, Error, number[]>({
    mutationFn: async (symptomIds) => {
      const res = await fetch("/api/symptoms/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ symptomIds }),
      });
      
      if (!res.ok) {
        throw new Error("Failed to analyze symptoms");
      }
      
      return res.json();
    },
    onSuccess: (data) => {
      if (data.conditions.length === 0) {
        toast({
          title: "No conditions found",
          description: "We couldn't identify any potential conditions based on your symptoms.",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Analysis failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddSymptom = (symptom: Symptom) => {
    setSelectedSymptoms([...selectedSymptoms, symptom]);
    setSymptomInput("");
  };

  const handleRemoveSymptom = (symptomId: number) => {
    setSelectedSymptoms(selectedSymptoms.filter((s) => s.id !== symptomId));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleAnalyze = () => {
    if (selectedSymptoms.length === 0) {
      toast({
        title: "No symptoms selected",
        description: "Please select at least one symptom to analyze.",
        variant: "destructive",
      });
      return;
    }

    analysisMutation.mutate(selectedSymptoms.map((s) => s.id));
  };

  const handleConsultDoctor = (condition: Condition) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to book a consultation.",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    // In a real app, we would navigate to doctor booking page with pre-selected condition
    navigate("/doctors");
  };

  return (
    <div className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <Card className="w-full overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 p-8 md:p-12">
              <h2 className="text-2xl md:text-3xl font-bold text-textColor mb-4">
                AI-Powered Symptom Analysis
              </h2>
              <p className="text-gray-600 mb-6">
                Enter your symptoms or upload your medical reports to get a preliminary
                analysis of possible conditions.
              </p>

              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3">
                    1
                  </div>
                  <span className="text-lg font-medium">Enter your symptoms</span>
                </div>
                <div className="bg-background rounded-lg p-4 mb-6">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {selectedSymptoms.map((symptom) => (
                      <span
                        key={symptom.id}
                        className="bg-primary/20 text-primary font-medium px-4 py-1.5 rounded-full text-sm flex items-center shadow-sm mb-1"
                      >
                        {symptom.name}
                        <button
                          className="ml-2 text-xs bg-primary/10 rounded-full p-1 hover:bg-primary/30 transition-colors"
                          onClick={() => handleRemoveSymptom(symptom.id)}
                          aria-label={`Remove ${symptom.name}`}
                        >
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                  </div>
                  <div className="relative">
                    <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 bg-white shadow-sm focus-within:ring-2 focus-within:ring-primary focus-within:border-transparent">
                      <Search className="h-4 w-4 text-gray-400 mr-2" />
                      <Input
                        type="text"
                        placeholder="Type your symptoms (e.g., Headache, Fever)..."
                        value={symptomInput}
                        onChange={(e) => setSymptomInput(e.target.value)}
                        className="w-full border-0 focus:outline-none focus:ring-0 px-0 py-0"
                      />
                      {symptomInput && (
                        <button
                          className="ml-2 p-1 rounded-full bg-primary/10 hover:bg-primary/20 text-primary"
                          onClick={() => {
                            if (filteredSymptoms && filteredSymptoms.length > 0) {
                              handleAddSymptom(filteredSymptoms[0]);
                            }
                          }}
                          disabled={!filteredSymptoms || filteredSymptoms.length === 0}
                          aria-label="Add symptom"
                        >
                          <Plus size={16} />
                        </button>
                      )}
                    </div>
                    
                    {symptomInput && filteredSymptoms && filteredSymptoms.length > 0 && (
                      <div className="absolute left-0 right-0 mt-1 bg-white rounded-lg shadow-lg z-10 max-h-64 overflow-auto border border-gray-200">
                        {filteredSymptoms.slice(0, 6).map((symptom) => (
                          <div
                            key={symptom.id}
                            className="px-4 py-2.5 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0 transition-colors"
                            onClick={() => handleAddSymptom(symptom)}
                          >
                            <div className="font-medium text-primary/90">{symptom.name}</div>
                            {symptom.description && (
                              <div className="text-xs text-gray-500 mt-0.5">{symptom.description}</div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3">
                    2
                  </div>
                  <span className="text-lg font-medium">
                    Upload medical reports (optional)
                  </span>
                </div>
                <div
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center"
                  onClick={() => document.getElementById("file-upload")?.click()}
                >
                  <input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={handleFileChange}
                  />
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500 mb-2">
                    {selectedFile ? selectedFile.name : "Drag and drop your files here"}
                  </p>
                  <p className="text-gray-400 text-sm mb-3">
                    Supported formats: PDF, JPG, PNG
                  </p>
                  <Button variant="outline" className="bg-primary text-white hover:bg-primary/90">
                    Browse Files
                  </Button>
                </div>
              </div>

              <Button
                className="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90 transition duration-300 flex items-center justify-center"
                onClick={handleAnalyze}
                disabled={symptomsLoading || analysisMutation.isPending}
              >
                {analysisMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Search className="mr-2 h-4 w-4" />
                )}
                {analysisMutation.isPending ? "Analyzing..." : "Analyze Symptoms"}
              </Button>
            </div>
            <div className="md:w-1/2 bg-gradient-to-br from-primary to-secondary p-8 md:p-12 text-white">
              {!analysisMutation.data ? (
                <>
                  <h3 className="text-2xl font-bold mb-6">How it works</h3>

                  <div className="space-y-6">
                    <div className="flex">
                      <div className="flex-shrink-0 mr-4">
                        <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
                          <Search size={18} />
                        </div>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">AI Analysis</h4>
                        <p className="text-white text-opacity-80">
                          Our advanced AI analyzes your symptoms and medical reports to
                          identify potential conditions.
                        </p>
                      </div>
                    </div>

                    <div className="flex">
                      <div className="flex-shrink-0 mr-4">
                        <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="M3 3v5h5" />
                            <path d="M3 3l6.5 6.5" />
                            <path d="M21 21v-5h-5" />
                            <path d="M21 21l-6.5-6.5" />
                            <path d="M9 3h1" />
                            <path d="M14 3h1" />
                            <path d="M19 3h1" />
                            <path d="M9 21h1" />
                            <path d="M14 21h1" />
                            <path d="M19 21h1" />
                            <path d="M3 9v1" />
                            <path d="M3 14v1" />
                            <path d="M3 19v1" />
                            <path d="M21 9v1" />
                            <path d="M21 14v1" />
                            <path d="M21 19v1" />
                          </svg>
                        </div>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Doctor Matching</h4>
                        <p className="text-white text-opacity-80">
                          Based on the analysis, we match you with the most suitable
                          specialists for your condition.
                        </p>
                      </div>
                    </div>

                    <div className="flex">
                      <div className="flex-shrink-0 mr-4">
                        <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="m22 8-6 4 6 4V8Z" />
                            <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                          </svg>
                        </div>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Consultation</h4>
                        <p className="text-white text-opacity-80">
                          Schedule a secure video consultation with your chosen specialist
                          for proper diagnosis and treatment.
                        </p>
                      </div>
                    </div>

                    <div className="flex">
                      <div className="flex-shrink-0 mr-4">
                        <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z" />
                            <path d="m8.5 8.5 7 7" />
                          </svg>
                        </div>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Treatment</h4>
                        <p className="text-white text-opacity-80">
                          Get prescriptions and order medicines directly through our
                          integrated e-pharmacy.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 bg-white bg-opacity-10 rounded-lg p-4">
                    <p className="text-sm text-white text-opacity-90 italic">
                      Note: Our AI analysis provides preliminary insights only and is not a
                      replacement for professional medical diagnosis.
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <h3 className="text-2xl font-bold mb-6">Analysis Results</h3>
                  
                  {analysisMutation.data.conditions.length === 0 ? (
                    <div className="bg-white bg-opacity-10 rounded-lg p-6 mb-4">
                      <div className="flex items-center mb-2">
                        <AlertTriangle className="h-5 w-5 mr-2" />
                        <h4 className="text-lg font-semibold">Insufficient Information</h4>
                      </div>
                      <p className="text-white text-opacity-90">
                        We couldn't determine potential conditions based on the provided symptoms. 
                        Please add more specific symptoms or consult with a doctor directly.
                      </p>
                    </div>
                  ) : (
                    <>
                      <p className="mb-4">
                        Based on your symptoms, our AI suggests these potential conditions. 
                        Please consult with a doctor for accurate diagnosis.
                      </p>
                      
                      <div className="space-y-4 mb-6">
                        {analysisMutation.data.conditions.slice(0, 3).map(({ condition, score }) => (
                          <div key={condition.id} className="bg-white bg-opacity-10 rounded-lg p-4">
                            <div className="flex justify-between items-center mb-2">
                              <h4 className="font-semibold text-lg">{condition.name}</h4>
                              <div className="text-xs font-medium bg-white text-primary px-2 py-1 rounded-full">
                                Match: {Math.min(Math.round((score / selectedSymptoms.length) * 100), 95)}%
                              </div>
                            </div>
                            <p className="text-sm text-white text-opacity-90 mb-3">{condition.description}</p>
                            <p className="text-xs text-white text-opacity-80 mb-3">
                              Specialist: {condition.specialization}
                            </p>
                            <Button
                              className="w-full bg-white text-primary hover:bg-white/90"
                              size="sm"
                              onClick={() => handleConsultDoctor(condition)}
                            >
                              Consult a {condition.specialization}
                            </Button>
                          </div>
                        ))}
                      </div>

                      <div className="bg-white bg-opacity-10 rounded-lg p-4">
                        <p className="text-sm text-white text-opacity-90 italic">
                          <AlertTriangle className="h-4 w-4 inline mr-1" />
                          This analysis is based on the symptoms you provided and is not a medical diagnosis. 
                          Always consult with healthcare professionals.
                        </p>
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
