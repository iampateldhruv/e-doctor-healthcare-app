import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Bell, Menu, User, LogOut, Home, Stethoscope, Pill, MessageSquare, Activity } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Navbar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { name: "Home", path: "/", icon: <Home className="h-4 w-4 mr-2" /> },
    { name: "Find Doctors", path: "/doctors", icon: <Stethoscope className="h-4 w-4 mr-2" /> },
    { name: "Pharmacy", path: "/pharmacy", icon: <Pill className="h-4 w-4 mr-2" /> },
    { name: "Community", path: "/community", icon: <MessageSquare className="h-4 w-4 mr-2" /> },
    { name: "Health Check", path: "/symptom-checker", icon: <Activity className="h-4 w-4 mr-2" /> },
  ];

  const isActive = (path: string) => {
    return location === path;
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const getInitials = (name: string) => {
    if (!name) return "HC";
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <div className="flex items-center gap-2 cursor-pointer">
                  <svg className="h-8 w-8 text-primary" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19 3H5c-1.1 0-1.99.9-1.99 2L3 19c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 11h-4v4h-4v-4H6v-4h4V6h4v4h4v4z" />
                  </svg>
                  <span className="text-xl font-bold text-primary font-sf-pro">E-Doctor</span>
                </div>
              </Link>
            </div>
            <div className="hidden md:ml-6 md:flex md:space-x-6">
              {navLinks.map((link) => (
                <Link
                  key={link.path} 
                  href={link.path} 
                  className={`${
                    isActive(link.path)
                      ? "text-primary border-b-2 border-primary font-medium"
                      : "text-textColor hover:text-primary font-medium"
                  } px-1 py-2 text-sm`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
          <div className="flex items-center">
            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <>
                  <Link 
                    href={user.role === "patient" ? "/dashboard" : "/dashboard"}
                    className="relative text-sm font-medium text-textColor hover:text-primary"
                  >
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-warning"></span>
                  </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.profilePicture} alt={user.fullName} />
                          <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56" align="end" forceMount>
                      <div className="flex flex-col space-y-1 p-2">
                        <p className="text-sm font-medium">{user.fullName}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard" className="cursor-pointer w-full">
                          Dashboard
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={handleLogout}
                        className="text-red-600 cursor-pointer"
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <Link href="/auth">
                  <Button variant="default" className="bg-primary hover:bg-primary/90">
                    Sign In
                  </Button>
                </Link>
              )}
            </div>
            <div className="flex items-center md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-gray-500 hover:text-primary">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="py-4">
                    <div className="flex items-center mb-6">
                      <svg className="h-8 w-8 text-primary" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-1.99.9-1.99 2L3 19c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 11h-4v4h-4v-4H6v-4h4V6h4v4h4v4z" />
                      </svg>
                      <span className="text-xl font-bold text-primary font-sf-pro ml-2">E-Doctor</span>
                    </div>

                    <div className="space-y-3">
                      {navLinks.map((link) => (
                        <Link 
                          key={link.path} 
                          href={link.path}
                          className={`${
                            isActive(link.path)
                              ? "text-primary font-medium"
                              : "text-textColor hover:text-primary"
                          } flex items-center py-2 px-1 text-base`}
                        >
                          {link.icon}
                          {link.name}
                        </Link>
                      ))}

                      {user ? (
                        <>
                          <Link 
                            href="/dashboard"
                            className="flex items-center py-2 px-1 text-base text-textColor hover:text-primary"
                          >
                            <User className="h-4 w-4 mr-2" />
                            Dashboard
                          </Link>
                          <button
                            className="flex items-center py-2 px-1 text-base text-red-600 hover:text-red-700 w-full text-left"
                            onClick={handleLogout}
                          >
                            <LogOut className="h-4 w-4 mr-2" />
                            Logout
                          </button>
                        </>
                      ) : (
                        <Link href="/auth">
                          <Button className="w-full bg-primary hover:bg-primary/90">Sign In</Button>
                        </Link>
                      )}
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
