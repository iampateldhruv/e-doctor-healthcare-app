import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Check } from "lucide-react";

export default function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Thank you for subscribing!",
        description: "You'll now receive our weekly health insights directly to your inbox.",
      });
      setEmail("");
    }, 1000);
  };

  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 p-8 md:p-12">
              <h2 className="text-2xl font-bold text-textColor mb-4 font-sf-pro">
                Stay Updated with Health Tips
              </h2>
              <p className="text-gray-600 mb-6">
                Subscribe to our newsletter for weekly health insights, tips from doctors, and
                updates on new features.
              </p>
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                <Input
                  type="email"
                  placeholder="Your email address"
                  className="flex-1 border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isSubmitting}
                />
                <Button
                  type="submit"
                  className="bg-primary text-white px-6 py-3 rounded-lg font-medium hover:bg-opacity-90 transition duration-300 whitespace-nowrap"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    "Subscribe"
                  )}
                </Button>
              </form>
              <p className="text-xs text-gray-500 mt-3">
                By subscribing, you agree to our Privacy Policy and consent to receive
                health-related emails.
              </p>
            </div>
            <div className="md:w-1/2 bg-gradient-to-r from-primary to-secondary text-white p-8 md:p-12">
              <h3 className="text-xl font-bold mb-4 font-sf-pro">Benefits of Subscription</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <Check className="mt-1 mr-3" />
                  <span>Expert health tips from verified doctors</span>
                </li>
                <li className="flex items-start">
                  <Check className="mt-1 mr-3" />
                  <span>Seasonal health advisories and preventive measures</span>
                </li>
                <li className="flex items-start">
                  <Check className="mt-1 mr-3" />
                  <span>Information about new treatment options</span>
                </li>
                <li className="flex items-start">
                  <Check className="mt-1 mr-3" />
                  <span>Exclusive discounts on health products</span>
                </li>
                <li className="flex items-start">
                  <Check className="mt-1 mr-3" />
                  <span>Early access to new platform features</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
