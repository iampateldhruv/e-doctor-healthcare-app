import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ArrowRight, Loader2, Upload } from "lucide-react";
import ProductCard from "@/components/pharmacy/product-card";

const categories = [
  "All Products",
  "Prescription Meds",
  "Vitamins & Supplements",
  "Personal Care",
  "Health Devices"
];

export default function PharmacySection() {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const response = await fetch("/api/products");
      if (!response.ok) {
        throw new Error("Failed to fetch products");
      }
      return response.json();
    }
  });

  // Get up to 5 products for the homepage
  const featuredProducts = products?.slice(0, 5);

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-3xl font-bold text-textColor font-sf-pro">E-Pharmacy</h2>
            <p className="text-gray-600 mt-2">Order prescribed medicines and healthcare products</p>
          </div>
          <Link href="/pharmacy">
            <a className="text-primary font-medium hidden md:flex items-center">
              View All Products <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>

        <div className="flex items-center space-x-4 mb-8 overflow-x-auto pb-2 md:flex-wrap">
          {categories.map((category, index) => (
            <Link key={index} href={`/pharmacy${category === "All Products" ? "" : `?category=${category}`}`}>
              <Button
                variant={index === 0 ? "default" : "outline"}
                className={`whitespace-nowrap rounded-full ${index === 0 ? "bg-primary text-white" : "bg-background text-textColor hover:bg-gray-200"}`}
              >
                {category}
              </Button>
            </Link>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {featuredProducts?.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        <div className="mt-10 bg-gradient-to-r from-secondary to-primary text-white rounded-xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-2/3 p-8">
              <h3 className="text-2xl font-bold mb-3 font-sf-pro">Prescription Delivery Service</h3>
              <p className="mb-6">
                Upload your prescription and get medicines delivered to your doorstep. Fast, secure,
                and convenient.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="bg-white text-primary hover:bg-gray-100 font-medium py-2 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                >
                  <Upload className="mr-2 h-4 w-4" /> Upload Prescription
                </Button>
                <Button
                  className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white font-medium py-2 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                  variant="ghost"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-2"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  View Order History
                </Button>
              </div>
            </div>
            <div className="md:w-1/3 flex items-center justify-center p-8 bg-white bg-opacity-10">
              <img
                src="/prescription.svg"
                alt="Prescription delivery"
                className="max-h-48 object-contain"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
