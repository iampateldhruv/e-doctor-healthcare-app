import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Post, User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ArrowRight, Loader2, Heart, MessageSquare } from "lucide-react";
import PostCard from "@/components/community/post-card";

type PostWithAuthor = Post & { author: User };

export default function CommunitySection() {
  const { data: posts, isLoading } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts"],
    queryFn: async () => {
      const response = await fetch("/api/posts");
      if (!response.ok) {
        throw new Error("Failed to fetch posts");
      }
      return response.json();
    }
  });

  // Get up to 3 posts for the homepage
  const topPosts = posts?.slice(0, 3);

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-3xl font-bold text-textColor font-sf-pro">Health Community</h2>
            <p className="text-gray-600 mt-2">Expert tips and community discussions for better health</p>
          </div>
          <Link href="/community">
            <a className="text-primary font-medium hidden md:flex items-center">
              View All Posts <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {topPosts?.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-sm p-6 mt-10">
          <h3 className="text-xl font-bold mb-4 font-sf-pro">Join the Conversation</h3>
          <div className="flex items-start mb-6">
            <img
              src="https://ui-avatars.com/api/?name=Guest+User&background=0D8ABC&color=fff"
              alt="User"
              className="w-10 h-10 rounded-full object-cover mr-3"
            />
            <div className="flex-1">
              <textarea
                placeholder="Share your health question or experience..."
                className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                rows={3}
              ></textarea>
              <div className="flex justify-between items-center mt-3">
                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                      />
                    </svg>
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
                      />
                    </svg>
                  </Button>
                </div>
                <Link href="/community">
                  <Button className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90 transition duration-300">
                    Post to Community
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center mb-4">
            <h4 className="font-semibold">Recent Discussions</h4>
            <div className="text-sm">
              <span className="text-primary cursor-pointer">Newest</span>
              <span className="mx-2 text-gray-300">|</span>
              <span className="text-gray-500 cursor-pointer">Popular</span>
            </div>
          </div>

          <div className="space-y-6">
            <div className="border-b border-gray-200 pb-6">
              <div className="flex items-center mb-2">
                <img
                  src="https://ui-avatars.com/api/?name=Emily+Johnson&background=0D8ABC&color=fff"
                  alt="User avatar"
                  className="w-8 h-8 rounded-full object-cover mr-2"
                />
                <div>
                  <p className="text-sm font-semibold">
                    Emily Johnson <span className="text-xs text-gray-500 ml-1">Patient</span>
                  </p>
                  <p className="text-xs text-gray-500">2 hours ago</p>
                </div>
              </div>
              <p className="text-sm mb-3">
                Has anyone tried meditation for managing chronic pain? I've been dealing with back
                pain for years and looking for alternative approaches besides medication.
              </p>
              <div className="flex items-center text-sm">
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center mr-4">
                  <Heart className="mr-1 h-4 w-4" /> 12
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center mr-4">
                  <MessageSquare className="mr-1 h-4 w-4" /> 8
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-1"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
                    />
                  </svg>
                  Share
                </Button>
              </div>
            </div>

            <div className="border-b border-gray-200 pb-6">
              <div className="flex items-center mb-2">
                <img
                  src="https://ui-avatars.com/api/?name=David+Kim&background=0D8ABC&color=fff"
                  alt="User avatar"
                  className="w-8 h-8 rounded-full object-cover mr-2"
                />
                <div>
                  <p className="text-sm font-semibold">
                    David Kim <span className="text-xs text-gray-500 ml-1">Fitness Coach</span>
                  </p>
                  <p className="text-xs text-gray-500">5 hours ago</p>
                </div>
              </div>
              <p className="text-sm mb-3">
                What's the optimal amount of protein intake for muscle recovery after strength
                training? I've heard different recommendations ranging from 1g to 2g per kg of body
                weight.
              </p>
              <div className="flex items-center text-sm">
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center mr-4">
                  <Heart className="mr-1 h-4 w-4" /> 24
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center mr-4">
                  <MessageSquare className="mr-1 h-4 w-4" /> 15
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-primary flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-1"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
                    />
                  </svg>
                  Share
                </Button>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link href="/community">
              <Button variant="link" className="text-primary font-medium">View More Discussions</Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
