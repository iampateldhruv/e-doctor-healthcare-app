import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-primary to-secondary text-white py-12 md:py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 font-sf-pro">
              Your Health, Our Priority
            </h1>
            <p className="text-lg md:text-xl mb-6">
              AI-powered healthcare platform connecting you with specialized doctors. Get symptoms
              analyzed, connect with the right specialist, and have medicines delivered to your
              doorstep.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Link href="/symptom-checker">
                <Button
                  className="bg-white text-primary hover:bg-gray-100 font-bold py-3 px-6 rounded-lg transition duration-300"
                  size="lg"
                >
                  Check Symptoms
                </Button>
              </Link>
              <Link href="/doctors">
                <Button
                  className="bg-accent text-white hover:bg-opacity-90 font-bold py-3 px-6 rounded-lg transition duration-300"
                  size="lg"
                >
                  Find a Doctor
                </Button>
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 md:pl-12">
            <img
              src="/doctor-tablet.svg"
              alt="Doctor with digital tablet"
              className="rounded-xl shadow-xl w-full object-cover h-64 md:h-80"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
