import { Button } from "@/components/ui/button";

export default function MobileAppSection() {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-accent to-primary rounded-2xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 p-8 md:p-12 text-white">
              <h2 className="text-3xl font-bold mb-4 font-sf-pro">Get the E-Doctor App</h2>
              <p className="mb-6">
                Access healthcare services on-the-go. Book appointments, consult with doctors, order
                medicines, and track your health all from your smartphone.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-start">
                  <div className="bg-white bg-opacity-20 p-2 rounded-full mr-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m22 8-6 4 6 4V8Z" />
                      <rect width="14" height="12" x="2" y="6" rx="2" ry="2" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 font-sf-pro">Video Consultations</h3>
                    <p className="text-white text-opacity-80 text-sm">
                      Connect with doctors from anywhere, anytime
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-white bg-opacity-20 p-2 rounded-full mr-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3" />
                      <path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4" />
                      <circle cx="20" cy="10" r="2" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 font-sf-pro">Health Tracking</h3>
                    <p className="text-white text-opacity-80 text-sm">
                      Monitor your vital signs and health metrics
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-white bg-opacity-20 p-2 rounded-full mr-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                      <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 font-sf-pro">Medication Reminders</h3>
                    <p className="text-white text-opacity-80 text-sm">
                      Never miss a dose with timely alerts
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="bg-white flex items-center justify-center px-4 py-3 rounded-lg text-gray-900">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="mr-3 h-6 w-6"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M17.569 12.6254C17.597 15.652 20.2179 16.6592 20.247 16.673C20.2249 16.7419 19.9339 17.7048 19.1524 18.6996C18.4919 19.5401 17.8079 20.3778 16.7383 20.3927C15.6892 20.407 15.342 19.8023 14.1335 19.8023C12.9285 19.8023 12.552 20.3778 11.5605 20.407C10.5161 20.4357 9.6895 19.4653 9.0187 18.629C7.6569 16.9138 6.6337 13.8098 8.0337 11.7287C8.7258 10.6975 9.9202 10.0558 11.1957 10.0411C12.2168 10.0265 13.1837 10.6817 13.8054 10.6817C14.4272 10.6817 15.6081 9.891 16.8409 10.0853C17.2622 10.1072 18.5555 10.2663 19.3834 11.4202C19.3053 11.4739 17.5451 12.4486 17.569 15.6361M15.6526 8.6658C16.2023 7.9957 16.5809 7.0649 16.4883 6.1333C15.6694 6.172 14.6526 6.6692 14.0776 7.3239C13.5695 7.8944 13.1086 8.8544 13.2158 9.7568C14.1275 9.8212 15.0775 9.3351 15.6526 8.6658" />
                  </svg>
                  <div>
                    <p className="text-xs text-gray-600">Download on the</p>
                    <p className="text-sm font-semibold text-gray-900">App Store</p>
                  </div>
                </Button>

                <Button className="bg-white flex items-center justify-center px-4 py-3 rounded-lg text-gray-900">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="mr-3 h-6 w-6"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M3.57061 4.1973C3.19789 4.56181 3 5.0533 3 5.68252V18.3178C3 18.947 3.19789 19.4385 3.57061 19.8027L3.62799 19.8588L12.5223 11.0239V10.9766L3.62799 2.14166L3.57061 4.1973Z" />
                    <path d="M16.338 14.6867L12.5223 11.0239V10.9766L16.338 7.31393L16.4068 7.35564L20.8298 9.80134C22.0256 10.501 22.0256 11.4995 20.8298 12.1992L16.4068 14.6449L16.338 14.6867Z" />
                    <path d="M16.4068 14.6449L12.5223 11L3.57061 19.8027C4.00442 20.2519 4.71469 20.3089 5.52743 19.8599L16.4068 14.6449Z" />
                    <path d="M16.4068 7.35564L5.52743 2.14049C4.71469 1.69148 4.00442 1.74843 3.57061 2.19767L12.5223 11L16.4068 7.35564Z" />
                  </svg>
                  <div>
                    <p className="text-xs text-gray-600">Get it on</p>
                    <p className="text-sm font-semibold text-gray-900">Google Play</p>
                  </div>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2 p-8 flex items-center justify-center">
              <img
                src="/mobile-app.svg"
                alt="E-Doctor mobile app"
                className="max-h-80 object-contain"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
