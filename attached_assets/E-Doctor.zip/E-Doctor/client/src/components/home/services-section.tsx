import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Brain, Stethoscope, Pill, MessageSquare, ArrowRight } from "lucide-react";

const services = [
  {
    icon: <Brain className="text-primary text-2xl" />,
    title: "AI Symptom Analysis",
    description: "Upload your symptoms or medical reports and get AI-powered disease predictions.",
    linkText: "Try Now",
    linkHref: "/symptom-checker",
    color: "primary"
  },
  {
    icon: <Stethoscope className="text-secondary text-2xl" />,
    title: "Doctor Consultation",
    description: "Connect with specialized doctors through secure video consultations.",
    linkText: "Book Now",
    linkHref: "/doctors",
    color: "secondary"
  },
  {
    icon: <Pill className="text-accent text-2xl" />,
    title: "E-Pharmacy",
    description: "Order prescribed medicines online and get them delivered to your doorstep.",
    linkText: "Shop Now",
    linkHref: "/pharmacy",
    color: "accent"
  },
  {
    icon: <MessageSquare className="text-warning text-2xl" />,
    title: "Health Community",
    description: "Join our community of doctors and patients sharing health tips and advice.",
    linkText: "Join Now",
    linkHref: "/community",
    color: "warning"
  }
];

export default function ServicesSection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-textColor mb-4 font-sf-pro">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Complete healthcare solution with AI-driven disease prediction, doctor consultations, and
            pharmacy services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-background rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow duration-300"
            >
              <div className={`w-14 h-14 bg-${service.color} bg-opacity-10 rounded-full flex items-center justify-center mb-4`}>
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3 font-sf-pro">{service.title}</h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <Link href={service.linkHref}>
                <a className={`text-${service.color} font-medium flex items-center`}>
                  {service.linkText} <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
