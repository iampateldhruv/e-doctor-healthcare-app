import { Star, StarHalf } from "lucide-react";

const testimonials = [
  {
    content:
      "The symptom analyzer was surprisingly accurate. It matched me with a specialist who diagnosed my condition correctly. The virtual consultation was smooth, and I received my medication the next day. Truly a seamless experience!",
    name: "Sarah M.",
    since: "Patient since 2022",
    avatar:
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
    rating: 5,
  },
  {
    content:
      "As someone with a chronic condition, having all my medical records in one place and being able to order my prescriptions without visiting a pharmacy has been life-changing. The reminders feature ensures I never miss my medication.",
    name: "John D.",
    since: "Patient since 2021",
    avatar:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
    rating: 5,
  },
  {
    content:
      "I was skeptical about telemedicine, but my experience was excellent. The doctor was attentive and thorough, even through video. The community section also provides valuable health tips from verified medical professionals.",
    name: "Robert T.",
    since: "Patient since 2023",
    avatar:
      "https://images.unsplash.com/photo-1552058544-f2b08422138a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1998&q=80",
    rating: 4.5,
  },
];

export default function TestimonialsSection() {
  // Helper function to render star ratings
  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    return (
      <div className="flex text-warning mb-4">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={i} className="fill-current" />
        ))}
        {hasHalfStar && <StarHalf className="fill-current" />}
      </div>
    );
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-textColor mb-4 font-sf-pro">
            What Our Patients Say
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Real stories from people who've experienced better healthcare through our platform
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-background rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              {renderStars(testimonial.rating)}
              <p className="text-gray-600 mb-6 italic">"{testimonial.content}"</p>
              <div className="flex items-center">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.since}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
