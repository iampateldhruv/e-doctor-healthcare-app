import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ArrowRight, Loader2 } from "lucide-react";
import DoctorCard from "@/components/doctor/doctor-card";

const specializations = [
  "All Specialists",
  "Cardiologist",
  "Neurologist",
  "Dermatologist",
  "Pediatrician",
  "Orthopedic"
];

export default function TopDoctors() {
  const { data: doctors, isLoading } = useQuery<User[]>({
    queryKey: ["/api/doctors"],
    queryFn: async () => {
      const response = await fetch("/api/doctors");
      if (!response.ok) {
        throw new Error("Failed to fetch doctors");
      }
      return response.json();
    }
  });

  // Get top 4 doctors sorted by rating
  const topDoctors = doctors
    ?.filter(doctor => doctor.verified)
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-3xl font-bold text-textColor font-sf-pro">Top Specialists</h2>
            <p className="text-gray-600 mt-2">
              Connect with highly rated doctors specializing in various fields
            </p>
          </div>
          <Link href="/doctors">
            <a className="text-primary font-medium hidden md:flex items-center">
              View All Doctors <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Link>
        </div>

        <div className="flex items-center space-x-4 mb-8 overflow-x-auto pb-2 md:flex-wrap">
          {specializations.map((specialization, index) => (
            <Link key={index} href={`/doctors${specialization === "All Specialists" ? "" : `?specialization=${specialization}`}`}>
              <Button
                variant={index === 0 ? "default" : "outline"}
                className={`whitespace-nowrap rounded-full ${index === 0 ? "bg-primary text-white" : "bg-background text-textColor hover:bg-gray-200"}`}
              >
                {specialization}
              </Button>
            </Link>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {topDoctors?.map((doctor) => (
              <DoctorCard key={doctor.id} doctor={doctor} />
            ))}
          </div>
        )}

        <div className="mt-8 text-center">
          <Link href="/doctors">
            <Button className="inline-block bg-primary text-white px-6 py-2 rounded-lg md:hidden">
              View All Doctors
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
