import { Link } from "wouter";
import { User } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Briefcase, MapPin, Star, StarHalf, Video } from "lucide-react";

interface DoctorCardProps {
  doctor: User;
}

export default function DoctorCard({ doctor }: DoctorCardProps) {
  // Function to render star rating
  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="text-warning text-xs fill-current" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="text-warning text-xs fill-current" />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-warning text-xs" />);
    }

    return stars;
  };

  // Generate specializations as badges
  const specializations = doctor.specialization
    ? doctor.specialization.split(",").map(s => s.trim())
    : [];

  // Default profile image if none provided
  const profileImage =
    doctor.profilePicture ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(doctor.fullName)}&background=0D8ABC&color=fff`;

  return (
    <Card className="bg-background rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300">
      <div className="p-6">
        <div className="flex items-start mb-4">
          <img
            src={profileImage}
            alt={doctor.fullName}
            className="w-16 h-16 rounded-full object-cover mr-4"
          />
          <div>
            <h3 className="text-lg font-bold font-sf-pro">
              {doctor.fullName}
              {doctor.verified && (
                <span className="verified-badge">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-3 w-3 mr-1"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  Verified
                </span>
              )}
            </h3>
            <p className="text-primary font-medium text-sm">{doctor.specialization}</p>
            <div className="flex items-center mt-1">
              <div className="flex text-warning">
                {renderStarRating(doctor.rating)}
              </div>
              <span className="text-gray-600 text-xs ml-1">
                {doctor.rating.toFixed(1)} ({doctor.reviewCount} reviews)
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
          <div className="flex items-center">
            <Briefcase className="text-primary mr-2 h-4 w-4" />
            <span>{doctor.experience ? `${doctor.experience}+ years` : "Experienced"}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="text-primary mr-2 h-4 w-4" />
            <span>{doctor.location || "Remote"}</span>
          </div>
        </div>
        <p className="text-gray-600 text-sm mb-4">{doctor.bio || `Specializes in ${doctor.specialization}`}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {specializations.map((spec, index) => (
            <Badge key={index} variant="outline" className="bg-primary/10 text-primary font-medium border-primary/20">
              {spec}
            </Badge>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <div className="text-green-600 font-medium">
            <Video className="inline mr-1 h-4 w-4" /> Available Today
          </div>
          <Link href={`/doctors/${doctor.id}`}>
            <Button className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-opacity-90 transition duration-300">
              Book Appointment
            </Button>
          </Link>
        </div>
      </div>
    </Card>
  );
}
