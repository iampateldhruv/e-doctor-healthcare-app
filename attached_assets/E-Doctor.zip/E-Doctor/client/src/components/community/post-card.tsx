import { Link } from "wouter";
import { Post, User } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageSquare } from "lucide-react";

interface PostCardProps {
  post: Post & { author?: User };
}

export default function PostCard({ post }: PostCardProps) {
  // Format the date to a readable format
  const formatDate = (date: Date) => {
    const now = new Date();
    const postDate = new Date(date);
    const diffInDays = Math.floor((now.getTime() - postDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays < 1) {
      return "Today";
    } else if (diffInDays === 1) {
      return "Yesterday";
    } else if (diffInDays < 7) {
      return `${diffInDays} days ago`;
    } else if (diffInDays < 30) {
      return `${Math.floor(diffInDays / 7)} weeks ago`;
    } else {
      return postDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }
  };

  // Get a placeholder image if none is provided
  const imageUrl = post.imageUrl || "https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80";
  
  // Get author profile picture or a placeholder
  const authorImage = post.author?.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(post.author?.fullName || 'Unknown Author')}&background=0D8ABC&color=fff`;

  return (
    <Card className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300">
      <div className="h-48 overflow-hidden">
        <img
          src={imageUrl}
          alt={post.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      <CardContent className="p-6">
        <div className="flex items-center mb-3">
          <img
            src={authorImage}
            alt={post.author?.fullName || "Author"}
            className="w-8 h-8 rounded-full object-cover mr-2"
          />
          <div>
            <p className="text-sm font-semibold">
              {post.author?.fullName || "Unknown Author"}
              {post.author?.specialization && (
                <span className="text-xs text-primary ml-1">{post.author.specialization}</span>
              )}
            </p>
            <p className="text-xs text-gray-500">Posted {formatDate(post.createdAt)}</p>
          </div>
        </div>
        <h3 className="text-xl font-bold mb-3 font-sf-pro">{post.title}</h3>
        <p className="text-gray-600 text-sm mb-4">
          {post.content.length > 120 ? `${post.content.substring(0, 120)}...` : post.content}
        </p>
        <div className="flex flex-wrap gap-2 mb-4">
          {post.tags?.map((tag, index) => (
            <Badge
              key={index}
              variant="outline"
              className="bg-secondary bg-opacity-10 text-secondary px-2 py-1 rounded text-xs"
            >
              {tag}
            </Badge>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center text-gray-500 text-sm">
            <span className="flex items-center mr-4">
              <Heart className="mr-1 h-4 w-4" /> {post.likes}
            </span>
            <span className="flex items-center">
              <MessageSquare className="mr-1 h-4 w-4" /> {post.comments}
            </span>
          </div>
          <Link href={`/community/posts/${post.id}`}>
            <a className="text-primary font-medium text-sm">Read More</a>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
