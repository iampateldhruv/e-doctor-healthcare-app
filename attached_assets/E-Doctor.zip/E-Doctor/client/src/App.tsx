import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import { ProtectedRoute } from "./lib/protected-route";
import DoctorListing from "@/pages/doctor-listing";
import SymptomChecker from "@/pages/symptom-checker";
import Pharmacy from "@/pages/pharmacy";
import CartPage from "@/pages/cart";
import Community from "@/pages/community";
import DoctorProfile from "@/pages/doctor-profile";
import PatientDashboard from "@/pages/patient-dashboard";
import Consultation from "@/pages/consultation";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import { AuthProvider } from "@/hooks/use-auth";
import { CartProvider } from "@/hooks/use-cart";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/doctors" component={DoctorListing} />
          <Route path="/doctors/:id" component={DoctorProfile} />
          <Route path="/symptom-checker" component={SymptomChecker} />
          <Route path="/pharmacy" component={Pharmacy} />
          <Route path="/cart" component={CartPage} />
          <Route path="/community" component={Community} />
          <ProtectedRoute path="/dashboard" component={PatientDashboard} />
          <ProtectedRoute path="/consultation/:id" component={Consultation} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <Router />
        <Toaster />
      </CartProvider>
    </AuthProvider>
  );
}

export default App;
