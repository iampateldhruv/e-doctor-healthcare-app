import pg from 'pg';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

// Database connection info
const dbUrl = process.env.DATABASE_URL || 'postgresql://postgres:postgres@db.oifgojcqkhizhleolcjt.supabase.co:5432/postgres';

if (!dbUrl) {
  console.error('Missing DATABASE_URL environment variable.');
  process.exit(1);
}

// Read the SQL file
const sqlFilePath = path.join(process.cwd(), 'supabase-setup.sql');
const sql = fs.readFileSync(sqlFilePath, 'utf8');

// Split the SQL file into individual statements
const statements = sql
  .split(';')
  .filter(statement => statement.trim() !== '')
  .map(statement => statement.trim());

async function setupDatabase() {
  console.log('Connecting to database...');
  
  const client = new pg.Client({
    connectionString: dbUrl,
  });

  try {
    await client.connect();
    console.log('Connected to database');
    
    // Execute each SQL statement
    for (const statement of statements) {
      console.log(`Executing: ${statement.substring(0, 60)}...`);
      try {
        await client.query(statement);
        console.log('Statement executed successfully');
      } catch (error) {
        console.error(`Error executing SQL: ${error.message}`);
        console.error('Statement:', statement);
      }
    }
    
    console.log('Database setup completed');
  } catch (error) {
    console.error('Database connection error:', error);
  } finally {
    await client.end();
    console.log('Database connection closed');
  }
}

// Execute setup
setupDatabase();