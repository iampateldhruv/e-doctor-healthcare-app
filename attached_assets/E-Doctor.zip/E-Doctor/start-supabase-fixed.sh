#!/bin/bash
echo "Starting server with Supabase database..."
npx tsx server/index-supabase.ts