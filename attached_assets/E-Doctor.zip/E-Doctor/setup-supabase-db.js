import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

// Get Supabase credentials
const supabaseUrl = process.env.SUPABASE_URL || 'https://oifgojcqkhizhleolcjt.supabase.co';
const supabaseKey = process.env.SUPABASE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pZmdvamNxa2hpemhsZW9sY2p0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUzOTE4OTAsImV4cCI6MjA2MDk2Nzg5MH0.UaiTIwaEZ1IJ_Tmv-6e3_5rxKJcApXKi3LBdD9Apfmc';

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials. Set SUPABASE_URL and SUPABASE_KEY environment variables.');
  process.exit(1);
}

// Create Supabase client
const supabase = createClient(supabaseUrl, supabaseKey);

// Read the SQL file
const sqlFilePath = path.join(process.cwd(), 'supabase-setup.sql');
const sql = fs.readFileSync(sqlFilePath, 'utf8');

// Split the SQL file into individual statements
const statements = sql
  .split(';')
  .filter(statement => statement.trim() !== '')
  .map(statement => statement.trim() + ';');

async function executeSql() {
  console.log('Starting database setup...');

  try {
    // Execute each SQL statement
    for (const statement of statements) {
      console.log(`Executing: ${statement.substring(0, 60)}...`);
      const { error } = await supabase.rpc('pgexec', { sql: statement });
      
      if (error) {
        console.error(`Error executing SQL: ${error.message}`);
        console.error('Statement:', statement);
      }
    }

    console.log('Database setup completed successfully');
  } catch (error) {
    console.error('Failed to set up database:', error);
  }
}

// Execute the setup
executeSql();